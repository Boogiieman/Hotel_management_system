<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    function __construct()
    {
		parent::__construct();
		$this->load->database();
		date_default_timezone_set( 'Asia/Kolkata' ); 
		$this->load->model("admin_model","admo");
		$this->load->model("public_page_model","PPmo");
    }

	public function index()
	{
		$this->managehotels();
    } 
    
	public function login()
	{		
        $Data['masters']="";        
        $this->loadViewLogin('admin/login',$Data);
	} 
	public function forgotpassword()
	{		
        $Data['masters']="";        
        $this->loadView('admin/login',$Data);
	}
	
	public function managehotels()
	{		
		$Data['v_data']= $this->PPmo->getHotelList('');
        $Data['masters']="";        
        $this->loadView('admin/hotels_list',$Data);
	}
	public function modifyhotel()
	{		
		$hodel_id=$this->input->post('hotel_id');
		$Data['lstlocation']=   $this->PPmo->getLocation();
		$Data['location']=   $this->input->post('txtLocation');
		$Data['v_data']= $this->PPmo->getHotelDetails($hodel_id);
		if($Data['v_data']!='No')
		{
			$Data['v_data']= $Data['v_data']->row();
		}
        $Data['masters']="";        
        $this->loadView('admin/modify_hotel',$Data);
	}
	public function saveHotel()
	{		
		$Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';  		
		$hotel_id=$this->input->post('hotel_id');
		$savedata= array(
			'hotel_name'=>	$this->input->post('thotel_name'),
			'location'	=>	$this->input->post('tlocation'),
			'address1'	=>	$this->input->post('taddress1'),
			'address2'	=>	$this->input->post('taddress2'),
			'category'	=>	$this->input->post('tcategory'),
			'phone_number'	=>	$this->input->post('tphone_number'),
			'email'		=>	$this->input->post('temail'),
			'website'	=>	$this->input->post('twebsite'),
			'facilities'=>	$this->input->post('tfacilities'),
			'conditions'=>	$this->input->post('tconditions'),
			'image1'	=>	$this->input->post('timage1'),
			'status_id'	=>	1
		);
        if($Err==0)
        {			
			$result=$this->admo->saveHotel($savedata,$hotel_id);
			if($result==1)
			{
				$data['msg']='Successfully Saved'  ; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']=$result ; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	}

	public function managerooms()
	{		
		$Data['lsthotels']=   $this->admo->gethotels();
		$Data['hotelname']=   $this->input->post('txtHotel');

		$Data['v_data']= $this->PPmo->getRoomsListFull($Data['hotelname']);
        $Data['masters']="";        
        $this->loadView('admin/rooms_list',$Data);
	}

	public function modifyroom()
	{		
		$room_id=$this->input->post('room_id');	
		$Data['mhotel_id']=$this->input->post('hotel_id');	
		$Data['v_data']= $this->PPmo->getRoomDetails($room_id);
		if($Data['v_data']!='No')
		{
			$Data['v_data']= $Data['v_data']->row();
		}
        $Data['masters']="";        
        $this->loadView('admin/modify_room',$Data);
	}

	public function saveRoom()
	{		
		$Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';  		
		$room_id=$this->input->post('room_id');
		
		$savedata= array(
			'hotel_id'	=> $this->input->post('hotel_id'),	
			'room_number'=>$this->input->post('troomnumber'),
			'facilities'=>$this->input->post('tfacilities'),
			'room_type'=>$this->input->post('troomtype'),
			'no_of_adults'=>$this->input->post('tnoofadults'),
			'no_of_childs'=>$this->input->post('tnoofchild'),
			'image1'=>$this->input->post('timage1'),
			'status_id'	=>	1
		);
        if($Err==0)
        {			
			$result=$this->admo->saveRoom($savedata,$room_id);
			if($result==1)
			{
				$data['msg']='Successfully Saved'  ; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']=$result ; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	}




	public function manageavailability()
	{		
		$Data['lstrooms']=   $this->admo->getrooms();
		$Data['roomname']=   $this->input->post('txtRoom');

        $Data['v_data']= $this->admo->getAvailabilityList($Data['roomname']);
        $Data['masters']="";        
        $this->loadView('admin/availability_list',$Data); 
	}

	public function modifyavailability()
	{		
		$availability_id=$this->input->post('availability_id');		
		$Data['mroom_id']=$this->input->post('room_id');
		$Data['mroom_details']=$this->PPmo->getRoomDetails($Data['mroom_id'])->row();	
		$Data['v_data']= $this->PPmo->getAvailabiltiyDetails($availability_id);
		if($Data['v_data']!='No')
		{
			$Data['v_data']= $Data['v_data']->row();
		}
        $Data['masters']="";        
        $this->loadView('admin/modify_availability',$Data);
	}

	public function saveAvailability()
	{		
		$Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';  		
		$availability_id=$this->input->post('availability_id');
		$savedata= array(
			'room_id' => $this->input->post('room_id'),
			'hotel_id' => $this->input->post('hotel_id'),
			'availability_date' => $this->input->post('tavailability_date'),
			'rate' => $this->input->post('trate'),
			'tax_amount' => $this->input->post('ttax_amount'),
			'total_amount' => $this->input->post('ttotal_amount'),
			'booking_status'	=>	0,
			'status_id'	=>	1
		);
        if($Err==0)
        {			
			$result=$this->admo->saveAvailability($savedata,$availability_id);
			if($result==1)
			{
				$data['msg']='Successfully Saved'  ; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']=$result ; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	}



	public function manageBookings()
	{		
        $Data['v_data']= $this->admo->getBookingList('');
        $Data['masters']="";        
        $this->loadView('admin/booking_list',$Data); 
	}


	public function manageGuests()
	{		
		$Data['v_data']= $this->PPmo->getGuestList('');
        $Data['masters']="";        
        $this->loadView('admin/guest_list',$Data);
	}
		
	public function logincheck()
	{
		$Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';   
			
		$email = $this->input->post('txtemail'); 
		$password = $this->input->post('txtpassword'); 
        
		If(empty($email)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' EMail is missing';}
		If(empty($password)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' Password is missing';}  

        if($Err==0)
        {       
			$rec=$this->admo->LoginCheck($email,$password);
			if($rec!="No")
			{      
				$row = $rec->row();
				$array= array(
					'user_id'		=> $row->id , 
					'user_name' 	=> $row->full_name , 
					'role_id' 	=> $row->role_id 
				);
                $this->session->set_userdata('adminsession', $array);
            	$data['msg']='Login Success'; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']='Login Failed'; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	}

	public function logout()
	{		
				$array= array(
					'user_id'	 , 
					'user_name'  , 
					'role_id'  
				);
                $this->session->unset_userdata('adminsession',  $array);
            	$this->login();
	}

	public function bookings()
	{		
        $Data['masters']="";        
        $this->loadView('guest/login',$Data);
	} 

	function loadView($view,$data)
	{
	 	$this->load->view('public/public_header');	 	
		$this->load->view($view,$data);
		$this->load->view('public/public_footer');
	}
	function loadViewLogin($view,$data)
	{
	 	$this->load->view('public/public_header_login');	 	
		$this->load->view($view,$data);
		$this->load->view('public/public_footer');
	}
}
