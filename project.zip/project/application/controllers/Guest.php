<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guest extends CI_Controller {
    function __construct()
    {
		parent::__construct();
		$this->load->database();
		date_default_timezone_set( 'Asia/Kolkata' ); 
		$this->load->model("guest_model","PPmo");
    }

	public function index()
	{
        //$Data['masters']="";        
		//$this->loadView('public/public_page_statistics',$Data);
		$this->hotels();
    } 
   
	public function login()
	{		
        $Data['masters']="";        
        $this->loadView('guest/login',$Data);
	} 
	public function forgotpassword()
	{		
        $Data['masters']="";        
        $this->loadView('guest/login',$Data);
	}
	public function register()
	{		
        $Data['masters']="";        
        $this->loadView('guest/register',$Data);
	} 
	public function registersave()
	{		
        $Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';        
		$name = $this->input->post('txtname');  
		$phone = $this->input->post('txtcontact');		
		$email = $this->input->post('txtemail'); 
		$password = $this->input->post('txtpassword'); 

        If(empty($name)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' Name is missing';}
		If(empty($phone)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' Phone No is missing';}   
		If(empty($email)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' EMail is missing';}
		If(empty($password)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' Password is missing';}  

        if($Err==0)
        {       
			if($this->PPmo->guestSave($name,$phone,$email,$password)==1)
			{      
            	$data['msg']='Successfully Created'; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']='Duplicate User'; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	} 

	public function logincheck()
	{
		$Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';   
			
		$email = $this->input->post('txtemail'); 
		$password = $this->input->post('txtpassword'); 
        
		If(empty($email)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' EMail is missing';}
		If(empty($password)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' Password is missing';}  

        if($Err==0)
        {       
			$rec=$this->PPmo->LoginCheck($email,$password);
			if($rec!="No")
			{      
				$row = $rec->row();
				$array= array(
					'client_id'		=> $row->client_id , 
					'user_name' 	=> $row->full_name , 
					'email' 	=> $row->email_id  , 
					'phone' 	=> $row->mobile_number 
				);
                $this->session->set_userdata('mysession', $array);
            	$data['msg']='Login Success'; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']='Login Failed'; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	}

	public function logout()
	{		
				$array= array(
					'client_id'	 , 
					'user_name'  , 
					'email'  , 
					'phone' 
				);
                $this->session->unset_userdata('mysession',  $array);
            	$this->login();
	}

	public function bookings()
	{		
        $Data['v_data']= $this->PPmo->getBookingList('');
        $Data['masters']="";        
        $this->loadViewMain('guest/booking_list',$Data);    
	} 

	function loadView($view,$data)
	{
	 	$this->load->view('public/public_header_login');	 	
		$this->load->view($view,$data);
		$this->load->view('public/public_footer');
	}
	function loadViewMain($view,$data)
	{
	 	$this->load->view('public/public_header');	 	
		$this->load->view($view,$data);
		$this->load->view('public/public_footer');
	}

}
