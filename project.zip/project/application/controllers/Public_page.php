<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Public_page extends CI_Controller {
    function __construct()
    {
		parent::__construct();
		$this->load->database();
		date_default_timezone_set( 'Asia/Kolkata' ); 
		$this->load->model("public_page_model","PPmo");
    }

	public function index()
	{
		$this->hotels();
    } 
    
	public function hotels()
	{
		$searchdata=$this->input->post('txtLocation');
		$datefrom=$this->input->post('datefrom');
		if(!isset($datefrom)) {$datefrom=date('d-m-Y');}
		$dateto=$this->input->post('dateto');		
		if(!isset($dateto)) 
		{
			$stop_date = new DateTime(date('d-m-Y')); 
			$stop_date->modify('+2 day');
			$dateto=$stop_date->format('d-m-Y');
		}
		$Data['lstlocation']=   $this->PPmo->getLocation();
		$Data['location']=   $this->input->post('txtLocation');
		$Data['lstRooms']=   $this->PPmo->getRoomsCount();
		$Data['rooms']=   $this->input->post('txtrooms');		
		$Data['datefrom']=$datefrom;
		$Data['dateto']=$dateto;
		$Data['searchdata']=$searchdata;
		$Data['v_data']= $this->PPmo->getHotelList($searchdata);
        $Data['masters']="";        
        $this->loadView('public/public_page_hotels',$Data);
	} 
	public function rooms()
	{
		//$UserName = $this->session->userdata['mysession']['user_name'];

		$searchdata=$this->input->post('hotel_id');
		$datefrom=$this->input->post('vdatefrom');
		if(!isset($datefrom)) {$datefrom=date('d-m-Y');}
		$dateto=$this->input->post('vdateto');		
		if(!isset($dateto)) 
		{
			$stop_date = new DateTime(date('d-m-Y')); 
			$stop_date->modify('+2 day');
			$dateto=$stop_date->format('d-m-Y');
			echo '~'.$datefrom . '~' . $dateto ;
		}
		//$Data['UserName']=   $UserName;
		$Data['lstRooms']=   $this->PPmo->getRoomsCount();
		$Data['rooms']=   $this->input->post('vrooms');		
		$Data['datefrom']=$datefrom;
		$Data['dateto']=$dateto;
		$Data['searchdata']=$searchdata;
		$Data['v_data_hotel']= $this->PPmo->getHotelDetails($searchdata);	
		$datefrom=date("d-m-Y", strtotime($datefrom));
		$dateto=date("d-m-Y", strtotime($dateto));
		//echo '~'.$datefrom . '~' . $dateto ;	
		$Data['v_data_rooms']= $this->PPmo->getRoomsList($searchdata,$datefrom,$dateto);
        $Data['masters']="";        
        $this->loadView('public/public_page_rooms',$Data);
	} 


	public function bookRoom()
	{
		$Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';  
		if(isset($this->session->userdata['mysession']['client_id']))
		{      
			$user_id = $this->session->userdata['mysession']['client_id'];  				
		}
		else
		{	$user_id = 0;	}

        If($user_id==0){$Err=1; $ErrCode.='7,'; $ErrMsg= ' Please login/Register as guest to book room.';}
		$room_id=$this->input->post('room_id');
		$hotel_id=$this->input->post('hotel_id');
		$from_date=$this->input->post('vdatefrom');
		$to_date=$this->input->post('vdateto');


        if($Err==0)
        {
			$date_from1=strtotime($from_date);
			$date_from=date("Y-m-d",$date_from1);
			$date_to1=strtotime($to_date);
			$date_to=date("Y-m-d",$date_to1);
			$result=$this->PPmo->bookRoom($room_id,$hotel_id,$date_from,$date_to,$user_id);
			if($result==1)
			{
				$data['msg']='Successfully Booked. Please view your booking page.'  ; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']=$result ; //'Error'  ; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	} 

	function loadView($view,$data)
	{
	 	$this->load->view('public/public_header');	 	
		$this->load->view($view,$data);
		$this->load->view('public/public_footer');
	}
}
