<?php


Class Guest_model Extends CI_Model 
{
    function __construct() 
    {
		parent::__construct();
        $this->load->database(); 
	}
      

	function getHotelList($searchdata)
	{	
        //$EnterpriseID = $this->session->userdata['mysession']['enterprise_id'];
        //$UserId = $this->session->userdata['mysession']['user_id'];

        $script1=" SELECT  * from  hotels " ;
        if(!($searchdata==""||$searchdata=="0"))
        {
            $script1=$script1 . " where location like '%". $searchdata ."%' ";
        }
        
        
        $script1=$script1 . " order by hotel_name " ;
        $rec = $this->db->query($script1);  
 
        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }

    function getHotelDetails($searchdata)
	{	
        //$EnterpriseID = $this->session->userdata['mysession']['enterprise_id'];
        //$UserId = $this->session->userdata['mysession']['user_id'];

        $script1=" SELECT  * from  hotels " ;
        if(!($searchdata==""||$searchdata=="0"))
        {
            $script1=$script1 . " where hotel_id =". $searchdata ."";
        }
        else
        {
            $script1=$script1 . " where hotel_id =0";
        }
        
        
        $script1=$script1 . " order by hotel_name " ;
        $rec = $this->db->query($script1);  
 
        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }

	function getRoomsList($searchdata)
	{	
        //$EnterpriseID = $this->session->userdata['mysession']['enterprise_id'];
        //$UserId = $this->session->userdata['mysession']['user_id'];

        $script1=" SELECT  * from  rooms " ;
        if(!($searchdata==""||$searchdata=="0"))
        {
            $script1=$script1 . " where hotel_id = '". $searchdata ."' ";
        }        
        
        $script1=$script1 . " order by room_number " ;
        $rec = $this->db->query($script1);  
 
        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }
    
    function guestSave($name,$phone,$email,$password)
    {
        $rec="0";

        $rec1 = $this->db->select('*') 
        ->where('login_name', $email)   
        ->get('client_users'); 

        if($rec1->num_rows() == 0) 
        { 
            $script2=" INSERT INTO `client_users` ( `login_name`,  `password`,  `full_name`,  `mobile_number`,  `email_id`, `status_id` )  " ;
            $script2 = $script2 . " VALUES ( '".$email."','".$password."','".$name."', '".$phone."', '".$email."', 1  ) ;" ;
            $rec = $this->db->query($script2);
            $rec = 1;
        }
        return $rec ; 
    }

    function LoginCheck($email,$password)
    {
        $rec="0";

        $rec1 = $this->db->select('*') 
        ->where('login_name', $email)  
        ->where('password', $password)   
        ->get('client_users'); 

        if($rec1->num_rows() == 0) 
        { 
            $rec1 = "No";
        }
        
        return $rec1 ; 
    }

    function getBookingList($searchdata)
	{	
        if(isset($this->session->userdata['mysession']['client_id']))
        {
            $UserId = $this->session->userdata['mysession']['client_id'];
        }else{
            $UserId = 0; 
        }

        $script1=" SELECT 1 as ttype, b.`booking_date` as bdate,b.`booking_id` bid,  b.`booking_id`,        b.`booking_date`,        b.`booking_number`,        c.`full_name`,        c.`email_id`, " ;
        $script1 = $script1 . " c.`mobile_number`,        h.`hotel_name`,        '' room_number,        '' room_date,        '' `total_rate`,        '' `total_tax`,        '' `total_amount` " ;
        $script1 = $script1 . " FROM booking b INNER JOIN client_users c ON b.`client_id`=c.`client_id` AND b.`client_id`= ".$UserId ;
        $script1 = $script1 . " INNER JOIN hotels h ON b.`hotel_id`=h.hotel_id " ;
        $script1 = $script1 . " UNION ALL  " ;
        $script1 = $script1 . " SELECT         2 as ttype, b.`booking_date` as bdate,b.`booking_id` bid, '',        '',        '',        '',        '',        '',        '',        b.`transaction_details`, " ;
        $script1 = $script1 . " r.`availability_date`,        t.`rate`,        t.`tax_amount`,        t.`total_amount` " ;
        $script1 = $script1 . " FROM booking b INNER JOIN client_users c ON b.`client_id`=c.`client_id` AND b.`client_id`= ".$UserId ;
        $script1 = $script1 . " INNER JOIN hotels h ON b.`hotel_id`=h.hotel_id " ;
        $script1 = $script1 . " INNER JOIN booking_transaction t ON b.`booking_id`=t.`booking_id` " ;
        $script1 = $script1 . " INNER JOIN room_availability_rate r ON t.`room_availability_id`=r.availability_id " ;
        $script1 = $script1 . " UNION ALL " ;
        $script1 = $script1 . " SELECT        3 as ttype, b.`booking_date` as bdate,b.`booking_id` bid,  '',        '',        '',        '',        '',        '',        '',        'Total Amount' room_number, " ;
        $script1 = $script1 . " '' room_date,        b.`total_rate`,        b.`total_tax`,        b.`total_amount` " ;
        $script1 = $script1 . " FROM booking b INNER JOIN client_users c ON b.`client_id`=c.`client_id` AND b.`client_id`= ".$UserId ;
        $script1 = $script1 . " INNER JOIN hotels h ON b.`hotel_id`=h.hotel_id " ;   
        
        $script1=$script1 . " order by bid,`bdate`,ttype,room_date " ;
        $rec = $this->db->query($script1);  
 
        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }

}
?>