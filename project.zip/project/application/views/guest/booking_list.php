
        <div class="wrapper wrapper-content">
            <div class="container">
            

                <div class="row">

                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>My Bookings</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-sm-9 m-b-xs">
                                        <div data-toggle="buttons" class="btn-group">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">                                       
                                        
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>

                                            <th>#</th>
                                            <th>Booking Number / Date</th>
                                            <th>Customer Details </th>
                                            <th>Hotel </th>
                                            <th>Room </th>
                                            <th>Date </th>
                                            <th>Rate</th>
                                            <th>Tax</th>
                                            <th>Total</th>
                                        </tr>
                                        </thead>
                                        <tbody>
<?php
	if($v_data!= "No")
    {
        $loop = 0;
    	foreach ($v_data->result() as $r)
     	{ 
     	    $loop = $loop + 1;
?>
                                        <tr>
                                            <td><?php echo $loop; ?></td>
                                            <td><?php echo $r->booking_number . '<br>' . $r->booking_date; ?></td>
                                            <td><?php echo $r->full_name . '<br>' . $r->email_id; ?></td>
                                            <td><?php echo $r->hotel_name; ?></td>
                                            <td><?php echo $r->room_number; ?></td>
                                            <td><?php echo $r->room_date; ?></td>
                                            <td><?php echo $r->total_rate; ?></td>
                                            <td><?php echo $r->total_tax; ?></td>
                                            <td><?php echo $r->total_amount; ?></td>                                            
                                        </tr>
<?php
        }
    } else {  echo "<tr> <td colspan=9>No data available/Please login</td></tr>";}
?>                                     
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        