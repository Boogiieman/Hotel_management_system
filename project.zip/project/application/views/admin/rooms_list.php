

        <?php
            if(!isset($hotelname))
            {
                $hotelname="0";
            }
                       
        ?>

        <div class="wrapper wrapper-content">
            <div class="container">
            

                <div class="row">

                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>List of Rooms</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <form class="m-t" role="form" action="<?php echo base_url(); ?>index.php/admin/managerooms" method="post">
                                    <div class="row">
                                        <div class="col-sm-8 m-b-xs">
                                            <div data-toggle="buttons" class="btn-group"> 
                                                    <label class="font-noraml">Select Hotel</label>                                                
                                                    <?php
                                                        $js ='id="txtHotel" class="form-control m-b"';
                                                        $DefaultValue = set_value('txtHotel',$hotelname); 
                                                        echo   form_dropdown('txtHotel',$lsthotels ,$DefaultValue,$js);
                                                    ?>                                            
                                            </div>
                                        </div>
                                        <div class="col-sm-2 m-b-xs">
                                            <button type="submit" class="btn btn-primary full-width m-b">Search</button>
                                        </div>
                                        <div class="col-sm-2">
                                            <button type="button" class="btn btn-primary full-width m-b" onclick="postPage('0')">Add Rooms</button>
                                        </div>
                                    </div>
                                </form>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>

                                            <th>#</th>
                                            <th>Location </th>
                                            <th>Name of Hotel </th>
                                            <th>Room Number </th>
                                            <th>Room Type </th>
                                            <th>Adults </th>
                                            <th>Childs </th>
                                            <th>Image </th>
                                            <th>Status </th>
                                            <th>Action </th>
                                        </tr>
                                        </thead>
                                        <tbody>
<?php
	if($v_data!= "No")
    {
        $loop = 0;
    	foreach ($v_data->result() as $r)
     	{ 
     	    $loop = $loop + 1;
?>
                                        <tr>
                                            <td><?php echo $loop ; ?></td>
                                            <td><?php echo $r->location; ?></td>
                                            <td><?php echo $r->hotel_name; ?></td>
                                            <td><?php echo $r->room_number; ?></td>
                                            <td><?php echo $r->room_type; ?></td>
                                            <td><?php echo $r->no_of_adults; ?></td>
                                            <td><?php echo $r->no_of_childs; ?></td>
                                            <td><?php echo $r->image1; ?></td>
                                            <td><?php echo $r->status_id; ?></td>
                                            <td><div class="clearfix"><a class="btn btn-xs btn-info"  onclick="postPage(<?php echo $r->room_id; ?>);"> <i class="fa fa-edit"></i></a>
                                                <a class="btn btn-xs btn-info" onclick="DeletePage(<?php echo $r->room_id; ?>);"> <i class="fa fa-close"></i></a></div></td>
                                        </tr>
<?php
        }
    } 
?>                                     
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        <form method="post" accept-charset="utf-8" action="<?php echo base_url(); ?>index.php/admin/modifyroom" id="form1" name="form1">   
            <input type="hidden" name="hotel_id" id="hotel_id">
            <input type="hidden" name="room_id" id="room_id">
         </form>

    <script>
        function postPage(room_id) {
                hotel_id=$('#txtHotel').val();
                $('#hotel_id').val(hotel_id);
                $('#room_id').val(room_id);
                document.getElementById("form1").submit();
        }        
    </script>
        