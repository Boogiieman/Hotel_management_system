        <?php
            if(!isset($roomname))
            {
                $roomname="0";
            }
                       
        ?>
        <div class="wrapper wrapper-content">
            <div class="container">
            

                <div class="row">

                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Room Availabilty</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <form class="m-t" role="form" action="<?php echo base_url(); ?>index.php/admin/manageavailability" method="post">
                                    <div class="row">
                                            <div class="col-sm-8 m-b-xs">
                                                <div data-toggle="buttons" class="btn-group"> 
                                                        <label class="font-noraml">Select Hotel room</label>                                                
                                                        <?php
                                                            $js ='id="txtRoom" class="form-control m-b"';
                                                            $DefaultValue = set_value('txtRoom',$roomname); 
                                                            echo   form_dropdown('txtRoom',$lstrooms ,$DefaultValue,$js);
                                                        ?>                                            
                                                </div>
                                            </div>
                                            <div class="col-sm-2 m-b-xs">
                                                <button type="submit" class="btn btn-primary full-width m-b">Search</button>
                                            </div>
                                            <div class="col-sm-2">
                                                <button type="button" class="btn btn-primary full-width m-b" onclick="postPage('0');">Add Room Rate</button>
                                            </div>
                                    </div>
                                </form>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>

                                            <th>#</th>
                                            <th>Hotel</th>
                                            <th>Room Number</th>
                                            <th>Room Type </th>
                                            <th>Date </th>
                                            <th>Rate </th>
                                            <th>Tax</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
<?php
	if($v_data!= "No")
    {
        $loop = 0;
    	foreach ($v_data->result() as $r)
     	{ 
     	    $loop = $loop + 1;
?>
                                        <tr>
                                            <td><?php echo $loop; ?></td>
                                            <td><?php echo $r->hotel_name ; ?></td>
                                            <td><?php echo $r->room_number ; ?></td>
                                            <td><?php echo $r->room_type; ?></td>
                                            <td><?php echo $r->availability_date; ?></td>
                                            <td><?php echo $r->rate; ?></td>
                                            <td><?php echo $r->tax_amount; ?></td>
                                            <td><?php echo $r->total_amount; ?></td>
                                            <?php 
                                                if($r->booking_status==0){$rstatus="Vacant";}
                                                if($r->booking_status==1){$rstatus="Booked";}
                                            ?>
                                            <td><?php echo $rstatus; ?></td> 
                                            <td><div class="clearfix"><a class="btn btn-xs btn-info" onclick="postPage(<?php echo $r->availability_id; ?>);"> <i class="fa fa-edit"></i></a> </td>                                         
                                        </tr>
<?php
        }
    } else {  echo "<tr> <td colspan=9>No data available</td></tr>";}
?>                                     
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        <form method="post" accept-charset="utf-8" action="<?php echo base_url(); ?>index.php/admin/modifyavailability" id="form1" name="form1">   
            <input type="hidden" name="availability_id" id="availability_id">
            <input type="hidden" name="room_id" id="room_id">
         </form>

        <script>
        function postPage(availability_id) {
                $('#availability_id').val(availability_id);
                room_id=$('#txtRoom').val();
                $('#room_id').val(room_id);
                document.getElementById("form1").submit();
        }        
    </script>