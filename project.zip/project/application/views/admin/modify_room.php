        <?php
            if(!isset($location))
            {
                $location="0";
            }  
            if($v_data!='No')   
            {
                $hotel_name=$v_data->hotel_id;
                $hotel_id=$v_data->hotel_id;
                $room_id=$v_data->room_id;
                $roomnumber=$v_data->room_number;
                $facilities=$v_data->facilities;
                $roomtype=$v_data->room_type;
                $noofadults=$v_data->no_of_adults;
                $noofchild=$v_data->no_of_childs;
                $image1=$v_data->image1;
            }   
            else
            {
                $hotel_name=$mhotel_id;
                $hotel_id=$mhotel_id;
                $room_id=0;
                $roomnumber="";
                $facilities="";
                $roomtype="";
                $noofadults=0;
                $noofchild=0;
                $image1="";
            }    
        ?>
        <div class="wrapper wrapper-content">
            <div class="container">
            

                <div class="row">

                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Modify Room details</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-sm-9 m-b-xs">
                                        <div data-toggle="buttons" class="btn-group">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                       
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <form class="m-t" role="form" method="post" name="formdata" id="formdata">
                                        <div class="col-lg-12">
                                            <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="font-noraml">Hotel Name</label>
                                                            <label class="font-noraml"><?php echo $hotel_id; ?></label>
                                                            <input type="hidden" class="input-sm form-control" name="hotel_id" id="hotel_id" value="<?php echo $hotel_id; ?>"/>
                                                        </div>
                                            </div>
                                            <div class="col-lg-8">                        
                                                        <div class="form-group">
                                                            <label class="font-noraml"></label>                                                         
                                                            <input type="hidden" class="input-sm form-control" name="room_id" id="room_id" value="<?php echo $room_id; ?>"/>
                                                        </div>                            
                                            </div>
                                            <div class="col-lg-6">                        
                                                        <div class="form-group">
                                                            <label class="font-noraml">Room Number</label>                                                         
                                                            <input type="text" class="input-sm form-control" name="troomnumber" id="troomnumber" value="<?php echo $roomnumber; ?>"/>
                                                        </div>                            
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Facilities</label>
                                                                <input type="text" class="input-sm form-control" name="tfacilities" id="tfacilities" value="<?php echo $facilities; ?>"/> 
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Room Type</label>
                                                                <input type="text" class="input-sm form-control" name="troomtype" id="troomtype" value="<?php echo $roomtype; ?>"/> 
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">No of Adults allowed</label>
                                                                <input type="text" class="input-sm form-control" name="tnoofadults" id="tnoofadults" value="<?php echo $noofadults; ?>"/>
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">No of Childrens allowed</label>
                                                                <input type="text" class="input-sm form-control" name="tnoofchild" id="tnoofchild" value="<?php echo $noofchild; ?>"/>
                                                        </div>                                                
                                            </div>                                            
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Image 1</label>                                                            
                                                                <input type="text" class="input-sm form-control" name="timage1" id="timage1" value="<?php echo $image1; ?>"/> 
                                                        </div>                                                
                                            </div>                                            
                                    </form>
                                </div>
                                <div class="col-lg-12">
                                            <div class="col-lg-2">                        
                                                        </br><button type="button" class="btn btn-primary full-width m-b" onclick="backpage();">Cancel</button>                          
                                            </div>
                                            <div class="col-lg-2">  
                                                        </br><button type="button" class="btn btn-primary full-width m-b" onclick="saveDetails();">Save</button>                            
                                            </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        <form method="post" accept-charset="utf-8" action="<?php echo base_url(); ?>index.php/admin/managerooms" id="form1" name="form1">
        </form>
    <script>

        function saveDetails()
        { 
            var r = confirm("Are you sure you want to save this data?");
            if (r == true) 
            {
                var serializedData = $('#formdata').serialize();  
                $.ajax({
                    type:"POST",
                    dataType: "json",
                    data: serializedData,
                    url:"<?php echo base_url(); ?>index.php/admin/saveroom",                                    
                    success:function(data)
                    {
                        alert(data.msg);
                        //$('#result').html(data.msg);
                    },
                    error: function(jqXHR, textStatus, errorThrown) 
                    {  
                        $("#msg").html("ERROR:::::" + jqXHR.responseText);
                        alert("error:" + jqXHR.responseText);	
                    }
                });
            }
        }

        function backpage() {                
                document.getElementById("form1").submit();
        }
    </script>