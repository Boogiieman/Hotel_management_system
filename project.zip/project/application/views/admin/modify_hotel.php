        <?php
            if(!isset($location))
            {
                $location="0";
            }  
            if($v_data!='No')   
            {
                $hotel_id=$v_data->hotel_id;
                $location=$v_data->location;
                $hotel_name=$v_data->hotel_name;
                $address1=$v_data->address1;
                $address2=$v_data->address2;
                $category=$v_data->category;
                $phone_number=$v_data->phone_number;
                $email=$v_data->email;
                $website=$v_data->website;
                $facilities=$v_data->facilities;
                $conditions=$v_data->conditions;
                $image1=$v_data->image1;
            }   
            else
            {
                $hotel_id=0;
                $location="";
                $hotel_name="";
                $address1="";
                $address2="";
                $category="";
                $phone_number="";
                $email="";
                $website="";
                $facilities="";
                $conditions="";
                $image1="";
            }    
        ?>
        <div class="wrapper wrapper-content">
            <div class="container">
            

                <div class="row">

                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Modify Hotel details</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-sm-9 m-b-xs">
                                        <div data-toggle="buttons" class="btn-group">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                       
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <form class="m-t" role="form" method="post" name="formdata" id="formdata">
                                        <div class="col-lg-12">
                                            <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="font-noraml">Location</label>
                                                            <input type="text" class="input-sm form-control" name="tlocation" id="tlocation" value="<?php echo $location; ?>"/>
                                                        </div>
                                            </div>
                                            <div class="col-lg-8">                        
                                                        <div class="form-group">
                                                            <label class="font-noraml"></label>                                                         
                                                            <input type="hidden" class="input-sm form-control" name="hotel_id" id="hotel_id" value="<?php echo $hotel_id; ?>"/>
                                                        </div>                            
                                            </div>
                                            <div class="col-lg-6">                        
                                                        <div class="form-group">
                                                            <label class="font-noraml">Name of Hotel</label>                                                         
                                                            <input type="text" class="input-sm form-control" name="thotel_name" id="thotel_name" value="<?php echo $hotel_name; ?>"/>
                                                        </div>                            
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Address 1</label>
                                                                <input type="text" class="input-sm form-control" name="taddress1" id="taddress1" value="<?php echo $address1; ?>"/> 
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Address 2</label>
                                                                <input type="text" class="input-sm form-control" name="taddress2" id="taddress2" value="<?php echo $address2; ?>"/> 
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Category</label>
                                                                <input type="text" class="input-sm form-control" name="tcategory" id="tcategory" value="<?php echo $category; ?>"/>
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Phone Number</label>
                                                                <input type="text" class="input-sm form-control" name="tphone_number" id="tphone_number" value="<?php echo $phone_number; ?>"/>
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">e Mail</label>
                                                                <input type="text" class="input-sm form-control" name="temail" id="temail" value="<?php echo $email; ?>"/>
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Web site</label>
                                                                <input type="text" class="input-sm form-control" name="twebsite" id="twebsite" value="<?php echo $website; ?>"/>
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Facilities</label>
                                                                <input type="text" class="input-sm form-control" name="tfacilities" id="tfacilities" value="<?php echo $facilities; ?>"/>
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Conditions</label>
                                                                <input type="text" class="input-sm form-control" name="tconditions" id="tconditions" value="<?php echo $conditions; ?>"/> 
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Image 1</label>                                                            
                                                                <input type="text" class="input-sm form-control" name="timage1" id="timage1" value="<?php echo $image1; ?>"/> 
                                                        </div>                                                
                                            </div>                                            
                                    </form>
                                </div>
                                <div class="col-lg-12">
                                            <div class="col-lg-2">                        
                                                        </br><button type="button" class="btn btn-primary full-width m-b" onclick="backpage();">Cancel</button>                          
                                            </div>
                                            <div class="col-lg-2">  
                                                        </br><button type="button" class="btn btn-primary full-width m-b" onclick="saveDetails();">Save</button>                            
                                            </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        <form method="post" accept-charset="utf-8" action="<?php echo base_url(); ?>index.php/admin/managehotels" id="form1" name="form1">
        </form>
    <script>

        function saveDetails()
        { 
            var r = confirm("Are you sure you want to save this data?");
            if (r == true) 
            {
                var serializedData = $('#formdata').serialize();  
                $.ajax({
                    type:"POST",
                    dataType: "json",
                    data: serializedData,
                    url:"<?php echo base_url(); ?>index.php/admin/savehotel",                                    
                    success:function(data)
                    {
                        alert(data.msg);
                        //$('#result').html(data.msg);
                    },
                    error: function(jqXHR, textStatus, errorThrown) 
                    {  
                        $("#msg").html("ERROR:::::" + jqXHR.responseText);
                        alert("error:" + jqXHR.responseText);	
                    }
                });
            }
        }

        function backpage() {                
                document.getElementById("form1").submit();
        }
    </script>