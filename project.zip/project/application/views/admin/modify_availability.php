        <?php
            if(!isset($location))
            {
                $location="0";
            }  
            if($v_data!='No')   
            {
                $room=$mroom_details->room_number;
                $room_id=$v_data->room_id;
                $hotel_id=$v_data->hotel_id;
                $availability_id=$v_data->availability_id;
                $availability_date=$v_data->availability_date;
                $rate=$v_data->rate;
                $tax_amount=$v_data->tax_amount;
                $total_amount=$v_data->total_amount;
            }   
            else
            {
                $room="";
                $room_id=$mroom_id;
                $hotel_id=$mroom_details->hotel_id;
                $availability_id=0;
                $availability_date="";
                $rate=0;
                $tax_amount=0;
                $total_amount=0;
            }    
        ?>
        <div class="wrapper wrapper-content">
            <div class="container">
            

                <div class="row">

                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Room Availability Settings</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-sm-9 m-b-xs">
                                        <div data-toggle="buttons" class="btn-group">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                       
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <form class="m-t" role="form" method="post" name="formdata" id="formdata">
                                        <div class="col-lg-12">
                                            <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="font-noraml">Room : </label>
                                                            <label class="font-noraml"><?php echo $room; ?> </label>
                                                            <input type="hidden" class="input-sm form-control" name="room_id" id="room_id" value="<?php echo $room_id; ?>"/>
                                                            <input type="hidden" class="input-sm form-control" name="hotel_id" id="hotel_id" value="<?php echo $hotel_id; ?>"/>
                                                        </div>
                                            </div>
                                            <div class="col-lg-8">                        
                                                        <div class="form-group">
                                                            <label class="font-noraml"></label>                                                         
                                                            <input type="hidden" class="input-sm form-control" name="availability_id" id="availability_id" value="<?php echo $availability_id; ?>"/>
                                                        </div>                            
                                            </div>
                                            <div class="col-lg-6">                        
                                                        <div class="form-group">
                                                            <label class="font-noraml">Transaction Date (YYYY-MM-DD)</label>                                                         
                                                            <input type="text" class="input-sm form-control" name="tavailability_date" id="tavailability_date" value="<?php echo $availability_date; ?>"/>
                                                        </div>                            
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Rate</label>
                                                                <input type="text" class="input-sm form-control" name="trate" id="trate" value="<?php echo $rate; ?>"/> 
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Tax Amount</label>
                                                                <input type="text" class="input-sm form-control" name="ttax_amount" id="ttax_amount" value="<?php echo $tax_amount; ?>"/> 
                                                        </div>                                                
                                            </div>
                                            <div class="col-lg-6">                                                
                                                        <div class="form-group" id="data_5">
                                                            <label class="font-noraml">Total Amount</label>
                                                                <input type="text" class="input-sm form-control" name="ttotal_amount" id="ttotal_amount" value="<?php echo $total_amount; ?>"/>
                                                        </div>                                                
                                            </div>
                                                                                      
                                    </form>
                                </div>
                                <div class="col-lg-12">
                                            <div class="col-lg-2">                        
                                                        </br><button type="button" class="btn btn-primary full-width m-b" onclick="backpage();">Cancel</button>                          
                                            </div>
                                            <div class="col-lg-2">  
                                                        </br><button type="button" class="btn btn-primary full-width m-b" onclick="saveDetails();">Save</button>                            
                                            </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        <form method="post" accept-charset="utf-8" action="<?php echo base_url(); ?>index.php/admin/manageavailability" id="form1" name="form1">
        </form>
    <script>

        function saveDetails()
        { 
            var r = confirm("Are you sure you want to save this data?");
            if (r == true) 
            {
                var serializedData = $('#formdata').serialize();  
                $.ajax({
                    type:"POST",
                    dataType: "json",
                    data: serializedData,
                    url:"<?php echo base_url(); ?>index.php/admin/saveavailability",                                    
                    success:function(data)
                    {
                        alert(data.msg);
                        //$('#result').html(data.msg);
                    },
                    error: function(jqXHR, textStatus, errorThrown) 
                    {  
                        $("#msg").html("ERROR:::::" + jqXHR.responseText);
                        alert("error:" + jqXHR.responseText);	
                    }
                });
            }
        }

        function backpage() {                
                document.getElementById("form1").submit();
        }
    </script>