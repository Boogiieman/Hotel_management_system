<div class="wrapper wrapper-content">
	<div class="row">
		<div class="col-lg-12">
			<div class="row">
				<div class="col-lg-12">
					<div class="ibox float-e-margins">
						<div class="ibox-title">
							<h5>
								Enter OP Details
							</h5>
							<div class="ibox-tools">
								<a class="collapse-link">
								<i class="fa fa-chevron-up"></i>
								</a>
								<a class="close-link">
								<i class="fa fa-times"></i>
								</a>
							</div>
						</div>
						<div class="ibox-content">
							<div class="row">
								<div class="col-lg-5">
									<dl class="dl-horizontal">
										<dt>
											Name:
										</dt>
										<dd>
											Sunil S
										</dd>
										<dt>
											OP No:
										</dt>
										<dd>
											2121
										</dd>
										<dt>
											Age:
										</dt>
										<dd>
											40
										</dd>
										<dt>
											Gender:
										</dt>
										<dd>
											Male
										</dd>
									</dl>
								</div>
								<div class="col-lg-7" id="cluster_info">
									<dl class="dl-horizontal">
										<dt>
											Date:
										</dt>
										<dd>
											16.08.2019
										</dd>
										<dt>
											Mobile:
										</dt>
										<dd>
											9895554814
										</dd>
										<dt>
											Address:
										</dt>
										<dd>
											Malel , Clappana
										</dd>
									</dl>
								</div>
							</div>
							<div class="row">
							 
                                
                                <div class="col-lg-9 animated fadeInRight" id="divDiagnosis">
                                   <form method="get" class="form-horizontal">
                                        <h3 style="padding-left: 25%;" class="text-warning">Diagnosis Report</h3>
    									<div class="row">
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">Diagnosis  </label> 
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" ></textarea> 
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">Pre-decease  </label> 
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" ></textarea> 
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">Farter Actions   </label> 
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" ></textarea> 
                                                </div>
                                            </div> 
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <div class="col-sm-4 col-sm-offset-2">
                                                    <button class="btn btn-white" type="submit">Cancel</button>
                                                    <button class="btn btn-primary" type="submit">Save  </button>
                                                </div>
                                            </div>
                                    
    									</div>
                                    </form>
								</div>
                                
                                <div class="col-lg-9 animated fadeInRight" style="display: none;" id="divPharmacy">
                                   <form method="get" class="form-horizontal">
                                     <h3 style="padding-left: 25%;" class="text-warning">Pharmacy Report</h3>
    									<div class="row">
                                             
    									</div>
                                    </form>
								</div>
                                <div class="col-lg-9 animated fadeInRight" style="display: none;" id="divObservation">
                                   <form method="get" class="form-horizontal">
                                     <h3 style="padding-left: 25%;" class="text-warning">Observation </h3>
    									<div class="row">
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">Observation Note  </label> 
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" ></textarea> 
                                                </div>
                                            </div> 
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <div class="col-sm-4 col-sm-offset-2">
                                                    <button class="btn btn-white" type="submit">Cancel</button>
                                                    <button class="btn btn-primary" type="submit">Save  </button>
                                                </div>
                                            </div>
                                            
    									</div>
                                    </form>
								</div>
                                <div class="col-lg-9 animated fadeInRight" style="display: none;" id="divLab">
                                   <form method="get" class="form-horizontal">
                                     <h3 style="padding-left: 25%;" class="text-warning">Lab Report</h3>
    									<div class="row">
                                             
    									</div>
                                    </form>
								</div>
                                <div class="col-lg-9 animated fadeInRight" style="display: none;" id="divIP">
                                   <form method="get" class="form-horizontal">
                                     <h3 style="padding-left: 25%;" class="text-warning">Move to IP</h3>
    									<div class="row">
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">IP Note  </label> 
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" ></textarea> 
                                                </div>
                                            </div> 
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <div class="col-sm-4 col-sm-offset-2">
                                                    <button class="btn btn-white" type="submit">Cancel</button>
                                                    <button class="btn btn-primary" type="submit">Save  </button>
                                                </div>
                                            </div>
                                            
    									</div>
                                    </form>
								</div>
                                <div class="col-lg-9 animated fadeInRight" style="display: none;" id="divOtherHsp">
                                   <form method="get" class="form-horizontal">
                                     <h3 style="padding-left: 25%;" class="text-warning">Transfer To Other Hospital Report</h3>
    									<div class="row">
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">Reference Note  </label> 
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" ></textarea> 
                                                </div>
                                            </div> 
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <div class="col-sm-4 col-sm-offset-2">
                                                    <button class="btn btn-white" type="submit">Cancel</button>
                                                    <button class="btn btn-primary" type="submit">Save  </button>
                                                </div>
                                            </div>
                                            
    									</div>
                                    </form>
								</div>
                                 
                               
                               
                               <div class="col-lg-3 pull-right fixed-bottom"  >
									<div class="ibox float-e-margins">
										<div class="ibox-content">
											<div class="file-manager">
												<h5>
													Other Action
												</h5>
												<ul class="folder-list" style="padding: 0">
													<li>
														<a href="#"  class="CallPage" Call="PH"><i class="fa fa-medkit "></i> Add To Medical Priscription</a>
													</li>
													<li>
														<a href="#"  class="CallPage" Call="OB"><i class="fa fa-wheelchair"></i> Observation</a>
													</li> 
													<li>
														<a href="#"  class="CallPage" Call="LB"><i class="fa fa-slideshare"></i> Add To LAB Items</a>
													</li>
													<li>
														<a href="#" class="CallPage" Call="IP"><i class="fa fa-user-md"></i> Move To IP</a>
													</li>
													<li>
														<a href="#" class="CallPage" Call="OH"><i class="fa fa-hospital-o"></i> Transfer to Other Hospital</a>
													</li>
													<li id="BtnDiagnosis" style="display: none;">
														<a href="#" class="CallPage" Call="DG"><i class="fa fa-stethoscope"></i> Diagnosis Screen</a>
													</li>
													 
												</ul> 
												<div class="clearfix">
												</div>
											</div>
										</div>
									</div>
								</div>
                                                                 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
 
<!--Popup1-->

 <div class="modal inmodal fade" id="Pharmacy" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg"  >
        <div class="modal-content animated bounceInRight">
            <div class="modal-header"> 
                <h4 class="modal-title"> Instalment Details</h4>
            </div>
            <div class="modal-body" id="divReceipt" style="min-height: 270px;">
                  
            </div>
            <div class="modal-footer"> 
                <button type="button" class="btn primary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<style>
.pull-right {
  float: right !important; 
}
</style>
<script>
 

$(function () {
    
    
     $(".CallPage").click(function () { 
       var Sel =  $(this).attr('Call'); 
       AllHide(); 
     
       switch(Sel) {
            case 'PH':
                $("#divPharmacy").show(1000);
            break;
            
            case 'OB':
                $("#divObservation").show(1000);
            break;
            
            case 'LB':
                $("#divLab").show(1000);
            break;
            
            case 'IP':
                $("#divIP").show(1000);
            break;
            
            case 'OH':
                $("#divOtherHsp").show(1000);
            break;
            
            case 'DG':
                $("#divDiagnosis").show(1000);
                $("#BtnDiagnosis").hide(1000);
            break;
       } 
       
    });
    
    function AllHide(){
        $("#divDiagnosis").hide(1000);
        $("#divPharmacy").hide(1000);
        $("#divObservation").hide(1000);
        $("#divObservation").hide(1000);
        $("#divLab").hide(1000);
        $("#divIP").hide(1000);
        $("#divOtherHsp").hide(1000); 
        $("#BtnDiagnosis").show(1000); 
    }
    
})
</script>