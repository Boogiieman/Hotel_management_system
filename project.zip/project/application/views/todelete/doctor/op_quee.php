 
   <div class="wrapper wrapper-content">  

                <div class="row"> 

                    <div class="col-lg-12">
 
                       <div class="row">
                                <div class="col-lg-5">
                                    <dl class="dl-horizontal"> 
                                        <dt>Dr Name:</dt> <dd>Alex Smith</dd> 
                                    </dl>
                                </div>
                                <div class="col-lg-7" id="cluster_info">
                                    <dl class="dl-horizontal">

                                        <dt>Date:</dt> <dd>16.08.2019  </dd> 
                                         
                                    </dl>
                                </div>
                            </div> 
                        
                        
                        
                        <div class="row" id="divMain">
                            <div class="col-lg-12">
                                <div class="ibox float-e-margins">
                                    <div class="ibox-title">
                                        <h5> OP Quee List</h5>
                                        <div class="ibox-tools">
                                            <a class="collapse-link">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a class="close-link">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="ibox-content">

                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table table-hover margin bottom" id="ItemTbl">
                                                
                                                    <thead>
                                                    <tr>
                                                        <th style="width: 15%" class="text-left">OP No.</th>
                                                        <th>Name</th>
                                                        <th class="text-center">Mobile Number</th>
                                                        <th class="text-center">Token No.</th>
                                                    </tr>
                                                    </thead>
                                                    
                                                    <tbody>
                                                    
                                                    <tr>
                                                        <td class="text-left">2121</td>
                                                        <td> Sunil S </td>
                                                        <td class="text-center small">9898989898</td>
                                                        <td class="text-center"><span class="label label-primary">35</span></td>

                                                    </tr>  
                                                    
                                                    <tr>
                                                        <td class="text-left">3232</td>
                                                        <td> Jaymon D</td>
                                                        <td class="text-center small">9898989898</td>
                                                        <td class="text-center"><span class="label label-primary">37</span></td>

                                                    </tr> 
                                                    
                                                    
                                                    <tr>
                                                        <td class="text-left">1212</td>
                                                        <td> Narayanan N G</td>
                                                        <td class="text-center small">9898989898</td>
                                                        <td class="text-center"><span class="label label-primary">39</span></td>

                                                    </tr> 
                                                    
                                                    
                                                    <tr>
                                                        <td class="text-left">3244</td>
                                                        <td> Jayan </td>
                                                        <td class="text-center small">9898989898</td>
                                                        <td class="text-center"><span class="label label-primary">43</span></td>

                                                    </tr> 
                                                    
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="col-lg-6">
                                                <div id="world-map" style="height: 300px;"></div>
                                            </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>


                </div>
                </div>
                 <script>
 $(function() { 
  
    $('#ItemTbl tbody').on('click', 'tr', function () {
       // alert();
        $.ajax ({
        			type: "POST",
        			url: "<?php echo base_url();?>index.php/Doctor/OPEntry",
        			data: {},
        			dataType:'json' ,
                     success: function (data) {   
                          $('#divMain').html(data);
        			   }
    	        });
    });
    
    
    	 
 });
        
   
    </script>