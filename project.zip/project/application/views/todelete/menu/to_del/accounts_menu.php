				<li class="active">
                    <a href="<?php echo base_url(); ?>index.php/welcome"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span> </a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-cubes"></i> <span class="nav-label">Users</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">                        
                        <li><a href="<?php echo base_url(); ?>index.php/users">Manage</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/users/resetpassword">Reset Password</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-envelope"></i> <span class="nav-label">Investor</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="<?php echo base_url(); ?>index.php/Investor">Manage</a></li> 
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/ledger">Ledger</a></li>
					<!--	<li><a href="#">Profile List</a></li> -->
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-envelope"></i> <span class="nav-label">Collection Reports</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/InvestorCollection">Investor</a></li> 
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/UnitCollection">Unit</a></li> 
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/AreaCollection">Area</a></li> 
                    </ul>
                </li>
				<li>
                    <a href="#"><i class="fa fa-money"></i> <span class="nav-label">Accounts</span><span class="fa arrow"></span><span class="label label-info pull-right">Demo</span></a>
                    <ul class="nav nav-second-level">                        
                        <li><a href="<?php echo base_url(); ?>index.php/Accounts/AddPayment">Payment voucher</a></li> 
                        <li><a href="<?php echo base_url(); ?>index.php/Accounts/AddReceipt">Receipt voucher</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/accounts/InvestmentRefund">Investment Refund</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/accounts/DividendPosting">Dividend Entry</a></li>						
						<li><a href="<?php echo base_url(); ?>index.php/accounts/AccountLedger">Account Ledger</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/accounts/accounttree">Account Head</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-globe"></i> <span class="nav-label">Reports</span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="<?php echo base_url(); ?>index.php/welcome">Receipts</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/welcome">Expenditure</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/InvProfile">Investors</a></li>
                                                                   
                    </ul>
                </li>
				<li>
                    <a href="#"><i class="fa fa-envelope"></i> <span class="nav-label">My Investments</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/MyLedger">Ledger</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/MyProfile">Update Profile</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/Welcome/InvDB">Dashboard</a></li>
                    </ul>
                </li>				