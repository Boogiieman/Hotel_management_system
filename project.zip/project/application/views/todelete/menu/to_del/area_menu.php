				<li class="active">
                    <a href="<?php echo base_url(); ?>index.php/welcome"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span> </a>
                </li>
				<li>
                    <a href="#"><i class="fa fa-envelope"></i> <span class="nav-label">Investor</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
						<li><a href="<?php echo base_url(); ?>index.php/Investor/InvProfile">Profile List</a></li>
                    </ul>
                </li>
               	<li>
                    <a href="#"><i class="fa fa-envelope"></i> <span class="nav-label">Transaction</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/Payment">New Contribution</a></li> 
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/PendingApproval">Authorise Unit Contributions</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-globe"></i> <span class="nav-label">Reports</span><span class="label label-info pull-right">NEW</span></a>
                    <ul class="nav nav-second-level">
                       <li><a href="<?php echo base_url(); ?>index.php/Investor/TransLog">Transaction Logs</a></li> 
					   <li><a href="<?php echo base_url(); ?>index.php/Investor/AuthorisedTran">Contribution-Unit wise</a></li> 
                    </ul>
                </li>
				<li>
                    <a href="#"><i class="fa fa-envelope"></i> <span class="nav-label">My Investments</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/MyLedger">Ledger</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/Investor/MyProfile">Update Profile</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/Welcome/InvDB">Dashboard</a></li>
                    </ul>
                </li>				