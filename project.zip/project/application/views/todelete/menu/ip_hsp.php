 <li class="active">
          <a href="<?php echo base_url(); ?>index.php/welcome"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span> </a>
  </li>

                <li>

                    <a href="#"><i class="fa fa-bank"></i> <span class="nav-label"> Booking (Room/OT)</span> </a>
 
                </li>

                <li>
                    <a href="#"><i class="fa fa-cubes"></i> <span class="nav-label">  Bills</span>  </a>
                </li>
                <li>    
                    <a href="#"><i class="fa fa-child"></i> <span class="nav-label">  Result </span> </a>
                 </li>            
                <li>    
                    <a href="#"><i class="fa fa-child"></i> <span class="nav-label">  Diagnostics Reports </span> </a>
                 </li>            

                <li>
                    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">  Reports </span> </a>
                 </li> 