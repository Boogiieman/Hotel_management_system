<li class="active">

                    <a href="<?php echo base_url(); ?>index.php/welcome"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span> </a>

                </li>
                <li>
                    <a href="#"><i class="fa fa-cubes"></i> <span class="nav-label">Users</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">                        
                        <li><a href="<?php echo base_url(); ?>index.php/users">Manage</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/users/resetpassword">Reset Password</a></li>
                    </ul>
                </li> 
                <li>

                    <a href="#"><i class="fa fa-bar-chart-o"></i> <span class="nav-label">Menu1</span><span class="fa arrow"></span></a>

                    <ul class="nav nav-second-level">

                        <li><a href="<?php echo base_url(); ?>index.php/">Menu1.1</a></li>

                        <li><a href="<?php echo base_url(); ?>index.php/">Menu1.2</a></li>                                           

                    </ul>

                </li>

              

                <li>

                    <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Settings</span><span class="fa arrow"></span></a>

                    <ul class="nav nav-second-level">

                        <li><a href="<?php echo base_url(); ?>index.php/">Menu2.1</a></li>

                    </ul>

                </li>

                <li>

                    <a href="#"><i class="fa fa-globe"></i> <span class="nav-label">Reports</span><span class="label label-info pull-right">NEW</span></a>

                    <ul class="nav nav-second-level">


                        <li><a href="<?php echo base_url(); ?>index.php/Investor/AreaCollection">Menu3.1</a></li> 

                        <li><a href="<?php echo base_url(); ?>index.php/Investor/InvProfile">Menu3.2</a></li>

                        <li><a href="<?php echo base_url(); ?>index.php/Investor/UnitCollection">Menu3.3</a></li>                                              

                    </ul>

                </li> 
                
                