 <li class="active">
          <a href="<?php echo base_url(); ?>index.php/welcome"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span> </a>
  </li>

                <li>

                    <a href="#"><i class="fa fa-bank"></i> <span class="nav-label"> Manage Hospital</span> </a>
 
                </li>

                <li>
                    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">  Hospital Admin</span>  </a>
                </li>               

                <li>
                    <a href="#"><i class="fa fa-cubes"></i> <span class="nav-label">  Hospital Departments </span> </a>
                 </li>
                <li>
                    <a href="<?php echo base_url(); ?>index.php/Scroll"><i class="fa fa-cubes"></i> <span class="nav-label">  Scroll News </span> </a>
                 </li>

                 <li>
                    <a href="#"><i class="fa fa-cubes"></i> <span class="nav-label">Users</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">                        
                        <li><a href="<?php echo base_url(); ?>index.php/users">Manage</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/users/resetpassword">Reset Password</a></li>
                    </ul>
                </li>