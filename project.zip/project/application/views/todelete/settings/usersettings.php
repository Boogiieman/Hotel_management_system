<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>User Settings</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Settings</a>
                        </li>
                        <li class="active">
                            <strong>User Details entry</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>User details <small>This form helps to manage users</small></h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Search User</a></li>
                                    <li><a href="#">Login History</a></li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form method="get" class="form-horizontal">
                                <div class="form-group">
                                	<label class="col-sm-2 control-label">User Code</label>
                                    <div class="col-sm-3">
                                    	<div class="input-group">
                                    		<input type="text" class="form-control"> 
                                    		<span class="input-group-btn"> <button type="button" class="btn btn-default"><i class="fa fa-eye"></i></button> </span>
                                    	</div>
                                    </div>                                                            			
                                 	<label class="col-sm-2 control-label">Full name of user</label>
                                    <div class="col-sm-3"><input type="text" class="form-control"></div>                                    
                                </div>
                                <div class="form-group"><label class="col-sm-2 control-label">Is Admin?</label>
                                    <div class="col-sm-3"><input type="checkbox" name="isadmin" value="Y"></div> 
                                    <label class="col-sm-2 control-label">Department</label>
                                    <div class="col-sm-3"> <select name="department" class="form-control">
											<option value="0">...</option>
											  <option value="O">Operation</option>
											  <option value="M">Marketing</option>
											  <option value="F">Finance</option>
											  <option value="P">Production</option>
											  <option value="A">Admin</option>
											</select> </div>                                 
                                </div>
				<div class="form-group"><label class="col-sm-2 control-label">Assigned Company</label>
                                    <div class="col-sm-3">
                                    		<select name="department" class="form-control">
							<option value="0">...</option>
						  	<option value="O">Company 1</option>
						  	<option value="M">Company 2</option>
						</select> </div>                                 
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
					<label class="col-sm-2 control-label">Password reset?</label>
                                    	<div class="col-sm-3"><input type="checkbox" name="passwordreset" value="Y"></div> 
                                	<label class="col-sm-2 control-label">Initial Password</label>
                                        <div class="col-sm-3"><input type="text" class="form-control"></div>                               
                                </div>     
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-white" type="submit">Cancel</button>
                                        <button class="btn btn-primary" type="submit">Save changes</button>
                                    </div>
                                </div>                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
