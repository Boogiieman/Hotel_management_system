<?php 
 
  
       $MemberPh = '';
       $MemberCodePh = ''; 
      
       if($v_data=='No'){ 
        
            $investorID  = 0 ;
            $unitID  = '' ;
            $folio_no  = '' ;
            $name  = '' ;
            $dob  = '' ;
            $sex  = 0 ;
            $email  = '' ;
            $mobile_india  = '' ;
            $mobile_ksa  = '' ;
            $address_india  = '' ;
            $address_ksa  = '' ;
            $bloodgroup  = '' ;
            $job_title  = '' ;
            $passport  = '' ;
            $pancard  = '' ;
            $aadhar  = '' ;
            $iqama  = '' ;
            $nominee_name  = '' ;
            $nominee_relation  = '' ;
            $nominee_address  = '' ;
            $nominee_mobile  = '' ;
            $premium_type  = 0 ;
            $premium_amount  = '' ;
            $due_date  = '' ;
            $join_date  = '' ;
            $residence_status  = 0 ;
            $current_location  = '' ;
            $photo  = '' ;
            $username  = '' ;
            $password  = '' ;
            $create_date  = '' ;
            $modify_date  = '' ;
            $modify_userID  = '' ;
            $active  = 3 ;

       }
       else{
           $investorID  = $v_data->investorID ;
            $unitID  = $v_data->unitID ;
            $folio_no  = $v_data->folio_no ;
            $name  = $v_data->name ;
            $dob  = $v_data->dob ;
            $sex  = $v_data->sex ;
            $email  = $v_data->email ;
            $mobile_india  = $v_data->mobile_india ;
            $mobile_ksa  = $v_data->mobile_ksa ;
            $address_india  = $v_data->address_india ;
            $address_ksa  = $v_data->address_ksa ;
            $bloodgroup  = $v_data->bloodgroup ;
            $job_title  = $v_data->job_title ;
            $passport  = $v_data->passport ;
            $pancard  = $v_data->pancard ;
            $aadhar  = $v_data->aadhar ;
            $iqama  = $v_data->iqama ;
            $nominee_name  = $v_data->nominee_name ;
            $nominee_relation  = $v_data->nominee_relation ;
            $nominee_address  = $v_data->nominee_address ;
            $nominee_mobile  = $v_data->nominee_mobile ;
            $premium_type  = $v_data->premium_type ;
            $premium_amount  = $v_data->premium_amount ;
            $due_date  = $v_data->due_date ;
            $join_date  = $v_data->join_date ;
            $residence_status  = $v_data->residence_status ;
            $current_location  = $v_data->current_location ;
            $photo  = $v_data->photo ;
            $username  = $v_data->username ;
            $password  = $v_data->password ;
            $create_date  = $v_data->create_date ;
            $modify_date  = $v_data->modify_date ;
            $modify_userID  = $v_data->modify_userID ;
            $active  = $v_data->active ;

            
            if($active==1)
            $passwords = '*******';
       } 
       $Address ='' ;
       
       if(!empty($address_india))
       $Address = $address_india;
      
       if(!empty($address_ksa))
       $Address = $address_ksa;
     
     if($MyLedger == 1){ 
         
         $InvID = $this->session->userdata['mysession']['inv_id'];
         if(empty($InvID))
         $InvID = 0;
         $Val = set_value('InvestorID',$InvID); 
     }        
  
?>
<form method="post" class="form-horizontal" action="MyProfile">
 <input type="hidden" id="investorID" name="investorID" value="<?php echo $investorID; ?>"/>
 <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Investor Details</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Investor</a>
                        </li>
                        <li class="active">
                            <strong>Investor Details</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
 </div>
  
<!-- Profile 1-->  
 <?php
	if($MyLedger == 1){ 
?>
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="form-group">
        	<label class="col-sm-2 control-label">Folio No</label>
            <div class="col-sm-3">
            
                
           <?php
               if($MyLedger == 1)
              {
    			$js ='id="InvestorID" class="form-control m-b"';
    			echo   form_dropdown('InvestorID', $MapdUsersFolio,$Val,$js);
  	          }
              else
              {
                echo ' <input type="text" class="form-control" id="InvestorID" name="InvestorID" value="' .$Folio_No.'">';
              }
          
          
          	?>	
           
            </div>
             


            
            <div class="col-sm-4  ">
                <button class="btn btn-primary" type="submit" id="cmdSubmit">Show</button>

             </div>                                                                                              
         </div>
  </div>       
  <?php
	}
?>
 <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
                <div class="col-lg-4">
                        <div class="widget-head-color-box navy-bg p-lg text-center">
                            <div class="m-b-md">
                            <h2 class="font-bold no-margins">
                                <?php echo $name; ?>
                            </h2>
                                <small> <?php if(!empty($job_title))echo $job_title; ?></small>
                            </div>
 <?php
	if(!empty($photo))
        $Img = 'photo/'.$photo. '?'.md5(time());
    else
        $Img = 'assets/img/profile_small.jpg';
    
?>
                            <img data-toggle="modal" data-target="#project-Cam"  src="<?php echo base_url().$Img; ?> " class="img-circle circle-border" width="200px" alt="profile">
                            <div>
                                <h2><?php echo $folio_no; ?></h2> 
                                 <small><?php echo 'Instalment Amount :'.$premium_amount; ?></small> 
                            </div>
                        </div>
                        <div class="widget-text-box">
                            <h4 class="media-heading">Contact Numbers</h4>
                            <p>KSA : <?php echo $mobile_ksa; ?> <br />India : <?php echo $mobile_india; ?></p> 
                             
                        </div>
                </div> 
        
            <div class="col-lg-8 animated fadeInRight">
            <div class="mail-box-header"> 
                <h2>
                    <?php echo $name; ?>
                </h2>
                <div class="mail-tools tooltip-demo m-t-md">


                    <h3>
                        <span class="font-noraml"> <?php echo $Address; ?> </span> 
                    </h3>
                    <h5>
                        <span class="pull-right font-noraml"><?php echo 'Date of Joining : '.$join_date; ?></span>
                        <span class="font-noraml"> &nbsp;&nbsp;</span><?php echo $email; ?>
                    </h5>
                </div>
            </div>
                <div class="mail-box">


                <div class="mail-body">
                 <div class="col-lg-6">
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <i class="fa fa-warning"></i>  Address KSA
                            </div>
                            <div class="panel-body" style=" min-height: 110px;">
                                <p><?php echo $address_ksa ?></p>
                            </div>
                            <div class="panel-footer">
                                            Phone : <?php echo $mobile_ksa ?>
                            </div>
                        </div>
                   </div>
                   <div class="col-lg-6">
                        <div class="panel panel-danger ">
                            <div class="panel-heading" >
                                <i class="fa fa-warning"></i> Address India
                            </div>
                            <div class="panel-body" style=" min-height: 110px;" >
                                            <p><?php echo $address_india ?></p>                            
                            </div>
                            <div class="panel-footer">
                                            Phone : <?php echo $mobile_india ?>
                            </div>
                        </div>
                    </div>
                    
                    <p>
    <?php
            $Details1 = '';$Details2= ''; $Details3= '';
	      if(!empty($sex))
          $Details1.='Sex : ' .$SexList[$sex].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	      if( $dob!= '0000-00-00')
          $Details1.='Date of Birth : ' .$dob.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	      if(!empty($job_title))
          $Details1.='JobTitle : ' .$job_title.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
          
	      if(!empty($passport))
          $Details2.='Passport No : ' .$passport.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	      if(!empty($pancard))
          $Details2.='PAN Card No : ' .$pancard.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	      if(!empty($aadhar))
          $Details2.='Aadhar No : ' .$aadhar.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	      if(!empty($iqama))
          $Details2.='Iqama No : ' .$iqama.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'; 
          
          if(!empty($residence_status))
          $Details3.='Residence Status : ' .$ResidenceStatus[$residence_status].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
          if(!empty($current_location))
          $Details3.='Iqama No : ' .$current_location.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
          
          echo $Details1.'</p><p>';
          echo $Details2.'</p><p>' ;
          echo $Details3.'</p><p>' ;
    ?>
                        <br> 
                     </p> 
                     
                     <div class="col-lg-12">
                        <div class="panel panel-danger ">
                            <div class="panel-heading" >
                                <i class="fa fa-warning"></i> Nominee Details
                            </div>
                            <div class="panel-body" style=" min-height: 110px;" >
                                            <p><?php echo 'Name : '.$nominee_name ?></p> 
                                            <p><?php echo 'Relation : '.$nominee_relation ?></p>
                                            <p><?php echo 'Address : '.$nominee_address ?></p>                            
                            </div>
                            <div class="panel-footer">
                                            Phone : <?php echo $nominee_mobile ?>
                            </div>
                        </div>
                    </div>
                    
                </div>
                    <div class="mail-attachment">
                    
  <?php
    
    $MyUserID = $this->session->userdata['mysession']['user_id'];
    
	if($MyLedger == 0 || ($MyLedger == 1 && $modify_userID != $MyUserID)){
?>                  
                      <button TypeID="1"  intID = "<?php  echo $investorID; ?>" title="Edit" class="btn btn-danger  dim ActionInv" type="button"><i class="fa fa-edit fa-2x"></i></button>   
 <?php
	}
?>                   
                      <button TypeID="2"  intID = "<?php  echo $investorID; ?>" title="Ledger" class="btn btn-warning  dim ActionInv" type="button"><i class="fa fa-list-alt fa-2x"></i></button>   
                    
                    
                    </div> 
                        <div class="clearfix"></div>


                </div>
            </div>
        
        
        
    </div>
 </div>        
  </form>
           
<?php 
		
  if($MyLedger == 0){   
    
        $attr1= array('name' => 'frmInvestorEdit', 'id' => 'frmInvestorEdit');
		echo form_open(base_url().'index.php/Investor/Select',$attr1);
        
        echo '<input  id="investorID" name="investorID" value="'.$investorID.'" type="hidden"/>';
        echo '<input id="TypeID" name="TypeID" value="0" type="hidden"/>  ';
        echo '<input type="submit"  id="cmdEdit" value="22" hidden="hidden"/> ';
        echo form_close();                                
?>	

<!-- Popup Screen 1-->
<div class="modal fade" id="project-Cam" tabindex="-1" role="dialog" aria-labelledby="project-Cam-label" aria-hidden="true">
	<div class="modal-dialog " style="width: 100%;" >
		<div class="modal-content" style="height:500px; width: 500px; margin-left: 40%;">
			<div class="modal-header">
				<button id="cmdCamClosed" type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title" id="project-6-label">Upload Photo</h4>
			</div>
			<div class="modal-body" id="divCamera" style="vertical-align: central;">
                <i class="fa fa-refresh fa-spin fa-5x text-danger" style="margin-left: 45%; margin-top: 30%;"></i>  
			</div> 
		</div>
	</div>
</div>

 <?php  
    }
    else
    {
        $attr1= array('name' => 'frmInvestorEdit', 'id' => 'frmInvestorEdit');
		echo form_open(base_url().'index.php/Investor/MySelect',$attr1);
        
        echo '<input  id="investorID" name="investorID" value="'.$investorID.'" type="hidden"/>';
        echo '<input id="TypeID" name="TypeID" value="0" type="hidden"/>  ';
        echo '<input type="submit"  id="cmdEdit" value="22" hidden="hidden"/> ';
        echo form_close();                                

    }
?>  
<style>
.photoDiv{
    border: 10px double red; 
    margin-left: 100px; 
    margin-right: 100px;
    vertical-align: central;
    width: 150px;
    height: 200px;
}
.photoDiv img {
   display: block;
   width: 100%;
}
</style>
<script>


      function GetPhoto(){
  	       event.preventDefault();  
             
           var MemberID =  <?php  echo $investorID;?>;   
           $.ajax 
    		({
    			   type: "POST",
    			   url: "<?php echo base_url();?>index.php/Photo/GetPhoto",
    			   data:{MemberID:MemberID},
    			   dataType:'json' ,
    			   success: function(data)
    			   {	
                      $('#divMemberPhoto').html(data.Photo); // alert(MemberID);  
    			   },
    			   error: function(jqXHR, textStatus, errorThrown) 
    				{ 
    				    $("#divMemberPhoto").html(jqXHR.responseText);
    				}
    		}); 
	} ;
        
  $(function () {
    
    
    GetPhoto();
    
    var MemberID =  <?php  echo $investorID;?>;   
     //alert(MemberID);
          $.ajax 
		({
			   type: "POST",
			   url: "<?php echo base_url();?>index.php/Photo/Camera/1",
			   data:{MemberID:MemberID},
			   dataType:'' ,
			   success: function(data)
			   {	
                  $('#divCamera').html(data);   
			   },
			   error: function(jqXHR, textStatus, errorThrown) 
				{ 
				    $("#divCamera").html(jqXHR.responseText);
				}
		});
        
       
        $('.ActionInv').click(function (event) { 
			var InvID = $(this).attr('intID');
            var TypeID = $(this).attr('TypeID');   
            if(InvID>0){                        
                //$('#investorID').val(InvID);                     
                $('#TypeID').val(TypeID); 
                $('#cmdEdit').click();
            }                
     });   
      
 <?php
	   if($MyLedger == 1){ 

?> 
    $('#InvestorID').change(function (event){
    
        var  InvID = $('#InvestorID').val(); 
        $.ajax({
			type:"POST",
			url:"<?php echo base_url(); ?>index.php/Investor/SetInvID",
			data:{InvID:InvID},
			success:function(data)
			{
			  $('#cmdSubmit').click();
			}
	   }); 
       
 });
 
 <?php
	}
?>
      
});

</script> 


 