<?php 
		$attr1= array('name' => 'frmPendingReceipts', 'id' => 'frmPendingReceipts' );
		echo form_open('#t',$attr1);
        
  /*       $UT = $this->session->userdata['mysession']['user_type_id'];
         
         $AccID = $this->session->userdata['mysession']['acc_id'];
         if(empty($AccID))
         $AccID = 0;
         $Accval = set_value('cmbAcc',$AccID); 
         
         $ZoneID = $this->session->userdata['mysession']['zone_id'];
         if(empty($ZoneID))
         $ZoneID = 0;
         $Zoneval = set_value('cmbZone',$ZoneID); 

         $AreaID = $this->session->userdata['mysession']['area_id'];
         if(empty($AreaID))
         $AreaID = 0;
         $Areaval = set_value('cmbArea',$AreaID); 
          
         $unitID = $this->session->userdata['mysession']['unit_id'];
         if(empty($unitID))
         $unitID = 0;
         $val1 = set_value('cmbUnit',$unitID); 
      */   
?>

            <div class="row"  id="InnerDiv">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5>Pending Receipts Details of <span class="text-danger"><?php echo $OfficeData->office_name; ?></span></h5>
                    	<div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
                    
                        <div class="form-group"> 
                     			 
                     	
                    
<?php
	
    if($v_data!= "No" )
    {
?>
                    <table class="table table-striped table-bordered table-hover dataTable1" id="TblInvList" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th>Name</th>
                        <th>Unit Name</th>
                        <th>Amount</th>
                        <th>Receipt No</th> 
                        <th>Receipt Date</th>
                        <th>Submitted by</th>
                        <th>Submitted Date</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
<?php
    $loop = 0;
    	foreach ($v_data->result() as $r)
     	 { 
     	  $loop = $loop + 1;
?>
                    <tr class="gradeX">
                        <td><?php  echo $loop; ?></td>
                        <td><?php  echo $r->name; ?></td>
                         <td><?php  echo $r->office_name; ?></td> 
                         <td><?php  echo $r->tran_amount_collection; ?></td> 
                         <td><?php  echo $r->receipt_no; ?></td> 
                         <td><?php  echo $r->receipt_date; ?></td> 
                         <td><?php  echo $r->submitted_by; ?></td> 
                         <td><?php  echo $r->submitted_date; ?></td> 
                        <td > 
                            <div id="<?php  echo 'divSbmt'.$r->id; ?>">
                                <a title="Click to approve this receipt and send to <?php  echo $OfficeData->parOfficeName; ?>"   TrID = "<?php  echo $r->id; ?>" href="#" class="Submit" >
                                    <i class="fa fa-exclamation-circle fa-2x text-danger"></i>
                                </a> 
                            </div>
                        </td>
                            
                    </tr>
<?php
        }
 
?> 
                    
                    </tbody>
                   <!--   <tfoot>
                    <tr>
                        <th>Sl No</th>
                        <th>Folio No</th>
                        <th>Name</th>
                        <th>Mobile KSA</th>
                        <th>Premium</th>
                        <th>Due Date</th>
                        <th></th>
                    </tr>
                    </tfoot>-->
                    </table>
<?php
        }
        else
        {
             
?>	
                    <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell-slash fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins "> 
                                 No pending approval receipts available 
                            </h3>
                            <small> </small>    
                        </div>
                    </div>

  
  <?php                 
            
        }
 
?>

                  	</div>
                  </div>
                </div>
            </div>
            </div>            
 
     
<script>
	
$(document).ready(function()
{

    var Approved = '<i title="Successfully send to <?php  echo $OfficeData->parOfficeName; ?>" class="fa fa-check-square-o fa-2x text-success"></i>'
     
    
     $('.Submit').click(function (event) {
			  var TrID = $(this).attr('TrID'); 
		      var DivID = '#divSbmt'+TrID 
         $(DivID).html('<i class="fa fa-refresh fa-spin  fa-2x text-warning"></i>');
         if(TrID > 0){
          	$.ajax({
            			type: "POST",
            			url: "<?php echo base_url();?>index.php/Investor/ApproveReceipt",
            			data: {TrID:TrID}, 
            			success: function(msg)
            			{ $(DivID).html(Approved); },
                	    error: function(jqXHR, textStatus, errorThrown) 
                	    {  $(DivID).html(jqXHR.responseText); }
            		
            		});	 
          }  
     });
     
         

}); 

</script>  


<style>
.spinner {
  /* margin: 150px auto; */
  width: 80px;
  height: 150px;
  text-align: center;
  font-size: 20px;
}

.spinner > div {
  background-color: #1ab394;
  height: 100%;
  width: 6px;
  display: inline-block;
  
  -webkit-animation: sk-stretchdelay 1.2s infinite ease-in-out;
  animation: sk-stretchdelay 1.2s infinite ease-in-out;
}

.spinner .rect2 {
  -webkit-animation-delay: -1.1s;
  animation-delay: -1.1s;
}

.spinner .rect3 {
  -webkit-animation-delay: -1.0s;
  animation-delay: -1.0s;
}

.spinner .rect4 {
  -webkit-animation-delay: -0.9s;
  animation-delay: -0.9s;
}

.spinner .rect5 {
  -webkit-animation-delay: -0.8s;
  animation-delay: -0.8s;
}

@-webkit-keyframes sk-stretchdelay {
  0%, 40%, 100% { -webkit-transform: scaleY(0.4) }  
  20% { -webkit-transform: scaleY(1.0) }
}

@keyframes sk-stretchdelay {
  0%, 40%, 100% { 
    transform: scaleY(0.4);
    -webkit-transform: scaleY(0.4);
  }  20% { 
    transform: scaleY(1.0);
    -webkit-transform: scaleY(1.0);
  }
}
</style>     