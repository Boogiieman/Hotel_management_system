﻿                <div class="widget red-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-ban fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins"> 
                               Permission Denied  
                            </h3>
                            <small>You have no permission to access this facility </small>    
                        </div>
                    </div>