<?php 
		$attr1= array('name' => 'frmAuthorisedTrn', 'id' => 'frmAuthorisedTrn' );
		echo form_open(base_url().'index.php/Investor/AuthorisedTran',$attr1);
        
       $UT = $this->session->userdata['mysession']['user_type_id'];
      
?>

            <div class="row"  id="InnerDiv">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5>Authorised Transactions Details of <span class="text-danger"><?php echo $OfficeData->office_name; ?></span></h5>
                    	<div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
                    
                        <div class="form-group">
                        	<label class="col-sm-2 control-label">Start Date</label>
                            <div class="col-sm-3">
                                <div class="input-group date" id="div2"> 
                                     <span class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                     </span>
                                        <input type="text"   class="form-control datepicker" value="<?php echo  $Sdate; ?>" id="txtStartDate" name="txtStartDate">
                                </div>
                            </div>  
                        	<label class="col-sm-2 control-label">End Date  </label>
                            <div class="col-sm-3">
                                <div class="input-group date" id="div2"> 
                                     <span class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                     </span>
                                        <input type="text"   class="form-control datepicker" value="<?php echo  $Edate; ?>" id="txtEndDate" name="txtEndDate">
                                </div>
                            </div> 
                            <div class="col-sm-2">
                                <button id="cmdShow" class="btn btn-primary" type="submit">Show </button>  
                                &nbsp;&nbsp;
                                <a style="display: none;" title="Click to Download PDF" href="#" id="PDFreport" >
                                    <i class="fa  fa-file-pdf-o fa-2x text-danger"></i>
                                </a>                              
                            </div>
                            
                        </div>
                     <div class="col-sm-12">&nbsp;&nbsp;&nbsp;</div>
                        <div class="form-group">  
<?php
    $OfficeType = 'Unit Name';
	
    if($UT==3)
    $OfficeType = 'Area Name';
    if($UT==2)
    $OfficeType = 'Zone Name';
    if($UT==1)
    $OfficeType = 'Zone Name';
    
      $loop = 0;
    if($v_data!= "No" )
    {
?>
                    <table class="table table-striped table-bordered table-hover dataTable1" id="TblInvList" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th>Authorised By</th>
                        <th><?php echo $OfficeType ?></th>
                        <th>Authorised Date</th>
                        <th>Number of Investors</th> 
                        <th>Total Amount</th>  
                    </tr>
                    </thead>
                    <tbody>
<?php
  
    	foreach ($v_data->result() as $r)
     	 { 
     	  $loop = $loop + 1;
?>
                    <tr class="gradeX">
                        <td><?php  echo $loop; ?></td>
                        <td><?php  echo $r->authorised_by; ?></td>
                         <td><?php  echo $r->office_name; ?></td> 
                         <td><?php  echo $r->aproved_date; ?></td> 
                         <td><?php  echo $r->count_receipt; ?></td> 
                         <td><?php  echo $r->sum_amount; ?></td>   
                            
                    </tr>
<?php
        }
 
?> 
                    
                    </tbody>
                   <!--   <tfoot>
                    <tr>
                        <th>Sl No</th>
                        <th>Folio No</th>
                        <th>Name</th>
                        <th>Mobile KSA</th>
                        <th>Premium</th>
                        <th>Due Date</th>
                        <th></th>
                    </tr>
                    </tfoot>-->
                    </table>
                    <div id="errDiv"></div>
<?php
        }
        else
        {
             
?>	
                   
                  
                    <div class="widget blue-bg p-lg text-center" style=" margin-top: 75px;">
                        <div class="m-b-md">
                            <i class="fa fa-bell-slash fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins "> 
                                 No Records Available 
                            </h3>
                            <small> </small>    
                        </div>
                    </div>

  
  <?php                 
            
        }
 
?>

                  	</div>
                  </div>
                </div>
            </div>
            </div>            


<?php
     echo form_close();  
		$attr1= array('name' => 'frmReportPdf', 'id' => 'frmReportPdf');
		echo form_open(base_url().'index.php/Reports/AuthorisedTranPDF',$attr1);
        
        echo '<input  id="txtStartDate1" name="txtStartDate1" value="'.$Sdate.'" type="hidden"/>'; 
        echo '<input  id="txtEndDate1" name="txtEndDate1" value="'.$Edate.'" type="hidden"/>'; 
        
        echo '<input type="submit"  id="cmdReportPdf" value="Pdf" hidden="hidden" />';
        echo form_close();                                
?>


 
  <div class="modal inmodal fade" id="ApprovalScreen" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg"  >
        <div class="modal-content animated bounceInRight">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title"> Pending Approval List of <span class="text-danger" id="spanOfficeName"></span></h4>
            </div>
            <div class="modal-body" id="divReceiptList" style="height: 350px; overflow-x:hidden;">
                 <div class="spinner" style="margin-left: 40%;">
                  <div class="rect1"></div>
                  <div class="rect2"></div>
                  <div class="rect3"></div>
                  <div class="rect4"></div>
                  <div class="rect5"></div>
                </div>
            </div>
            <div class="modal-footer"> 
                <div  class="col-sm-4" id="divResult">  
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                </div>
                <div  class="col-sm-4" >
                     <a href="#" id="divPdf" style=" display: none;" title="Click to download 'Log Report'"> <i class="fa fa-file-pdf-o  fa-2x text-danger"></i> <span id="spanRpt"></span></a>
                </div>
                <div  class="col-sm-4">
                    <a href="<?php echo base_url(); ?>index.php/Investor/PendingApproval"> 
                                    <button  id="cmdCancelApp" class="btn btn-danger" type="button">Cancel</button>
                     </a>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <button 
                           OfficeID = "<?php  echo $r->office_id; ?>"
                           UserID = "<?php  echo $r->user_id; ?>" 
                            id="cmdApproveTrn" class="btn btn-primary" type="button">Approve </button>
                </div>
            </div>
        </div>
    </div>
</div>

 

 	
     
<script>
	
$(document).ready(function()
{
 $('.datepicker').datepicker({  
                format: 'yyyy-mm-dd',
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });
<?php
	if($loop > 0) {
?>
     $('#PDFreport').show('slow');
<?php
	}
?>
           
$('#PDFreport').click(function (event) {
     $('#cmdReportPdf').click();
});
    /*
    var Approved = '<i title="Successfully send to <?php  echo $OfficeData->parOfficeName; ?>" class="fa fa-check-square-o fa-2x text-success"></i>'
    var Err = '<i title="Errorr..." class="fa fa-ban fa-2x text-danger"></i>'
    $('#divPdf').click(function (event) { 
        $('#cmdReportLog').click();
    });
    
    
    $('.Submit').click(function (event) {
       // alert();
        
      	var OfficeID = $(this).attr('OfficeID');
      	var UserID = $(this).attr('UserID'); 
      	var OfficeName = $(this).attr('OfficeName'); 
       var DivID = '#divSbmt'+OfficeID+'_'+UserID
       $(DivID).html('<i class="fa fa-refresh fa-spin  fa-2x text-warning"></i>');
        $('#spanOfficeName').html(OfficeName);  
          $.ajax({
        			type: "POST",
        			url: "<?php echo base_url();?>index.php/Investor/PendingApprovalList",
        			data: {OfficeID:OfficeID,UserID:UserID},  
        			success: function(msg)
        			{ 
                          $('#divReceiptList').html(msg);  
                    },
            	    error: function(jqXHR, textStatus, errorThrown) 
            	    {  $('#divReceiptList').html(jqXHR.responseText); }
        		
        		});	  
    });
    
    $(document).on('hide.bs.modal','#ApprovalScreen', function () {
            location.reload();
    });
    
     $('#cmdApproveTrn').click(function (event) {
			  var OfficeID = $(this).attr('OfficeID'); 
              var UserID = $(this).attr('UserID'); 
         $("#divResult").html('<i class="fa fa-refresh fa-spin  fa-2x text-danger"></i>');
         
       var DivID = '#divSbmt'+OfficeID+'_'+UserID
       
          if(OfficeID > 0 && UserID > 0){ 
          	$.ajax({
            			type: "POST",
            			url: "<?php echo base_url();?>index.php/Investor/ApproveReceipt",
            			data: {OfficeID:OfficeID,VolID:UserID}, 
                        dataType: "json",
            			success: function(msg)
            			{ 
            			   if( msg.Success==1) { //alert();
                             
                              $("#spanRpt").html(msg.pdfName); 
                             $(DivID).html(Approved); 
                             $("#divResult").html(Approved +'  ' + msg.Transaction); 
                             $("#hdnLogID").val(msg.LogID); 
                              $('#divPdf').show('slow');
                            }
                            else{
                                $(DivID).html(Err); 
                                $("#divResult").html(Err+msg.msg);
                            }
                        },
                	    error: function(jqXHR, textStatus, errorThrown) 
                	    {  $("#divResult").html(Err+jqXHR.responseText); }
            		
            		});	 
          }  
     });
     
      */   

}); 

</script>  


<style>
.spinner {
  /* margin: 150px auto; */
  width: 80px;
  height: 150px;
  text-align: center;
  font-size: 20px;
}

.spinner > div {
  background-color: #1ab394;
  height: 100%;
  width: 6px;
  display: inline-block;
  
  -webkit-animation: sk-stretchdelay 1.2s infinite ease-in-out;
  animation: sk-stretchdelay 1.2s infinite ease-in-out;
}

.spinner .rect2 {
  -webkit-animation-delay: -1.1s;
  animation-delay: -1.1s;
}

.spinner .rect3 {
  -webkit-animation-delay: -1.0s;
  animation-delay: -1.0s;
}

.spinner .rect4 {
  -webkit-animation-delay: -0.9s;
  animation-delay: -0.9s;
}

.spinner .rect5 {
  -webkit-animation-delay: -0.8s;
  animation-delay: -0.8s;
}

@-webkit-keyframes sk-stretchdelay {
  0%, 40%, 100% { -webkit-transform: scaleY(0.4) }  
  20% { -webkit-transform: scaleY(1.0) }
}

@keyframes sk-stretchdelay {
  0%, 40%, 100% { 
    transform: scaleY(0.4);
    -webkit-transform: scaleY(0.4);
  }  20% { 
    transform: scaleY(1.0);
    -webkit-transform: scaleY(1.0);
  }
}
</style>     