<table width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td colspan="2"><strong>Dear</strong> <?php echo $Name; ?> </td>
      </tr>
      <tr>
        <td width="7%">&nbsp;</td>
        <td width="93%"><strong> We have received a contribution of SAR. <?php echo $Amount; ?>/- on <?php echo $Date; ?> </strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Thanks and Regards,</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>SAIF</td>
      </tr>
    </table>