<?php 
		$attr1= array('name' => 'frmPendingReceipts', 'id' => 'frmPendingReceipts' );
		echo form_open('#t',$attr1);
        
  /*       $UT = $this->session->userdata['mysession']['user_type_id'];
         
         $AccID = $this->session->userdata['mysession']['acc_id'];
         if(empty($AccID))
         $AccID = 0;
         $Accval = set_value('cmbAcc',$AccID); 
         
         $ZoneID = $this->session->userdata['mysession']['zone_id'];
         if(empty($ZoneID))
         $ZoneID = 0;
         $Zoneval = set_value('cmbZone',$ZoneID); 

         $AreaID = $this->session->userdata['mysession']['area_id'];
         if(empty($AreaID))
         $AreaID = 0;
         $Areaval = set_value('cmbArea',$AreaID); 
          
         $unitID = $this->session->userdata['mysession']['unit_id'];
         if(empty($unitID))
         $unitID = 0;
         $val1 = set_value('cmbUnit',$unitID); 
      */   
?>
 
                     			 
                     	
                    
<?php
	
    if($v_data!= "No" )
    {
?>
                    <table class="table table-striped table-bordered table-hover dataTable1" id="TblInvList" >
                    <thead>
                    <tr>
                        <th width=15%>Sl No</th>
                        <th>Name</th>
                        <th>Folio No.</th>
                        <th>Amount</th>
                        <th>Ref No</th>  
                        <th>Submitted Date</th> 
                    </tr>
                    </thead>
                    <tbody>
<?php
    $loop = 0;$Amount = 0;
    	foreach ($v_data->result() as $r)
     	 { 
     	  $loop = $loop + 1;
           $Amount =  $Amount +$r->tran_amount_collection;
?>
                    <tr class="gradeX">
                        <td><?php  echo $loop; ?></td>
                        <td><?php  echo $r->name; ?></td>
                         <td><?php  echo $r->folio_no; ?></td> 
                         <td><?php  echo $r->tran_amount_collection; ?></td> 
                         <td><?php  echo $r->receipt_no; ?></td>  
                         <td><?php  echo $r->submitted_date; ?></td>  
                            
                    </tr>
<?php
        }
 
?> 
                    
                    </tbody>
                   <!--   <tfoot>
                    <tr>
                        <th>Sl No</th>
                        <th>Folio No</th>
                        <th>Name</th>
                        <th>Mobile KSA</th>
                        <th>Premium</th>
                        <th>Due Date</th>
                        <th></th>
                    </tr>
                    </tfoot>-->
                    </table>
                    
                    <div class=" text-center">
                            <div class="ibox-content text-center">
                                <h1><?php  echo $r->submitted_by; ?></h1> 
                                   <p class="font-bold"><h3>Total Amount : <?php  echo $Amount; ?> </h3></p>

                                 
                            </div>
                   </div>
<?php
        }
        else
        {
             
?>	
                    <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell-slash fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins "> 
                                 No pending receipts available for approval
                            </h3>
                            <small> </small>    
                        </div>
                    </div>

  
  <?php                 
            
        }
 
?>

                   
 
     
<script>
	
$(document).ready(function()
{
    

}); 

</script>  


<style>
.spinner {
  /* margin: 150px auto; */
  width: 80px;
  height: 150px;
  text-align: center;
  font-size: 20px;
}

.spinner > div {
  background-color: #1ab394;
  height: 100%;
  width: 6px;
  display: inline-block;
  
  -webkit-animation: sk-stretchdelay 1.2s infinite ease-in-out;
  animation: sk-stretchdelay 1.2s infinite ease-in-out;
}

.spinner .rect2 {
  -webkit-animation-delay: -1.1s;
  animation-delay: -1.1s;
}

.spinner .rect3 {
  -webkit-animation-delay: -1.0s;
  animation-delay: -1.0s;
}

.spinner .rect4 {
  -webkit-animation-delay: -0.9s;
  animation-delay: -0.9s;
}

.spinner .rect5 {
  -webkit-animation-delay: -0.8s;
  animation-delay: -0.8s;
}

@-webkit-keyframes sk-stretchdelay {
  0%, 40%, 100% { -webkit-transform: scaleY(0.4) }  
  20% { -webkit-transform: scaleY(1.0) }
}

@keyframes sk-stretchdelay {
  0%, 40%, 100% { 
    transform: scaleY(0.4);
    -webkit-transform: scaleY(0.4);
  }  20% { 
    transform: scaleY(1.0);
    -webkit-transform: scaleY(1.0);
  }
}
</style>     