<?php 
		$attr1= array('name' => 'frmIinvestorrDetails', 'id' => 'frmIinvestorrDetails', 'class'=> 'form-horizontal');
		echo form_open('#',$attr1);
  
       $MemberPh = '';
       $MemberCodePh = ''; 
      
       if($v_data=='No'){ 
        
            $investorID  = 0 ;
            $unitID  = '' ;
            $folio_no  = '' ;
            $name  = '' ;
            $dob  = '' ;
            $sex  = 0 ;
            $email  = '' ;
            $mobile_india  = '' ;
            $mobile_ksa  = '' ;
            $address_india  = '' ;
            $address_ksa  = '' ;
            $bloodgroup  = '' ;
            $job_title  = '' ;
            $passport  = '' ;
            $pancard  = '' ;
            $aadhar  = '' ;
            $iqama  = '' ;
            $nominee_name  = '' ;
            $nominee_relation  = '' ;
            $nominee_address  = '' ;
            $nominee_mobile  = '' ;
            $premium_type  = 0 ;
            $premium_amount  = '' ;
            $due_date  = '' ;
            $join_date  = '' ;
            $residence_status  = 0 ;
            $current_location  = '' ;
            $photo  = '' ;
            $username  = '' ;
            $password  = '' ;
            $create_date  = '' ;
            $modify_date  = '' ;
            $modify_userID  = '' ;
            $active  = 3 ;

       }
       else{
           $investorID  = $v_data->investorID ;
            $unitID  = $v_data->unitID ;
            $folio_no  = $v_data->folio_no ;
            $name  = $v_data->name ;
            $dob  = $v_data->dob ;
            $sex  = $v_data->sex ;
            $email  = $v_data->email ;
            $mobile_india  = $v_data->mobile_india ;
            $mobile_ksa  = $v_data->mobile_ksa ;
            $address_india  = $v_data->address_india ;
            $address_ksa  = $v_data->address_ksa ;
            $bloodgroup  = $v_data->bloodgroup ;
            $job_title  = $v_data->job_title ;
            $passport  = $v_data->passport ;
            $pancard  = $v_data->pancard ;
            $aadhar  = $v_data->aadhar ;
            $iqama  = $v_data->iqama ;
            $nominee_name  = $v_data->nominee_name ;
            $nominee_relation  = $v_data->nominee_relation ;
            $nominee_address  = $v_data->nominee_address ;
            $nominee_mobile  = $v_data->nominee_mobile ;
            $premium_type  = $v_data->premium_type ;
            $premium_amount  = $v_data->premium_amount ;
            $due_date  = $v_data->due_date ;
            $join_date  = $v_data->join_date ;
            $residence_status  = $v_data->residence_status ;
            $current_location  = $v_data->current_location ;
            $photo  = $v_data->photo ;
            $username  = $v_data->username ;
            $password  = $v_data->password ;
            $create_date  = $v_data->create_date ;
            $modify_date  = $v_data->modify_date ;
            $modify_userID  = $v_data->modify_userID ;
            $active  = $v_data->active ;

            
            if($active==1)
            $passwords = '*******';
       } 
       
       
        $MyUserID = $this->session->userdata['mysession']['user_id'];
	
        $invID = $this->session->userdata['mysession']['inv_id'];
        if($invID>0 ){
?>
 <input type="hidden" id="investorID" name="investorID" value="<?php echo $investorID; ?>"/>
 <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Investor Details</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Investor</a>
                        </li>
                        <li class="active">
                            <strong>Edit</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Your Account Profile <small> This form helps to  edit your profile details </small></h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <!--
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="<?php echo base_url(); ?>index.php/job/index">Search Job</a></li>
                                    <li><a href="#">Job - Status</a></li>
                                    <li><a href="#">Client wise other jobs</a></li>
                                </ul>
                                -->
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        
             
                        <div class="ibox-content">
                             
                <label  class="text-danger" style=" padding-left: 10%;"><?php echo $name . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; Folio No :' . $folio_no; ?>   </label> 
                            
                                     <div class="row">
                                        <div class="col-lg-12">
                                            <div class="panel blank-panel">
                        
                                                <div class="panel-heading">
                                                    <!--  <div class="panel-title m-b-md">
                                                    			<small>Please fill all mandatory fields</small>
                                                    </div>-->
                                                    <div class="panel-options">
                        
                                                        <ul class="nav nav-tabs">
                                                            <li id="tab1" class="active"><a data-toggle="tab" href="#tab-1" aria-expanded="true">Basic Details</a></li>
                                                           <!-- <li id="tab2" class=""><a data-toggle="tab" href="#tab-2" aria-expanded="false">Premium</a></li>
                                                           --!>
                                                            <li id="tab2" class=""><a data-toggle="tab" href="#tab-2" aria-expanded="false">Address</a></li>
                                                            <li id="tab3" class=""><a data-toggle="tab" href="#tab-3" aria-expanded="false">Nominee</a></li>
   
                                                            <li id="tab5" class=""><a data-toggle="tab" href="#tab-5" aria-expanded="false">Photo</a></li>
                                                      &nbsp;
                                                        </ul>
                                                    </div>
                                                </div>
                        
                                                <div class="panel-body">
                        
                                                    <div class="tab-content">
                                                        
                                                        <div id="tab-1" class="tab-pane active">
                                                         
                                                          
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Date of Birth </label>
                                                                <div class="col-sm-3">
                                                                    <div class="input-group date"> 
                                                                         <span class="input-group-addon">
                                                                            <i class="fa fa-calendar"></i>
                                                                         </span>
                                                                            <input type="text"  class="form-control datepicker" value="<?php echo  $dob; ?>" id="dob" name="dob">
                                                                    </div>
                                                                </div>
                                                             	<label class="col-sm-2 control-label">Sex </label>
                                                                <div class="col-sm-3" id="div3">                                                                   
                                                                    <?php
                                                                        			$js ='id="sex" class="form-control m-b"';
                                                                        			$val1 = set_value('sex',$sex); 
                                                                        			echo   form_dropdown('sex', $SexList,$val1,$js);
                                                                      ?>
                                                                </div>                                   
                                                            </div>     
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Job Title</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $job_title; ?>" class="form-control" id="job_title" name="job_title"></div>
                                                             	<label class="col-sm-2 control-label">Email</label>
                                                                <div class="col-sm-3"><input type="text" class="form-control" value="<?php echo  $email; ?>" id="email" name="email"></div>                                   
                                                            </div>  
                                                               
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Passport No</label>
                                                                <div class="col-sm-3"><input type="text" class="form-control" value="<?php echo  $passport; ?>" id="passport" name="passport" ></div>
                                                             	<label class="col-sm-2 control-label">PAN Card</label>
                                                                <div class="col-sm-3"><input type="text" class="form-control" value="<?php echo  $pancard; ?>"  id="pancard" name="pancard"  ></div>                                   
                                                            </div> 
                                                               
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Aadhar No</label>
                                                                <div class="col-sm-3"><input type="text" class="form-control" value="<?php echo  $aadhar; ?>" id="aadhar" name="aadhar" ></div>
                                                             	<label class="col-sm-2 control-label">Iqama No</label>
                                                                <div class="col-sm-3"><input type="text" class="form-control" value="<?php echo  $iqama; ?>"  id="iqama" name="iqama"  ></div>                                   
                                                            </div>  
                                                            
                                                            <div class="form-group">
                                                                <label class="col-sm-2 control-label">Join Date</label>
                                                                <div class="col-sm-3">
                                                                    <div class="input-group date"> 
                                                                         <span class="input-group-addon">
                                                                            <i class="fa fa-calendar"></i>
                                                                         </span>
                                                                            <input type="text" class="form-control datepicker" value="<?php echo  $join_date; ?>" id="join_date" name="join_date" >
                                                                    </div>
                                                                </div>  
                                                                
                                                             	<label class="col-sm-5 control-label">Subscription Amount : <?php echo  $premium_amount; ?></label>
                                                             </div> 
                                                                                                                 
                                                        </div>
                                                    
                                                        <div id="tab-2" class="tab-pane">
                                                        
                                                            
                                                             <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Address in KSA</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $address_ksa; ?>" class="form-control" id="address_ksa" name="address_ksa" ></div>
                                                             	<label class="col-sm-6 control-label">Mobile# in KSA : <?php echo  $mobile_ksa; ?></label>
                                                             </div> 
                                                            
                                                             <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Address in India</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $address_india; ?>" class="form-control" id="address_india" name="address_india" ></div>
                                                             	<label class="col-sm-6 control-label">Mobile# in India : <?php echo  $mobile_india; ?>"</label>
                                                             </div> 
                                                            
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Current Residence Status</label>
                                                                <div class="col-sm-3">
                                                                 	<?php
                                                                 					$jsResidenceStatus='id="residence_status" class="form-control m-b"';
                                                                        			$valResidenceStatus= set_value('residence_status',$residence_status); 
                                                                        			echo   form_dropdown('residence_status', $ResidenceStatus,$valResidenceStatus,$jsResidenceStatus);
                                                                   	?>
																</div>
                                                             	<label class="col-sm-2 control-label">Current Location</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $current_location; ?>" class="form-control"  id="current_location" name="current_location"  ></div>                                   
                                                            </div> 
                                                            
                                                        </div>
                                                        
                                                        
                                                        <div id="tab-3" class="tab-pane">
                                                        
                                                            
                                                             <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Nominee Name</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $nominee_name; ?>" class="form-control" id="nominee_name" name="nominee_name" ></div>
                                                             	<label class="col-sm-2 control-label">Relation with nominee</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $nominee_relation; ?>" class="form-control"  id="nominee_relation" name="nominee_relation"  ></div>                                   
                                                            </div> 
                                                            
                                                             <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Nominee Address</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $nominee_address; ?>" class="form-control" id="nominee_address" name="nominee_address" ></div>
                                                             	<label class="col-sm-2 control-label">Nominee Mobile#</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $nominee_mobile; ?>" class="form-control"  id="nominee_mobile" name="nominee_mobile"  ></div>                                   
                                                            </div> 
                                                        </div>
                                                       
                                                        <div id="tab-4" class="tab-pane">  
                                                             <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Login Name</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $username; ?>" class="form-control" id="username" name="username" ></div>                                                             	                                  
                                                            </div> 
                                                             <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Password</label>
                                                                <div class="col-sm-3"><input type="text" value="<?php echo  $password; ?>" class="form-control" id="password" name="password" ></div>                                                             	                                  
                                                            </div> 
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Investor Status</label>
                                                                <div class="col-sm-3">
                                                                 	<?php
                                                                        			$jsInvestorStatus ='id="InvestorStatus" class="form-control m-b"';
                                                                        			$valInvestorStatus = set_value('InvestorStatus',$active); 
                                                                        			echo   form_dropdown('InvestorStatus', $InvestorStatus,$valInvestorStatus,$jsInvestorStatus);
                                                                   	?>
																</div>                                                             	                                  
                                                            </div>                                                            
                                                        </div>
                                                        
                                                       <div id="tab-5" class="tab-pane">  
                                                             <div class="form-group">  </div> 
                                                             <div class="form-group">

                                                                <div   data-toggle="modal" data-target="#project-Cam" class="photoDiv" id="divMemberPhoto">
                                                                </div>
                                                               <!-- <input value="<?php echo $photo; ?>" id="photo" name="photo" />
                                                            -->
                                                            </div>                                                            
                                                        </div>
                                                          
                                                    </div>
                                                    
                                                      
                                                            
                                                </div>
                        
                                            </div>
                                        </div> 
                                    </div>     
                                     <div class="form-group">
                                     	<div class="hr-line-dashed"></div>
                                                  <div class="col-sm-4 col-sm-offset-2">
                                                    <a href="<?php echo base_url(); ?>index.php/Investor"> 
                                                        <button  id="cmdCancelInv" class="btn btn-primary" type="button">Cancel</button>
                                                    </a>
                                                    <button id="cmdSaveInv" class="btn btn-primary" type="button">Save </button>
                     							</div> 
                                                 <div id="msg"></div>  
                                     	</div>                      
                            
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>


<!-- Popup Screen 1-->
<div class="modal fade" id="project-Cam" tabindex="-1" role="dialog" aria-labelledby="project-Cam-label" aria-hidden="true">
	<div class="modal-dialog " style="width: 100%;" >
		<div class="modal-content" style="height:500px; width: 500px; margin-left: 40%;">
			<div class="modal-header">
				<button id="cmdCamClosed" type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title" id="project-6-label">Upload Photo</h4>
			</div>
			<div class="modal-body" id="divCamera" style="vertical-align: central;">
                <i class="fa fa-refresh fa-spin fa-5x text-danger" style="margin-left: 45%; margin-top: 30%;"></i>  
			</div> 
		</div>
	</div>
</div>

 <?php
	echo form_close();
?>  
<style>
.photoDiv{
    border: 10px double red; 
    margin-left: 100px; 
    margin-right: 100px;
    vertical-align: central;
    width: 150px;
    height: 200px;
}
.photoDiv img {
   display: block;
   width: 100%;
}
</style>
<script>


      function GetPhoto(){
  	       event.preventDefault();  
             
           var MemberID =  <?php  echo $investorID;?>;   
           $.ajax 
    		({
    			   type: "POST",
    			   url: "<?php echo base_url();?>index.php/Photo/GetPhoto",
    			   data:{MemberID:MemberID},
    			   dataType:'json' ,
    			   success: function(data)
    			   {	
                      $('#divMemberPhoto').html(data.Photo); // alert(MemberID);  
    			   },
    			   error: function(jqXHR, textStatus, errorThrown) 
    				{ 
    				    $("#divMemberPhoto").html(jqXHR.responseText);
    				}
    		}); 
	} ;
        
  $(function () {
    
    
    GetPhoto();
    
    
    
    var MemberID =  <?php  echo $investorID;?>;   
     //alert(MemberID);
          $.ajax 
		({
			   type: "POST",
			   url: "<?php echo base_url();?>index.php/Photo/Camera",
			   data:{MemberID:MemberID},
			   dataType:'' ,
			   success: function(data)
			   {	
                  $('#divCamera').html(data);   
			   },
			   error: function(jqXHR, textStatus, errorThrown) 
				{ 
				    $("#divCamera").html(jqXHR.responseText);
				}
		});
        
         $('.datepicker').datepicker({  
                format: 'yyyy-mm-dd',
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });
         
       
      $("#cmdSaveInv").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmIinvestorrDetails").serialize();   
                    //alert(values);
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                
             swal({
                  title: 'Are you sure?',
                  text: "You have only one time update your profile ..",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, Submi it!'
                }).then(function () {    
                
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/Investor/SaveInv",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({ 
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                }); 
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url();?>index.php/Investor/MyProfile");
                                  }, 1500);
                                
                                
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    });
                                         
                                         Tab ='#tab'+ data.ErrTab;  
                                         TabPan = '#tab-'+ data.ErrTab; 
                                         
                                         $("li").removeClass("active");
                                         $(".tab-pane").removeClass("active");
                                                                                                                                                                                                             
                                         $(Tab).addClass('active');
                                         $(TabPan).addClass('active');                                    
                                   // ErrTab
                                swal(
                                      'Error...',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
               });   
        });
     
   

      $("#cmdEnableMebr").click(function(){
  	         event.preventDefault(); 
              var MembID = $("#hdnMemberID").val(); 
              var StatusID = 1;
             swal({
                  title: 'Are you sure?',
                  text: "You won't be able to enable this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, Enable it!'
            }).then(function () { 
                    $.ajax  
                    ({ 
                    	   type: "POST", 
                    	   url: "<?php echo base_url();?>index.php/member/MemberStatus", 
                    	   data:{StatusID:StatusID, MembID : MembID}, 
                    	   dataType:'' , 
                    	   success: function(data) 
                    	   {	
                                  swal(
                                    'Enable!',
                                    'Member Details has been Successfully Enabled.',
                                    'success'
                                  )
                                   $("#cmdLstMemb").click();
                                   $("#cmdLstSup").click();
                    	   }, 
                    	   error: function(jqXHR, textStatus, errorThrown)  
                    		{ 
                    		  $("#divUserFrm").html(jqXHR.responseText);
                             //alert('2');
                    		} 
                    });  
            });   
      
      });
      
      
});

</script> 



<?php
	}
    else
    { echo "Invalid Investor...";}
?>