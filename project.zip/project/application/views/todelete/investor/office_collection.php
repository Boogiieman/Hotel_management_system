<?php 
		$attr1= array('name' => 'frmAuthorisedTrn', 'id' => 'frmAuthorisedTrn' );
		echo form_open(base_url().'index.php/Investor/'.$Select,$attr1);
        
       $UT = $this->session->userdata['mysession']['user_type_id'];
       
       if($Select=='AreaCollection')
       $OfficeName = 'Area Name';
       else
       $OfficeName = 'Unit Name';
       
      
?>

            <div class="row"  id="InnerDiv">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                     	<div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
                    
                        <div class="form-group">
                        	<label class="col-sm-2 control-label">Start Date</label>
                            <div class="col-sm-3">
                                <div class="input-group date" id="div2"> 
                                     <span class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                     </span>
                                        <input type="text"   class="form-control datepicker" value="<?php echo  $Sdate; ?>" id="txtStartDate" name="txtStartDate">
                                </div>
                            </div>  
                        	<label class="col-sm-2 control-label">End Date  </label>
                            <div class="col-sm-3">
                                <div class="input-group date" id="div2"> 
                                     <span class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                     </span>
                                        <input type="text"   class="form-control datepicker" value="<?php echo  $Edate; ?>" id="txtEndDate" name="txtEndDate">
                                </div>
                            </div> 
                            <div class="col-sm-2">
                                <button id="cmdShow" class="btn btn-primary" type="submit">Show </button>  
                                &nbsp;&nbsp;
                                <a style="display: none;" title="Click to Download PDF" href="#" id="PDFreport" >
                                    <i class="fa  fa-file-pdf-o fa-2x text-danger"></i>
                                </a>                              
                            </div>
                            
                        </div>
                     <div class="col-sm-12">&nbsp;&nbsp;&nbsp;</div>
                        <div class="form-group">  
<?php
       $loop = 0;
    if($v_data!= "No" )
    {
?>
                    <table class="table table-striped table-bordered table-hover dataTable1" id="TblInvList" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th><?php echo $OfficeName; ?></th>
                        <th><div align="right"> Collection </div></th>
                        <th><div align="right"> Expense</div> </th> 
                        <th><div align="right"> Withdrawal </div></th> 
                        <th><div align="right"> Balance Amount</div></th>  
                    </tr>
                    </thead>
                    <tbody>
<?php
  
             $Collection = 0; 
           $expense = 0;
           $Withdrawal = 0;
           $Balance = 0 ;
           $GT = 0 ;
    	foreach ($v_data->result() as $r)
     	 { 
     	  $loop = $loop + 1; 
           $Collection = $Collection + $r->collection; 
           $expense = $expense + $r->expense;
           $Withdrawal = $Withdrawal + $r->withdrawal;
           $Balance =   $r->collection -   $r->expense  - $r->withdrawal;
           $GT = $GT + $Balance; 
?>
                    <tr class="gradeX">
                        <td al><?php  echo $loop; ?></td>
                        <td><?php  echo $r->office_name; ?></td>
                         <td align="right"><?php  echo number_format($r->collection,2); ?></td> 
                         <td align="right"><?php  echo number_format($r->expense,2); ?></td> 
                         <td align="right"><?php  echo number_format($r->withdrawal,2); ?></td>  
                         <td align="right"><?php  echo number_format($Balance,2); ?></td>  
                    </tr>
<?php
        
            $Balance = 0 ;
        }
 
?> 
                    </tbody>
                      <tfoot>
                    <tr> 
                        <th colspan="5"><div align="right">Total Balance </div> </th>
                        <th><div align="right"><?php  echo number_format($GT,2); ?> </div></th> 
                    </tr>
                    </tfoot> 
                    </table>
                    <div id="errDiv"></div>
<?php
        }
        else
        {
             
?>	
                   
                  
                    <div class="widget blue-bg p-lg text-center" style=" margin-top: 75px;">
                        <div class="m-b-md">
                            <i class="fa fa-bell-slash fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins "> 
                                 No Records Available 
                            </h3>
                            <small> </small>    
                        </div>
                    </div>

  
  <?php                 
            
        }
 
?>

                  	</div>
                  </div>
                </div>
            </div>
            </div>            


 
     
<script>
	
$(document).ready(function()
{
              $('.datepicker').datepicker({  
                format: 'yyyy-mm-dd',
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });
       

}); 

</script>  


<style>
.spinner {
  /* margin: 150px auto; */
  width: 80px;
  height: 150px;
  text-align: center;
  font-size: 20px;
}

.spinner > div {
  background-color: #1ab394;
  height: 100%;
  width: 6px;
  display: inline-block;
  
  -webkit-animation: sk-stretchdelay 1.2s infinite ease-in-out;
  animation: sk-stretchdelay 1.2s infinite ease-in-out;
}

.spinner .rect2 {
  -webkit-animation-delay: -1.1s;
  animation-delay: -1.1s;
}

.spinner .rect3 {
  -webkit-animation-delay: -1.0s;
  animation-delay: -1.0s;
}

.spinner .rect4 {
  -webkit-animation-delay: -0.9s;
  animation-delay: -0.9s;
}

.spinner .rect5 {
  -webkit-animation-delay: -0.8s;
  animation-delay: -0.8s;
}

@-webkit-keyframes sk-stretchdelay {
  0%, 40%, 100% { -webkit-transform: scaleY(0.4) }  
  20% { -webkit-transform: scaleY(1.0) }
}

@keyframes sk-stretchdelay {
  0%, 40%, 100% { 
    transform: scaleY(0.4);
    -webkit-transform: scaleY(0.4);
  }  20% { 
    transform: scaleY(1.0);
    -webkit-transform: scaleY(1.0);
  }
}
</style>     