<?php 
		$attr1= array('name' => 'frmIinvestorInstalment', 'id' => 'frmIinvestorInstalment', 'class'=> 'form-horizontal');
		echo form_open('#',$attr1);
  
       $MemberPh = '';
       $MemberCodePh = '';  
       $mdate 		= now();
       $Rdate 		= date("Y-m-d",$mdate); 
            
       if($v_data=='No'){ 
        
        echo "Invalid Investor";

       }
       else{
           $investorID  = $v_data->investorID ;
            $unitID  = $v_data->unitID ;
            $folio_no  = $v_data->folio_no ;
            $name  = $v_data->name ;
            $dob  = $v_data->dob ;
            $sex  = $v_data->sex ;
            $email  = $v_data->email ;
            $mobile_india  = $v_data->mobile_india ;
            $mobile_ksa  = $v_data->mobile_ksa ;
            $address_india  = $v_data->address_india ;
            $address_ksa  = $v_data->address_ksa ;
            $bloodgroup  = $v_data->bloodgroup ;
            $job_title  = $v_data->job_title ;
            $passport  = $v_data->passport ;
            $pancard  = $v_data->pancard ;
            $aadhar  = $v_data->aadhar ;
            $iqama  = $v_data->iqama ;
            $nominee_name  = $v_data->nominee_name ;
            $nominee_relation  = $v_data->nominee_relation ;
            $nominee_address  = $v_data->nominee_address ;
            $nominee_mobile  = $v_data->nominee_mobile ;
            $premium_type  = $v_data->premium_type ;
            $premium_amount  = $v_data->premium_amount ;
            $due_date  = $v_data->due_date ;
            $join_date  = $v_data->join_date ;
            $residence_status  = $v_data->residence_status ;
            $current_location  = $v_data->current_location ;
            $photo  = $v_data->photo ;
            $username  = $v_data->username ;
            $password  = $v_data->password ;
            $create_date  = $v_data->create_date ;
            $modify_date  = $v_data->modify_date ;
            $modify_userID  = $v_data->modify_userID ;
            $active  = $v_data->active ; 
        
  	
        $unitID = $this->session->userdata['mysession']['unit_id']; 
?>
  <input id="investorID" name="investorID" value="<?php echo $investorID; ?>" type="hidden" />
 
 
                                                         
   <div class="col-md-8"> 
           
            <div class="form-group"><label class="col-sm-4 control-label">Reference No</label>
                <div id="div1" class="col-sm-6"><input   value="" type="text" class="form-control" id="receipt_no" name="receipt_no"></div> 
           </div>
            
        
            <div class="form-group">
            	<label class="col-sm-4 control-label">Date of Contribution </label>
                <div class="col-sm-6">
                    <div class="input-group date" id="div2"> 
                         <span class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                         </span>
                            <input type="text"   class="form-control datepicker" value="<?php echo  $Rdate; ?>" id="receipt_date" name="receipt_date">
                    </div>
                </div>                                
            </div>     
            <div class="form-group">
            	<label class="col-sm-4 control-label">Amount</label>
                <div class="col-sm-6" id="div3"><input type="text" value="<?php echo  $premium_amount ; ?>" class="form-control" id="tran_amount_collection" name="tran_amount_collection"></div>
            </div>  
               
            <div class="form-group">
            	<label class="col-sm-4 control-label">Remarks</label>
                <div class="col-sm-6"><textarea class="form-control" value="" id="tran_description" name="tran_description" ></textarea></div>
           </div> 
            <div class="form-group">
             	<div class="hr-line-dashed"></div>
                          <div class="col-sm-4 col-sm-offset-2">
                            <a href="<?php echo base_url(); ?>index.php/Investor/Payment"> 
                                <button  id="cmdCancelInv" class="btn btn-primary" type="button">Cancel</button>
                            </a>
                            <button id="cmdSaveInv" class="btn btn-primary" type="button">Save </button>
				</div> 
                          
            </div>  
             
            
      </div>
       <div id="msg"></div>
      <div class="col-lg-4">
            <div class="widget-head-color-box navy-bg p-lg text-center">
                <div class="m-b-md">
                <h2 class="font-bold no-margins">
                    <?php echo '  '.$name; ?>
                </h2>
                    <small><?php echo 'Folio No : '.$folio_no; ?></small>
                </div> 
<?php
	$InvPhoto = 'assets/img/profile_small.jpg'; $Rand = md5(time());
    if(!empty($photo))
    $InvPhoto = 'photo/'.$photo.'?'.$Rand;
?>                
                <div class="text-center-block">
                    <img  src="<?php echo base_url().$InvPhoto;?>" width="100" height="100" class="img-circle circle-border   text-right" alt="Profile Photo">
                </div> 
                    <small><?php echo 'SR. '.$premium_amount; ?></small> 
                <div> 
                    <span></span>  
                </div>
            </div>
            <div class="widget-text-box">
                <h4 class="media-heading">Address</h4>
                <p><?php if(!empty($address_india)){echo 'India  : '.$address_india;} if(!empty($mobile_india)){echo '</br><i class="fa fa-mobile"></i>&nbsp;&nbsp;'.$mobile_india;} ?></p>
                <p><?php if(!empty($address_ksa)){echo 'KSA  : '.$address_ksa;}  if(!empty($mobile_ksa)){echo '</br><i class="fa fa-mobile"></i>&nbsp;&nbsp;'.$mobile_ksa; } ?></p>
                <p>
                    <?php
                           
                    ?>
                </p>
                 
            </div>
    </div>
                
                                                               
                                                        

 <?php
	echo form_close(); 
  
?>  
 <style>
 .datepicker{ z-index:99999 !important; }
 </style>
<script>
  $(function () {  

           
            $('.datepicker').datepicker({  
                format: 'yyyy-mm-dd',
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });
       
      
       $("#cmdSaveInv").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmIinvestorInstalment").serialize();   
                    //alert(values);
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/Investor/SaveInstalment",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({ 
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                }); 
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url();?>index.php/Investor/Payment");
                                  }, 1500);
                                
                                
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    });                                                                                                                        
                                                                            
                                   // ErrTab
                                swal(
                                      'Error...',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
});

</script> 



<?php
 }
?>