<?php 
		$attr1= array('name' => 'frmInvestor', 'id' => 'frmInvestor' );
		echo form_open(base_url().'index.php/Investor',$attr1);
        
        
         $AreaID = $this->session->userdata['mysession']['area_id'];
         if(empty($AreaID))
         $AreaID = 0;
         $Areaval = set_value('cmbArea',$AreaID); 
         
         $unitID = $this->session->userdata['mysession']['unit_id'];
         if(empty($unitID))
         $unitID = 0;
         $val1 = set_value('cmbUnit',$unitID); 
          
         
?>

            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5>Investors Details</h5>
                    	<div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
                    
                        <div class="form-group row">
                            <label class="col-sm-2 control-label text-right">Select Area Name</label>
                            <div class="col-sm-4">
                       			<?php
                        			$js ='id="cmbArea" class="form-control m-b"';
                        			echo   form_dropdown('cmbArea', $AreaList,$Areaval,$js);
                      			?>	
                            </div>
						                            
                        </div> 
                        
                        <div class="form-group">
                            <label class="col-sm-2 control-label text-right">Select Unit Name</label>
                            <div class="col-sm-4">
                       			<?php
                        			$js ='id="cmbUnit" class="form-control m-b"';
                        			echo   form_dropdown('cmbUnit', $UnitList,$val1,$js);
                      			?>	
                            </div>
							<?php
								if($val1>0){
							?>                           
	                            <label class="col-sm-4 control-label text-right"></label>
	                            <div class="col-sm-2">
	                                <a href="<?php echo base_url(); ?>index.php/Investor/Add">
	                                     <button class="btn btn-danger btn-sm " type="button"><i class="fa fa-plus-square"></i>&nbsp;Add Investor</button>
	                                 </a>
	                            </div>
							<?php
								   }
							?>                            
                        </div>
                      
                        <div class="form-group">
                        	<br>
                     			<div class="hr-line-dashed"></div>
                     	
                    
<?php
	
    if($v_data!= "No" &&  $val1!= 0)
    {
?>
                    <table class="table table-striped table-bordered table-hover dataTable1" id="TblInvList" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th width=10%>Folio No</th>
                        <th>Name</th>
                        <th width=15%>Mobile KSA</th>
                        <th width=10%>Contribution</th> 
                        <th width=10%></th>
                    </tr>
                    </thead>
                    <tbody>
<?php
    $loop = 0; $Amount = 0;
    	foreach ($v_data->result() as $r)
     	 { 
     	  $loop = $loop + 1;
          $Amount = $Amount + $r->premium_amount;
?>
                    <tr class="gradeX">
                        <td><?php  echo $loop; ?></td>
                        <td><?php  echo $r->folio_no; ?></td>
                        <td><?php  echo $r->name; ?></td>
                        <td><?php  echo $r->mobile_ksa; ?></td>
                        <td  align="right"><?php  echo $r->premium_amount; ?></td> 
                        <td >
                        <a TypeID="1"  intID = "<?php  echo $r->investorID; ?>" href="#" class="ActionInv" title="Edit"><i class="fa fa-edit fa-2x  "></i></a> 
                        <a  TypeID="3"  intID = "<?php  echo $r->investorID; ?>" href="#" class="ActionInv" title="Show Details"> <i class="fa fa-eye fa-2x  "></i></a> 
                        <a  TypeID="2"  intID = "<?php  echo $r->investorID; ?>" href="#" class="ActionInv" title="Ledger"><i class="fa fa-list-alt fa-2x  " ></i></a></td>
                    </tr>
<?php
        }
 
?> 
                    
                    </tbody>
                     <tfoot>
                    <tr>
                        <th> </th>
                        <th> </th>
                        <th> </th>
                        <th>Total</th>
                        <th class="text-right"><?php echo $Amount; ?></th>
                        <th> </th>
                    </tr>
                    </tfoot> 
                    </table>
<?php
        }
        else
        {
            if( $val1> 0) 
            {
?>	
                <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins"> 
                               Add Investors Detail 
                            </h3>
                            <small>Please add investors detail using "Add" button </small>    
                        </div>
                    </div>

  <?php          
            }
            else
            {
?>
                <div class="widget navy-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins">
                             Select Unit Name
                            </h3>
                            <small>Please select a unit from the combobox</small>
                        </div>
                </div>
  <?php                 
            }
        }
 
?>

                  	</div>
                  </div>
                </div>
            </div>
            </div>            
<input type="submit"  id="cmdSubmit" hidden="hidden" />
<?php
	echo form_close();
    
  
		$attr1= array('name' => 'frmInvestorEdit', 'id' => 'frmInvestorEdit');
		echo form_open(base_url().'index.php/Investor/Select',$attr1);
        
        echo '<input  id="investorID" name="investorID" value="0" type="hidden"/>';
        echo '<input id="TypeID" name="TypeID" value="0" type="hidden"/>  ';
        echo '<input type="submit"  id="cmdEdit" value="22" hidden="hidden" />';
        echo form_close();                                
?>	
     
<script>
	
$(document).ready(function()
{

     $('#cmbUnit').change(function (event){
        
            var  UnitID = $('#cmbUnit').val();  
            $.ajax({
    			type:"POST",
    			url:"<?php echo base_url(); ?>index.php/Investor/SetUnit",
    			data:{UnitID:UnitID},
    			success:function(data)
    			{
    			  
    			}
    	   });
                        
         $('#cmdSubmit').click();
     });
     
     $('#cmbArea').change(function (event){
        
            var  AreaID = $('#cmbArea').val();  
            $.ajax({
    			type:"POST",
    			url:"<?php echo base_url(); ?>index.php/Investor/SetArea",
    			data:{AreaID:AreaID},
    			success:function(data)
    			{
    			  
    			}
    	   });
                        
         $('#cmdSubmit').click();
     });
    
     $('.ActionInv').click(function (event) {
			var InvID = $(this).attr('intID');
            var TypeID = $(this).attr('TypeID');   
            if(InvID>0){                        
                $('#investorID').val(InvID);                     
                $('#TypeID').val(TypeID); 
               $('#cmdEdit').click();
            }                
     });

}); 

</script>       