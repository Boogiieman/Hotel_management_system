<?php 
		$attr1= array('name' => 'frmIinvestorInstalment', 'id' => 'frmIinvestorInstalment', 'class'=> 'form-horizontal');
		echo form_open('#',$attr1);
  
       $MemberPh = '';
       $MemberCodePh = '';  
       $mdate 		= now();
       $Rdate 		= date("Y-m-d",$mdate); 
            
       if($v_data=='No'){ 
        
        echo "Invalid Investor";

       }
       else{
           $investorID  = $v_data->investorID ;
            $unitID  = $v_data->unitID ;
            $folio_no  = $v_data->folio_no ;
            $name  = $v_data->name ;
            $dob  = $v_data->dob ;
            $sex  = $v_data->sex ;
            $email  = $v_data->email ;
            $mobile_india  = $v_data->mobile_india ;
            $mobile_ksa  = $v_data->mobile_ksa ;
            $address_india  = $v_data->address_india ;
            $address_ksa  = $v_data->address_ksa ;
            $bloodgroup  = $v_data->bloodgroup ;
            $job_title  = $v_data->job_title ;
            $passport  = $v_data->passport ;
            $pancard  = $v_data->pancard ;
            $aadhar  = $v_data->aadhar ;
            $iqama  = $v_data->iqama ;
            $nominee_name  = $v_data->nominee_name ;
            $nominee_relation  = $v_data->nominee_relation ;
            $nominee_address  = $v_data->nominee_address ;
            $nominee_mobile  = $v_data->nominee_mobile ;
            $premium_type  = $v_data->premium_type ;
            $premium_amount  = $v_data->premium_amount ;
            $due_date  = $v_data->due_date ;
            $join_date  = $v_data->join_date ;
            $residence_status  = $v_data->residence_status ;
            $current_location  = $v_data->current_location ;
            $photo  = $v_data->photo ;
            $username  = $v_data->username ;
            $password  = $v_data->password ;
            $create_date  = $v_data->create_date ;
            $modify_date  = $v_data->modify_date ;
            $modify_userID  = $v_data->modify_userID ;
            $active  = $v_data->active ; 
        
  	
        $unitID = $this->session->userdata['mysession']['unit_id']; 
?>
  <input id="investorID" name="investorID" value="<?php echo $investorID; ?>" type="hidden" />
 <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Investor Payment</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Investor</a>
                        </li>
                        <li class="active">
                            <strong>Payment</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Add Instalment details <small> This form helps to add new instalment details and instalment details</small></h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <!--
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="<?php echo base_url(); ?>index.php/job/index">Search Job</a></li>
                                    <li><a href="#">Job - Status</a></li>
                                    <li><a href="#">Client wise other jobs</a></li>
                                </ul>
                                -->
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                             
                            
                                     <div class="row">
                                        <div class="col-lg-12">
                                            <div class="panel blank-panel">
                        
                                                <div class="panel-heading">
                                                    <!--  <div class="panel-title m-b-md">
                                                    			<small>Please fill all mandatory fields</small>
                                                    </div>-->
                                                    <div class="panel-options">
                        
                                                        <ul class="nav nav-tabs">
                                                            <li id="tab1" class="active"><a data-toggle="tab" href="#tab-1" aria-expanded="true">Basic Details</a></li>
                                                           <!-- <li id="tab2" class=""><a data-toggle="tab" href="#tab-2" aria-expanded="false">Premium</a></li>
                                                           --!>
                                                            <li id="tab2" class=""><a data-toggle="tab" href="#tab-2" aria-expanded="false">Last Payment Details</a></li> 
                                                        </ul>
                                                    </div>
                                                </div>
                        
                                                <div class="panel-body">
                        
                                                    <div class="tab-content">
                                                        
                                                        <div id="tab-1" class="tab-pane active">
                                                         
                                                           <div class="col-md-6"> 
                                                                   
                                                                    <div class="form-group"><label class="col-sm-4 control-label">Receipt No</label>
                                                                        <div id="div1" class="col-sm-6"><input   value="" type="text" class="form-control" id="receipt_no" name="receipt_no"></div> 
                                                                   </div>
                                                                    
                                                                
                                                                    <div class="form-group">
                                                                    	<label class="col-sm-4 control-label">Date of Receipt </label>
                                                                        <div class="col-sm-6">
                                                                            <div class="input-group date" id="div2"> 
                                                                                 <span class="input-group-addon">
                                                                                    <i class="fa fa-calendar"></i>
                                                                                 </span>
                                                                                    <input type="text"   class="form-control" value="<?php echo  $Rdate; ?>" id="receipt_date" name="receipt_date">
                                                                            </div>
                                                                        </div>                                
                                                                    </div>     
                                                                    <div class="form-group">
                                                                    	<label class="col-sm-4 control-label">Amount</label>
                                                                        <div class="col-sm-6" id="div3"><input type="text" value="<?php echo  $premium_amount ; ?>" class="form-control" id="tran_amount_collection" name="tran_amount_collection"></div>
                                                                    </div>  
                                                                       
                                                                    <div class="form-group">
                                                                    	<label class="col-sm-4 control-label">Remarks</label>
                                                                        <div class="col-sm-6"><textarea class="form-control" value="" id="tran_description" name="tran_description" ></textarea></div>
                                                                   </div> 
                                                                    <div class="form-group">
                                                                     	<div class="hr-line-dashed"></div>
                                                                                  <div class="col-sm-4 col-sm-offset-2">
                                                                                    <a href="<?php echo base_url(); ?>index.php/Investor/Payment"> 
                                                                                        <button  id="cmdCancelInv" class="btn btn-primary" type="button">Cancel</button>
                                                                                    </a>
                                                                                    <button id="cmdSaveInv" class="btn btn-primary" type="button">Save </button>
                                                     					</div> 
                                                                                 <div id="msg"></div>  
                                                                    </div>  
                                                                     
                                                                    
                                                              </div>
                                                              
                                                              <div class="col-lg-6">
                                                                    <div class="widget-head-color-box navy-bg p-lg text-center">
                                                                        <div class="m-b-md">
                                                                        <h2 class="font-bold no-margins">
                                                                            <?php echo '  '.$name; ?>
                                                                        </h2>
                                                                            <small><?php echo 'Fol No : '.$folio_no; ?></small>
                                                                        </div>
                                                                         <div class="col-xs-4">
                                                                            <h1 class="m-xs"><?php echo '$'.$ClosingBlns; ?> </h1>
                                                                        </div>
                                                                        
                                                                        <div class="text-right">
                                                                            <img  src="<?php echo base_url();?>assets/img/profile_small.jpg" width="100" height="100" class="img-circle circle-border   text-right" alt="Profile Photo">
                                                                        </div> 
                                                                        
                                                                        <div> 
                                                                            <span><?php echo 'Premium : '. $premium_amount ; ?></span>  
                                                                        </div>
                                                                    </div>
                                                                    <div class="widget-text-box">
                                                                        <h4 class="media-heading">Address</h4>
                                                                        <p><?php if(!empty($address_india)){echo 'Address India  : '.$address_india;} ?></p>
                                                                        <p><?php if(!empty($address_ksa)){echo 'Address India  : '.$address_ksa;} ?></p>
                                                                        <div class="text-right">
                                                                            <a  TypeID="2"  InvID = "<?php  echo $investorID; ?>" class="btn btn-xs btn-white ActionInv" href="#" ><i class="  fa fa-shield"></i> Ledger </a>
                                                                            <a  TypeID="1"  InvID = "<?php  echo $investorID; ?>" class="btn btn-xs btn-primary ActionInv" href="#" ><i class="fa fa-edit"></i> Edit</a>
                                                                        </div>
                                                                    </div>
                                                            </div>
                
                                                               
                                                                                                                 
                                                        </div>
                                                        
                                                        <div id="tab-2" class="tab-pane">
                                                         <!---    Instalment List --!>  
                                                                    <div class="col-lg-12">
                                                                        <div class="ibox float-e-margins">
                                                                            <div class="ibox-title">
                                                                                <h5>Basic Data Tables example with responsive plugin</h5>
                                                                                <div class="ibox-tools">
                                                                                    <a class="collapse-link">
                                                                                        <i class="fa fa-chevron-up"></i>
                                                                                    </a> 
                                                                                    <a class="close-link">
                                                                                        <i class="fa fa-times"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="ibox-content">
                                                        
                                                                            <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline" id="DataTablesTable0" role="grid" aria-describedby="DataTablesTable0_info">
                                                                            <thead>
                                                                            <tr role="row">
                                                                                <th class="sorting_asc" tabindex="0" aria-controls="DataTablesTable0" rowspan="1" colspan="1"  style="width: 5%;" aria-sort="ascending">Sl No</th>
                                                                                <th class="sorting" tabindex="0" aria-controls="DataTablesTable0" rowspan="1" colspan="1"  style="width: 10%">Amount</th>
                                                                                <th class="sorting" tabindex="0" aria-controls="DataTablesTable0" rowspan="1" colspan="1"   style="width: 15%;">Receipt No.</th>
                                                                                <th class="sorting" tabindex="0" aria-controls="DataTablesTable0" rowspan="1" colspan="1"  style="width: 10%;">Date</th>
                                                                                <th class="sorting" tabindex="0" aria-controls="DataTablesTable0" rowspan="1" colspan="1"  style="width: 60%;">Collected User</th></tr>
                                                                            </thead>
                                                                            <tbody> 
                                                                            <?php 
                                                                                $loop = 0;
                                                                            	
                                                                                if($v_list!='No')
                                                                                {
                                                                                    foreach ($v_list->result() as $r)
                                                                                 	{ 
                                                                             	          $loop = $loop + 1;
                                                                            ?>
                                                                                <tr class="gradeA odd" role="row">
                                                                                
                                                                                    <td class="sorting_1"><?php echo $loop;  ?>  </td>
                                                                                    <td><?php echo $r->tran_amount_collection;  ?></td>
                                                                                    <td><?php echo $r->receipt_no;  ?></td>
                                                                                    <td class="center"><?php echo $r->receipt_date;  ?></td>
                                                                                    <td class="center"><?php echo $r->User_Name;  ?></td>
                                                                                </tr>
                                                                              <?php 
                                                                                    } 
                                                                                 }
                                                                              ?>  
                                                                             </tbody>
                                                                             
                                                                            </table> 
                                                                    </div> 
                                                                </div> 
                                                            </div>                                                   
                                                                                                                    
                                                         <!---   / Instalment List --!>                                                               
                                                            
                                                            
                                                        </div>
                                                        
                                                        
                                                    </div> 
                                                      
                                                            
                                                </div>
                        
                                            </div>
                                        </div> 
                                    </div>     
                                                          
                            
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

 <?php
	echo form_close();
    
    		$attr1= array('name' => 'frmInvestorEdit', 'id' => 'frmInvestorEdit');
		echo form_open(base_url().'index.php/Investor/Select',$attr1);
        
        echo '<input  id="investorID" name="investorID" value="0" type="hidden" />';
        echo '<input id="TypeID" name="TypeID" value="0"  type="hidden"/> ';
        echo '<input type="submit"  id="cmdEdit" value="22" hidden="hidden" />';
        echo form_close();  
        
        
  
?>  

<script>
  $(function () {
    
    $('#DataTablesTable0').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip' 
   });
            
    
   $('.ActionInv').click(function (event) {
			var InvID = $(this).attr('InvID');
            var TypeID = $(this).attr('TypeID');   
            if(InvID>0){                        
                $('#investorID').val(InvID);                     
                $('#TypeID').val(TypeID); alert(InvID);
                $('#cmdEdit').click();
            }                
     });
     
      
      $("#cmdSaveInv").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmIinvestorInstalment").serialize();   
                    //alert(values);
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/Investor/SaveInstalment",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({
                                  position: 'top-right',
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                }); 
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url();?>index.php/Investor/Payment");
                                  }, 1500);
                                
                                
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    });                                                                                                                        
                                                                            
                                   // ErrTab
                                swal(
                                      'Error...',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
        
        
            $('.input-group.date').datepicker({
                format: 'yyyy-mm-dd',
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });
      
});

</script> 



<?php
 }
?>