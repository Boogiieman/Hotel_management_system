<?php
if($v_details!="No")
{
	$Folio_No	=	$v_details->folio_no;
	$name		=	$v_details->name;
	$address	=	$v_details->address_india;	
}
else
{
	$Folio_No	=	$FolioNo;
	$name		=	"";
	$address	=	"";
}

    if($MyLedger == 1){ 
         
         $InvID = $this->session->userdata['mysession']['inv_id'];
         if(empty($InvID))
         $InvID = 0;
         $Val = set_value('InvestorID',$InvID); 
     }        
?>
 			<div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5><?php echo $head_label; ?></h5>
                    	<div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
 <?php
	if($MyLedger == 1){ 
?>
                            <form method="post" class="form-horizontal" action="MyLedger">
 <?php
	}
    else
    {
?>                           
                            <form method="post" class="form-horizontal" action="ledger">
                                   
  <?php
	}
?>                                  
                                    
                                     <div class="row">
                                        <div class="col-lg-12">                                               
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Folio No</label>
                                                                <div class="col-sm-3">
                                                                
                                                                    
                                                               <?php
                                                                   if($MyLedger == 1)
                                                                  {
                                                        			$js ='id="InvestorID" class="form-control m-b"';
                                                        			echo   form_dropdown('InvestorID', $MapdUsersFolio,$Val,$js);
                                                      	          }
                                                                  else
                                                                  {
                                                                    echo ' <input type="text" class="form-control" id="InvestorID" name="InvestorID" value="' .$Folio_No.'">';
                                                                  }
                                                              
                                                              
                                                              	?>	
                                                               
                                                                </div>
                                                                 
							     	
							      
                                                                
                                                                <div class="col-sm-4  ">
                                                                    <button class="btn btn-primary" type="submit" id="cmdSubmit">Show</button>
                                     							<?php
	                                                               if($v_ledgerdetails!="No") { 
?>
                                                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                                                    <button class="btn btn-danger " type="button" id="cmdPDF"><i class="fa fa-file-pdf-o"></i>&nbsp;Export to PDF</button>
                                                                
                                                                <?php
	                                                                   }            
?> 
                                                                 </div>                                                                                              
                                                            </div>     
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Investor Name</label>
																<div class="col-sm-3"><?php echo $name; ?></div>																
                                                             	<label class="col-sm-2 control-label">Address</label> 
                                                                <div class="col-sm-3"><?php echo $address; ?></div>                                   
                                                            </div> 
                                            </div>
                                        </div> 
                                        <div class="form-group">
                                     	<div class="hr-line-dashed"></div>

                    <table class="table table-striped table-bordered table-hover dataTable1" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th width=10%>Tran.Date</th>
                        <th>Remarks</th>
                        <th width=15%  align="center">Collection</th>
                        <!--<th width=15%  align="center">Dividend</th>-->
                        <th width=15%  align="center">Withdrawal/Charges</th>
						<th width=15%  align="center">Balance</th>
						<th width=10%  align="center">Status</th>
                    </tr>
                    </thead>
                    <tbody>
<?php
	$total_collection=0;
	$total_Dividend=0;
	$total_Withdrawal=0;
    $InvID = 0;
if($v_ledgerdetails!="No")
{
    $loop = 0;
	$runningBalance=0;
    foreach ($v_ledgerdetails->result() as $r)
     	 { 
     	  $loop = $loop + 1;
          $InvID=$r->invester_id;
		  $runningBalance=$runningBalance+$r->sumamt;
?>
                    <tr class="gradeX">
                        <td><?php  echo $loop; ?></td>
                        <td><?php  echo $r->tran_date;?></td>
                        <td><?php  echo $r->tran_description; ?></td>
                        
                        <td  align="right"><?php  echo number_format($r->Collection,2); ?></td>
                        <!--<td align="right"><?php  echo number_format($r->Dividend,2); ?></td>-->
                        <td align="right"><?php  echo number_format($r->Withdrawal,2); ?></td>
						<td align="right"><?php  echo number_format($runningBalance,2); ?></td>
						<td><?php  echo $r->TranStatus; ?></td>	
						<?php 
							$total_collection=$total_collection+$r->Collection;
							//$total_Dividend=$total_Dividend+$r->Dividend;;
							$total_Withdrawal=$total_Withdrawal+$r->Withdrawal;
						?>						
                    </tr>
<?php
        }
}
?>           
                    </tbody> 
<thead>
                    <tr>
                        <th></th>
                        <th></th>
                        <th><div align="right">Total</th>
                        <th><div align="right"><?php echo number_format($total_collection,2) ?></div></th>
                        <!--<th><div align="right"><?php echo number_format($total_Dividend,2) ?></div></th>-->
                        <th><div align="right"><?php echo number_format($total_Withdrawal,2) ?></div></th>						
                        <th><div align="right"></div></th>
						<th  ></th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th><div align="right">Balance</th>  
						<?php $balance_amount= $total_collection-$total_Withdrawal; ?>						
                        <th colspan=3><div align="right"><?php echo number_format($balance_amount,2) ?></div></th>                        
						<th  ></th>
                    </tr>
                    </thead>					
                    </table>                
                                     	</div>             
                            </form>
                        </div>
                    </div>
                </div>
            </div>

<?php
      
		$attr1= array('name' => 'frmInvLedger', 'id' => 'frmInvLedger');
		echo form_open(base_url().'index.php/Reports/InvLedgerPDF',$attr1);
        
        echo '<input  id="InvestorID" name="InvestorID" value="'.$InvID. '" type="hidden"/>'; 
        echo '<input type="submit"  id="cmdReport" value="Pdf" hidden="hidden" />'; 
        echo form_close();                                
?>	

<script>
$(document).ready(function()
{
  $('#cmdPDF').click(function (event) { $('#cmdReport').click(); }); 
 <?php
	   if($MyLedger == 1){ 

?> 
    $('#InvestorID').change(function (event){
    
        var  InvID = $('#InvestorID').val(); 
        $.ajax({
			type:"POST",
			url:"<?php echo base_url(); ?>index.php/Investor/SetInvID",
			data:{InvID:InvID},
			success:function(data)
			{
			  $('#cmdSubmit').click();
			}
	   }); 
       
 });
 
 
 <?php
	}
?>

});
</script>