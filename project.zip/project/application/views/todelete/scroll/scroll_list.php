 

            <div class="row"  id="InnerDiv">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5>Scroll News List <span class="text-danger"> </span></h5>
                    	<div class="ibox-tools">
                        <button type="button" class="btn btn-sm btn-danger NewsAdd" NewsID="0" data-toggle="modal" data-target="#NewsScreen" >New Scroll</button>
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
                    
                        <div class="form-group"> 
                     			 
                     	
                    
<?php 
    
    if($v_data!= "No" )
    {
?>
                    <table class="table table-striped table-bordered table-hover dataTable1" id="TblInvList" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th width=15%>Subject</th>
                        <th width=45%>Scroll News</th>
                        <th class="text-center" width=30%>Status Details</th> 
                        <th width=5%></th>
                    </tr>
                    </thead>
                    <tbody>
<?php
    $loop = 0;
    	foreach ($v_data->result() as $r)
     	 { 
     	  $loop = $loop + 1;
            $User1 = $UserList[$r->create_userid];
            $User2 = $UserList[$r->delete_userid];
          if($r->scroll_status==1) {
            $Details = '<div class="text-center"> <p><span class="badge badge-primary">Active</span></p></div> ';
            $Label = 'Delete';
            $Details.= "Created by $User1 on $r->create_date ";
            if($r->delete_userid>0)
            $Details.= " </br> Status changed by $User2 on$r->delete_date ";

            $Status = 2;
          }
          else{
             $Details = '<div class="text-center"><p><span class="badge badge-danger">Deleted</span></p></div> ';
             $Label = 'Enable'; 
             $Details.= "Created by $User1 on $r->create_date </br> Deleted by $User2 on$r->delete_date ";
             $Status = 1 ; 
          }
          
?>
                    <tr class="gradeX">
                        <td><?php  echo $loop; ?></td>
                        <td><?php  echo $r->subject; ?></td>
                         <td><?php  echo $r->scroll_news; ?></td> 
                         <td><?php  echo $Details; ?></td>  
                        <td > 
                            <div id="<?php  echo 'divSbmt'.$r->scroll_id; ?>">
 
                                   
                                     <div class="btn-group">
                                        <button data-toggle="dropdown" class="btn  dim dropdown-toggle" aria-expanded="false">
                                         <i class="fa fa-edit fa-2x text-danger"></i>
                                         </button>
                                        <ul class="dropdown-menu">
                                            <li><a href="#" class="NewsAdd" NewsID = "<?php echo $r->scroll_id; ?>" data-toggle="modal" data-target="#NewsScreen" >Edit</a></li> 
                                            <li class="divider"></li>
                                            <li><a  href="#" Sts = "<?php echo $Status; ?>" NewsID = "<?php echo $r->scroll_id; ?>" class="text-danger Submit"><?php echo $Label; ?></a></li>
                                        </ul>
                                    </div>
                            </div>
                        </td>
                            
                    </tr>
<?php
        }
 
?> 
                    
                    </tbody>
 
                    </table>
                    <div id="errDiv"></div>
<?php
        }
        else
        {
             
?>	
                    <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell-slash fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins "> 
                                 No pending receipts available for approval
                            </h3>
                            <small> </small>    
                        </div>
                    </div>

  
  <?php                 
            
        }
 
?>

                  	</div>
                  </div>
                </div>
            </div>
 </div>            
<!-- Modal -->
 <div class="modal inmodal fade" id="NewsScreen" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg"  >
        <div class="modal-content animated bounceInRight">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title"> Scroll News Details</h4>
            </div>
            <div class="modal-body" id="divScNews" style="min-height: 270px;">
                 <div class="spinner" style="margin-left: 40%;">
                  <div class="rect1"></div>
                  <div class="rect2"></div>
                  <div class="rect3"></div>
                  <div class="rect4"></div>
                  <div class="rect5"></div>
                </div>
            </div>
            <div class="modal-footer"> 
            </div>
        </div>
    </div>
</div> 
     
<script>
	
$(document).ready(function()
{
    var spinner = '<div class="spinner" style="margin-left: 40%;"> <div class="rect1"></div> <div class="rect2"></div> <div class="rect3"></div> <div class="rect4"></div> <div class="rect5"></div> </div>'

     
     $('.Submit').click(function (event) {
			  var NewsID = $(this).attr('NewsID'); 
              var StsID = $(this).attr('Sts');
		    //  var DivID = '#divSbmt'+NewsID ;
      //   $(DivID).html('<i class="fa fa-refresh fa-spin  fa-2x text-warning"></i>');
                        swal({ 
    							type: '', // Title 
    							allowOutsideClick: false,
    							showSpinner: true,
    							closeOnEsc: false,
    							html: "Please wait .....<i class='fa fa-spin fa-1x fa-fw'><i class='fa fa-cog'></i></i> ",
    							showConfirmButton: false
							});
                            
         if(NewsID > 0 ){ 
          	$.ajax({
            			type: "POST",
            			url: "<?php echo base_url();?>index.php/Scroll/ChangeStatus",
            			data: {NewsID:NewsID,StsID:StsID}, 
                        dataType: "json",
            			success: function(msg)
            			{  
                            swal.close();
                          if(msg.Success==1){
                            swal({ 
                                  type: 'success',
                                  title: 'Successfully Change Status',
                                  showConfirmButton: false,
                                  timer: 1500
                                }); 
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url();?>index.php/Scroll");
                                  }, 1500);
                          }
                          else{
                                swal(
                                  'Error...',
                                  msg.msg,
                                  'error'
                                );
                          }
                        },
                	    error: function(jqXHR, textStatus, errorThrown) 
                	    {  alert(jqXHR.responseText); }
            		
            		});	 
          }  
     });
     
   $('.NewsAdd').click(function (event) { //alert(' ');
		 	var NewsID = $(this).attr('NewsID');   
            //alert(NewsID);
		 $('#divReceipt').html(spinner);
    	 	$.ajax({
        			type: "POST",
        			url: "<?php echo base_url();?>index.php/Scroll/AddNews",
        			data: {NewsID:NewsID}, 
        			success: function(msg)
        			{ $('#divScNews').html(msg) ; },
            	    error: function(jqXHR, textStatus, errorThrown) 
            	    {  
            	       //alert(jqXHR.responseText); alert(errorThrown);('#divScNews').html(jqXHR.responseText);
                    }
        		
        		});	  
           
     });      

}); 

</script>  


<style>
.spinner {
  /* margin: 150px auto; */
  width: 80px;
  height: 150px;
  text-align: center;
  font-size: 20px;
}

.spinner > div {
  background-color: #1ab394;
  height: 100%;
  width: 6px;
  display: inline-block;
  
  -webkit-animation: sk-stretchdelay 1.2s infinite ease-in-out;
  animation: sk-stretchdelay 1.2s infinite ease-in-out;
}

.spinner .rect2 {
  -webkit-animation-delay: -1.1s;
  animation-delay: -1.1s;
}

.spinner .rect3 {
  -webkit-animation-delay: -1.0s;
  animation-delay: -1.0s;
}

.spinner .rect4 {
  -webkit-animation-delay: -0.9s;
  animation-delay: -0.9s;
}

.spinner .rect5 {
  -webkit-animation-delay: -0.8s;
  animation-delay: -0.8s;
}

@-webkit-keyframes sk-stretchdelay {
  0%, 40%, 100% { -webkit-transform: scaleY(0.4) }  
  20% { -webkit-transform: scaleY(1.0) }
}

@keyframes sk-stretchdelay {
  0%, 40%, 100% { 
    transform: scaleY(0.4);
    -webkit-transform: scaleY(0.4);
  }  20% { 
    transform: scaleY(1.0);
    -webkit-transform: scaleY(1.0);
  }
}
</style>     