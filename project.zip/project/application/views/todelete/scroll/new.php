<?php 
		$attr1= array('name' => 'frmScrollNews', 'id' => 'frmScrollNews', 'class'=> 'form-horizontal');
		echo form_open('#',$attr1);
 
      
       if($v_data=='No'){ 
        
            $scroll_id  =   0;
            $subject  =   '';
            $scroll_news  =   ''; 


       }
       else{
           $scroll_id  = $v_data->scroll_id ;
            $subject  = $v_data->subject ;
            $scroll_news  = $v_data->scroll_news ; 
            $sort_order  = $v_data->sort_order ;

       } 
       
       
 
	
        $unitID = $this->session->userdata['mysession']['unit_id'];
         
?>
  
  <input id="scroll_id" name="scroll_id" value="<?php echo $scroll_id; ?>" type="hidden" />
 
 
                                                         
   <div class="col-md-12"> 
           
            <div class="form-group"><label class="col-sm-4 control-label">Subject</label>
                <div id="div1" class="col-sm-6"><input   value="<?php echo $subject; ?>" type="text" class="form-control" id="subject" name="subject"></div> 
           </div>
            <div class="form-group"><label class="col-sm-4 control-label">Sort Order</label>
                <div id="div2" class="col-sm-6"><input   value="<?php echo $sort_order; ?>" type="number" class="form-control" id="sort_order" name="sort_order"></div> 
           </div>
           
          <div class="form-group">
            	<label class="col-sm-4 control-label">Scroll News</label>
                <div class="col-sm-6"><textarea rows="5" style="width: 100%;" class="form-control"  id="scroll_news" name="scroll_news" ><?php echo $scroll_news; ?></textarea></div>
           </div> 
           
            <div class="form-group">
             	<div class="hr-line-dashed"></div>
                     <div class="col-sm-6 col-sm-offset-2 text-right" >
                            <a href="<?php echo base_url(); ?>index.php/Scroll"> 
                                <button  id="cmdCancelScroll" class="btn btn-primary" type="button">Cancel</button>
                            </a>
                            <button id="cmdSaveScroll" class="btn btn-primary" type="button">Save </button>
				</div> 
                          
            </div>  
             
            
      </div>
       <div id="msg"></div>                                
                                                        

 <?php
	echo form_close(); 
  
?>  
 <style>
 .datepicker{ z-index:99999 !important; }
 </style>
<script>
  $(function () {  

           
            
       
      
       $("#cmdSaveScroll").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmScrollNews").serialize();   
                    //alert(values);
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                 //       $("#divMemBody").find("*").prop("disabled", true);  
                   swal({ 
							type: '', // Title 
							allowOutsideClick: false,
							showSpinner: true,
							closeOnEsc: false,
							html: "Please wait .....<i class='fa fa-spin fa-1x fa-fw'><i class='fa fa-cog'></i></i> ",
							showConfirmButton: false
							});

                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/Scroll/SaveNews",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            swal.close();
                            
                            if(data.Success==1){
                                swal({ 
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                }); 
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url();?>index.php/Scroll");
                                  }, 1500);
                                
                                
                            }
                            else{
                                
                                
                                swal(
                                      'Error...',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
});

</script> 

 