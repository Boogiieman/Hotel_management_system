<?php
		$attr1= array('name' => 'frmUserDetails', 'id' => 'frmUserDetails', 'class'=> 'form-horizontal');
		echo form_open('#',$attr1);
        
        $UserTypeVal  =  $this->session->userdata['mysession']['user_type_id'];
        
    	if($v_data=="No")
    	{		
            $user_id  =  0;
            $enterprise_id  =  $this->session->userdata['mysession']['enterprise_id'];
            $office_id  =   0;
            $user_code  =   '';
            $user_name  =   '';
            $user_status  =   1;
            $user_type_id  =   0;
            $email  =   '';
            $mobile  =   '';
            $isFirstLogin  =   0;
            $folio_number='';
            $v_formOpen='users';
    	}
    	else 
    	{
            $user_id  =  $v_data->user_id;
            $enterprise_id  =  $this->session->userdata['mysession']['enterprise_id'];
            $office_id  =   $v_data->office_id;
            $user_code  =   $v_data->User_Code;
            $user_name  =   $v_data->User_Name;
            $user_status  =   $v_data->UserStatus;
            $user_type_id  =   $v_data->TypeID;
            $email  =   $v_data->email;
            $mobile  =   $v_data->mobile;
            $isFirstLogin  =   $v_data->isFirstLogin;
            $folio_number =$v_data->folio_number;
            $v_formOpen='users';
    	}
?>		
 			
           
             
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>User details <small> </small></h5>
                            
                        </div>
                        <div class="ibox-content">
                            <form method="post" class="form-horizontal" name="frmUserDetails" id="frmUserDetails">
                                    <input type="hidden"  id="user_id" name="user_id" value="<?php echo $user_id; ?>"/> 
                                    <input type="hidden"  id="enterprise_id" name="enterprise_id" value="<?php echo $enterprise_id; ?>"/> 
                                    <input type="hidden"  id="office_id" name="office_id" value="<?php echo $office_id; ?>"/> 
                                    <input type="hidden"  id="v_formOpen" name="v_formOpen" value="<?php echo $v_formOpen; ?>"/> 
                                    
                                     <div class="row">
                                        <div class="col-lg-12">
                                            <div class="panel blank-panel"> 
                                                <div class="panel-body">
                                                    <div class="tab-content">
                                                        <div id="tab-1" class="tab-pane active">
                                                        	<div class="form-group">
                                                            	<label class="col-sm-2 control-label">Login Name</label>
                                                                <div class="col-sm-3" id="div1"><input type="text" class="form-control" id="User_Code" name="User_Code" value="<?php echo $user_code ?>"></div> 
                                                                <label class="col-sm-2 control-label">User Type</label>
                                                                <div class="col-sm-3" id="div2">
                                                                    <?php
                                                                        $js ='id="TypeID" class="form-control m-b"';
                                                                        $DefaultValue = set_value('TypeID',$user_type_id); 
                                                                        echo   form_dropdown('TypeID',$UserType ,$DefaultValue,$js);
                                                                    ?>
                                                                </div> 
                                                            </div>    
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Name of User</label>
                                                                <div class="col-sm-3" id="div3"><input type="text" class="form-control" id="User_Name" name="User_Name" value="<?php echo $user_name; ?>"></div>                                                                                              
                                                            	<label class="col-sm-2 control-label">Phone No/Mobile</label>
                                                                <div class="col-sm-3"  id="div7"><input type="text" class="form-control" id="mobile" name="mobile"  value="<?php echo $mobile; ?>"></div>                                                                

                                                            </div>  
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">eMail id</label>
                                                                <div class="col-sm-3"  id="div5"><input type="text" class="form-control" id="email" name="email" value="<?php echo $email; ?>"></div>
                                                                <label class="col-sm-2 control-label text-right">User Status</label>
                                                                <div class="col-sm-3" id="div8">
                                                                        <?php
                                                                            $js ='id="UserStatus" name="UserStatus" class="form-control m-b"';
                                                                            $DefaultValue = set_value('UserStatus',$user_status); 
                                                                            echo   form_dropdown('UserStatus', $UserStatus,$DefaultValue,$js);
                                                                        ?>	
                                                                </div>
                                                             </div>                                                                 
  
                                                                                                            
                                                                        
                                                            <div class="form-group">
                                                            	<label class="col-sm-5 control-label"><div id="msg"></div></label>                                                                
                                                            </div>                                                                                                                                                                   
                                                        </div>
                                                    </div>  
                                                </div>
                        
                                            </div>
                                        </div> 
                                    </div>     
                                     <div class="form-group">
                                     	<div class="hr-line-dashed"></div>
                                                  <div class="col-sm-4 col-sm-offset-2">
                                                    <a href="<?php echo base_url().'index.php/'.$v_formOpen; ?>"> 
                                                        <button  id="cmdCancel" class="btn btn-primary" type="button">Cancel</button>
                                                    </a>
                                                    <button id="cmdSave" class="btn btn-primary" type="button">Save </button>
                     							</div>  
                                     	</div>                      
                            </form>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        
 
        
 <?php
	echo form_close();
?>  

<script>
  $(function () {
 
      
      $("#cmdSave").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmUserDetails").serialize();                                        ;
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/users/SaveUser",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({ 
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                });  
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url().'index.php/'. $v_formOpen;?>");
                                  }, 1500);
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    }); 
                                          
                                         $("li").removeClass("active");                                                                                                                                    
                                                                           
                                   // ErrTab
                                swal(
                                      'Error.',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
      
      
});

</script>        
        
        
        
