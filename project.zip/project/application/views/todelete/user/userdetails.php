<div class="wrapper wrapper-content">
User Details. Not Implemented      
</div>