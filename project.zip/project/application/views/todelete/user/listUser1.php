<?php 
		$attr1= array('name' => 'frmUser', 'id' => 'frmUser');
		echo form_open(base_url().'index.php/Users/resetpassword' ,$attr1);
?>

            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5>Users List</h5>
                    	<div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
                    
                        <div class="form-group">
                            <label class="col-sm-2 control-label text-right">User Type</label>
                            <div class="col-sm-3">
                       			<?php
                        			$js ='id="cmbUserType" class="form-control m-b"';
                        			$DefaultValue = set_value('cmbUserType',0); 
                        			echo   form_dropdown('cmbUserType', $UserType,$DefaultValue,$js);
                      			?>	
                            </div> 
							<div class="col-sm-3">
								<input class="btn btn-primary btn-sm " type="submit"  id="cmdSubmit" value="Search" />                                
                             </div>							
                        </div>
						<div class="form-group">
							<div class="col-sm-12">								
                                
                            </div>
						</div>
                        <div class="form-group">
                        	<br><br><br>
                     			<div class="hr-line-dashed"></div>
                     	
                    
<?php
	
if($Date_Users!= "No" &&  $DefaultValue!= 0)
    {
?>
                    <table class="table table-striped table-bordered table-hover dataTable1" id="TblUser" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th width=10%>Login Id</th>
                        <th>Name of User</th>
                        <th width=15%>Email</th>
                        <th width=15%>Phone Number</th> 
                        <th width=5%></th>
                    </tr>
                    </thead>
                    <tbody>
<?php
    $loop = 0;
    	foreach ($Date_Users->result() as $r)
     	 { 
     	  $loop = $loop + 1;
?>
                    <tr class="gradeX">
                        <td><?php  echo $loop; ?></td>
                        <td><?php  echo $r->User_Code;?></td>
                        <td ><?php  echo $r->User_Name; ?></td>
                        <td><?php  echo $r->email; ?></td>
                        <td><?php  echo $r->mobile; ?></td>
                         
                        <td UserName = "<?php  echo $r->User_Name; ?>" UserID = "<?php  echo $r->user_id; ?>"  >
                            <a title="Reset Password" href="#"   id="cmdResetPwd" >  <i class="fa fa-key fa-2x" ></i> </a>                       
                         </td>
                    </tr>
<?php
        }
 
?>           
                    </tbody>
                    
                    </table>
<?php
        }
        else
        {
        	if( $DefaultValue> 0) 
            {
?>	
                <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins"> 
                               Add User Detail 
                            </h3>
                            <small>Please add User detail using "Add" button </small>    
                        </div>
                    </div>

  <?php          
            }
            else
            {
?>
                <div class="widget navy-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins">Mandatory fields</h3>
                            <small>Please select the User type </small>
                        </div>
                </div>
  <?php                 
            }
        }
 
?>
                  	</div>
                  </div>
                </div>
            </div>
            </div>            

<?php
	echo form_close();
    
  
		$attr1= array('name' => 'frmUserEdit', 'id' => 'frmUserEdit');
		echo form_open(base_url().'index.php/users/modifyUser',$attr1);        
        echo '<input  id="user_id" name="user_id" value="0" type="hidden"/>'; 
        echo '<input type="submit"  id="cmdSubmitAdd"  hidden="hidden" />';
        echo form_close();                                
?>	
     
<script>
 

$(document).ready(function()
{
     $('#cmbUserType').change(function (event){                          
         $('#cmdSubmit').click();
     });
    
 $('#TblUser tbody').on('click', 'td', function () {  
          var UserName =  $(this).attr('UserName'); 
          var UserID =  $(this).attr('UserID');  
        if(UserID > 0){    
           swal({
              title: 'Are you sure ?',
              text:   "Do you want to reset "+ UserName+"'s Password" ,
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, Reset it!'
            }).then(function(){
                    
                 swal({ 
					  title: 'Reset Password',
					  html: "<i class='fa fa-key'></i> Enter New Password",
					  allowOutsideClick: false,
					  input: 'text',
					  showSpinner: true,
					  showCancelButton: true,
					  confirmButtonColor: "#DD6B55",
					  confirmButtonText: "Reset"
					}).then(function (Pswd) { 
        					if (Pswd == "") {
           						 swal("Missing New Password","You need to enter New Password","warning");
           						 return false
         					}else{
        					
                            		swal({ 
                							type: '', // Title 
                							allowOutsideClick: false,
                							showSpinner: true,
                							closeOnEsc: false,
                							html: "Please wait .....<i class='fa fa-spin fa-1x fa-fw'><i class='fa fa-cog'></i></i> ",
                							showConfirmButton: false
                							});
                							
                                                    $.ajax ({
                                            			type: "POST",
                                            			url: "<?php echo base_url();?>index.php/Users/NewPassword",
                                            			data: {Password:Pswd,UserID:UserID},
                                            			dataType:'json' ,
                                                         success: function (data) {   
                                                            
                                                                swal({ 
                                                							title: "Successfully Updated" ,
                                                							type: 'success', // Title 
                                               							  //  html: "    <i class='fa fa-key'></i> !!!",
                                                							showConfirmButton: true,
                                                							timer: 3500,
                                                							imageUrl: '<?php echo base_url(); ?>assets/img/thumbs-up.jpg',
                                                							imageWidth: 100,
                                                							imageHeight: 100
                                            							}); 
                                                              
                                            			   }
                                        	        });  
                            	 }
                            });                          
                    }) 
            }
     });
});

</script>       