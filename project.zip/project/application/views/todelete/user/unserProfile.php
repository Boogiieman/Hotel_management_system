<?php
		$attr1= array('name' => 'frmUserDetails', 'id' => 'frmUserDetails', 'class'=> 'form-horizontal');
		echo form_open('#',$attr1);
        
    	if($v_data=="No")
    	{		
            $user_id  =  0;
            $enterprise_id  =  $this->session->userdata['mysession']['enterprise_id'];
            $office_id  =   0;
            $user_code  =   '';
            $user_name  =   '';
            $user_status  =   1;
            $user_type_id  =   0;
            $email  =   '';
            $mobile  =   '';
            $isFirstLogin  =   0;
            $folio_number='';
            $photo='';
            $v_formOpen='users';
    	}
    	else 
    	{
            $user_id  =  $v_data->user_id;
            $enterprise_id  =  $this->session->userdata['mysession']['enterprise_id'];
            $office_id  =   $v_data->office_id;
            $user_code  =   $v_data->User_Code;
            $user_name  =   $v_data->User_Name;
            $user_status  =   $v_data->UserStatus;
            $user_type_id  =   $v_data->TypeID;
            $email  =   $v_data->email;
            $mobile  =   $v_data->mobile;
            $isFirstLogin  =   $v_data->isFirstLogin;
            $folio_number =$v_data->folio_number;
            $photo =$v_data->profile_photo; 
    	}
        $user_type_id  = $this->session->userdata['mysession']['user_type_id'];
        $office_id  = $this->session->userdata['mysession']['office_id'];
         
?>		
 			
           
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
                <div class="col-lg-4">
                        <div class="widget-head-color-box navy-bg p-lg text-center">
                            <div class="m-b-md">
                            <h2 class="font-bold no-margins">
                                <?php echo $user_name; ?>
                            </h2>
                                
                            </div>
 <?php
	if(!empty($photo))
        $Img = 'photo/'.$photo. '?'.md5(time());
    else
        $Img = 'assets/img/profile_small.jpg';
    
?>
                            <img data-toggle="modal" data-target="#project-Cam"  src="<?php echo base_url().$Img; ?> " class="img-circle circle-border" width="200px" alt="profile">
                            <div>
                                 
                            </div>
                        </div>
                         
                </div> 
        
            <div class="col-lg-8 animated fadeInRight">
            <div class="mail-box-header"> 
                <h2>
                    <?php echo $user_name; ?>
                </h2> 
            </div>
                <div class="mail-box"> 
                <div class="mail-body">
                 <div class="col-lg-6">
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <i class="fa fa-warning"></i>  User Details
                            </div>
                            <div class="panel-body" style=" min-height: 110px;">                          
                                <span class="pull-left font-noraml"><?php echo 'User ID : '.$user_code; ?></span><br/>
                                 <span class="pull-left font-noraml"><?php echo 'Email ID : '.$email; ?></span><br/>
                                 <span class="pull-left font-noraml"><?php echo 'Mobile Number : '.$mobile; ?></span><br/>
                                 <span class="pull-left font-noraml"><?php echo 'Account Type : '.$UserType[$user_type_id]; ?></span><br/>
                                 <span class="pull-left font-noraml"><?php echo 'Office : '.$OfficeList[$office_id]; ?></span><br/>

                            </div>
                            <div class="panel-footer">
                                             
                            </div>
                        </div>
                   </div>
                   <div class="col-lg-6">
                        <div class="panel panel-danger ">
                            <div class="panel-heading" >
                                <i class="fa fa-warning"></i> Mapped Accounts
                            </div>
                            <div class="panel-body" style=" min-height: 110px;" >
                                            
                                            
                                                         
                            </div>
                            <div class="panel-footer">
                                             
                            </div>
                        </div>
                    </div> 
 
                    
                </div>
 
                        <div class="clearfix"></div>


                </div>
            </div>
        
        
        
    </div>
 </div>           
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Edit User details <small> </small></h5>
                            
                        </div>
                        <div class="ibox-content">
                            <form method="post" class="form-horizontal" name="frmUserDetails" id="frmUserDetails">
                                    <input type="hidden"  id="user_id" name="user_id" value="<?php echo $user_id; ?>"/> 
                                    <input type="hidden"  id="enterprise_id" name="enterprise_id" value="<?php echo $enterprise_id; ?>"/> 
                                    <input type="hidden"  id="office_id" name="office_id" value="<?php echo $office_id; ?>"/>  
                                    
                                     <div class="row">
                                        <div class="col-lg-12">
                                            <div class="panel blank-panel"> 
                                                <div class="panel-body">
                                                    <div class="tab-content">
                                                        <div id="tab-1" class="tab-pane active">
                                                        	    
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Name of User</label>
                                                                <div class="col-sm-3" id="div3"><input type="text" class="form-control" id="User_Name" name="User_Name" value="<?php echo $user_name; ?>"></div>                                                                                              
                                                                
                                                            </div>  
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">eMail id</label>
                                                                <div class="col-sm-3"  id="div5"><input type="text" class="form-control" id="email" name="email" value="<?php echo $email; ?>"></div>
                                                             </div>                                                                 
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Phone No/Mobile</label>
                                                                <div class="col-sm-3"  id="div7"><input type="text" class="form-control" id="mobile" name="mobile"  value="<?php echo $mobile; ?>"></div>                                                                
                                                            </div>                                                        
                                                            <div class="form-group">
                                                            	<label class="col-sm-5 control-label"><div id="msg"></div></label>                                                                
                                                            </div>                                                                                                                                                                   
                                                        </div>
                                                    </div>  
                                                </div>
                        
                                            </div>
                                        </div> 
                                    </div>     
                                     <div class="form-group">
                                     	<div class="hr-line-dashed"></div>
                                                  <div class="col-sm-4 col-sm-offset-2">
                                                    <a href="<?php echo base_url().'index.php/Users/UserPfofile'; ?>"> 
                                                        <button  id="cmdCancel" class="btn btn-primary" type="button">Cancel</button>
                                                    </a>
                                                    <button id="cmdSave" class="btn btn-primary" type="button">Save </button>
                     							</div>  
                                     	</div>                      
                            </form>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        
 
        
 <?php
	echo form_close();
?>  

<script>
  $(function () {
       
      
      $("#cmdSave").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmUserDetails").serialize();                                        ;
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/users/SaveUserProf",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({ 
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                });  
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url().'index.php/Users/UserPfofile'?>");
                                  }, 1500);
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    }); 
                                          
                                         $("li").removeClass("active");                                                                                                                                    
                                                                           
                                   // ErrTab
                                swal(
                                      'Error.',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
      
      
});

</script>        
        
        
        
