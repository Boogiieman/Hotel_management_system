<div class="wrapper wrapper-content">
User List. Not Implemented , This is for <b>DEMO</b>
</br></br></br>
<table>

<tr><th width=20%>User_Code	</th><th width=20%>	User_Name	</th><th width=20%>			Password</th>
<tr><td>admin			</td><td>	Administrator			</td><td>123</td></tr>
<tr><td>accounts		</td><td>Accounts				</td><td>123</td></tr>
<tr><td>zoneadmin		</td><td>Jeddah Zone Admin		</td><td>123</td></tr>
<tr><td>alrawdahadmin	</td><td>Al Rawdah Area Admin	</td><td>123</td></tr>
<tr><td>faisaliyaadmi	</td><td>Faisaliya Area Admin	</td><td>123</td></tr>
<tr><td>aziziaadmin		</td><td>Azizia Area Admin		</td><td>123</td></tr>
<tr><td>faisaliya2adm	</td><td>Faisaliya Area Admin	</td><td>123</td></tr>
<tr><td>rawdaadmin		</td><td>Rawda Unit Admin		</td><td>123</td></tr>
<tr><td>alsalamaadmin	</td><td>Al Salama Unit Admin	</td><td>123</td></tr>
<tr><td>faisaliyaunit	</td><td>Faisaliya Unit Admin	</td><td>123</td></tr>
<tr><td>murabbaadmin	</td><td>Murabba Unit Admin		</td><td>123</td></tr>
<tr><td>halaqavadmin	</td><td>Halaqa V Unit Admin		</td><td>123</td></tr>
<tr><td>alsalamavadmi	</td><td>Al Salama V Unit Admin	</td><td>123</td></tr>
<tr><td>bawadivadmin	</td><td>Bawadi V Unit Admin		</td><td>123</td></tr>
</table>
    
</div>