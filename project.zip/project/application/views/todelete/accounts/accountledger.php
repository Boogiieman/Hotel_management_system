
 			<div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5>Account Head Ledger </h5>
                    	<div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
                            <form method="post" class="form-horizontal" action="ledger">
                                     <div class="row">
                                        <div class="col-lg-12">                                               
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Account Head</label>
                                                                <div class="col-sm-8">
																<select class="form-control">
																	<option value="group">...</option>
																	<option value="1">Account Head 1</option>
																	<option value="2">Account Head 2</option>
																	<option value="3">Account Head 3</option>
																	<option value="4">Account Head 4</option>
																</select>
																</div>                                                                                                                                                            
                                                            </div>     
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">From Date</label>
																<div class="col-sm-2"><input type="text" class="form-control" id="InvestorID" name="InvestorID" value=""></div>																
                                                             	<label class="col-sm-2 control-label">To Date</label> 
                                                                <div class="col-sm-2"><input type="text" class="form-control" id="InvestorID" name="InvestorID" value=""></div>                                   
																<div class="col-sm-2 col-sm-offset-2">
                                                                    <button class="btn btn-primary" type="submit">Show</button>
                                     							</div>  
															</div> 
                                            </div>
                                        </div> 
                                        <div class="form-group">
                                     	<div class="hr-line-dashed"></div>

                    <table class="table table-striped table-bordered table-hover dataTable1" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th width=10%>Tran.Date</th>
						<th width=10%>Ref. No</th>
                        <th>Particulars</th>
                        <th width=15%>Dr.</th>
                        <th width=15%>Cr.</th>
                        <th width=10%>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
					<tr class="gradeX">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Opening Balance</td>
                        <td style="text-align:right" >0.00</td>
                        <td style="text-align:right" >0.00</td>
						<td style="text-align:right" >0.00</td>													
                    </tr> 
					<tr class="gradeX">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td style="text-align:right" >0.00</td>
                        <td style="text-align:right" >0.00</td>
						<td style="text-align:right" >0.00</td>													
                    </tr> 
                    <tr class="gradeX">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Clossing Balance</td>
                        <td style="text-align:right" >0.00</td>
                        <td style="text-align:right" >0.00</td>
						<td style="text-align:right" >0.00</td>													
                    </tr>        
                    </tbody> 				
                    </table>                
                                     	</div>             
                            </form>
                        </div>
                    </div>
                </div>
            </div>
