 			
           <input type="hidden"  id="office_id" name="office_id" value=""/> 
            <input type="hidden" id="office_type_id" name="office_type_id" value=""/> 
            <input type="hidden" id="parent_id" name="parent_id" value=""/> 
             <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Dividend Issue Voucher</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Transaction</a>
                        </li>
                        <li class="active">
                            <strong>Dividend</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Dividend Details<small> </small></h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>                              
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form method="post" class="form-horizontal">                            
                                     <div class="row">
                                        <div class="col-lg-12">
											<table class="table table-striped table-bordered table-hover dataTable1" >
											<thead>
											<tr>
												<th width=2%>#</th>
												<th>Account Name</th>
												<th width=15%>Balance</th>
												<th width=2%></th>
											</tr>
											</thead>
											<tbody>
											<tr class="gradeX">
												<td>1</td>												
												<td><select class="form-control">
														<option value="group">...</option>
														<option value="group">Investments</option>
													</select>
												</td>
												<td style="text-align:right">0.00</td>
												<td></td>
											</tr>
											</tbody>
											</table>  
											<div class="form-group">
												<label class="col-sm-1 control-label">Narration</label>
												<div class="col-sm-8" id="div3"><input type="text" class="form-control" id="office_location" name="office_location" value=""></div>                                                             	                                   
											</div> 
                                        </div> 
                                    </div> 
									<div class="row">
                                        <div class="col-lg-12">
											<table class="table table-striped table-bordered table-hover dataTable1" >
											<thead>
											<tr>
												<th width=2%>#</th>												
												<th>Account Name (Folio No and Name)</th>
												<th width=15%>Dividend Amount</th>
												<th width=2%></th>
											</tr>
											</thead>
											<tbody>
											<tr class="gradeX">
												<td>1</td>												
												<td></td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td><a href="#" onclick="editOffice(1);"><i class="fa fa-trash" aria-hidden="true"></i></a> </td>
											</tr>
											<tr class="gradeX">
												<td>2</td>												
												<td></td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td><a href="#" onclick="editOffice(1);"><i class="fa fa-trash" aria-hidden="true"></i></a> </td>
											</tr>
											<tr class="gradeX">
												<td>3</td>
												<td></td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td><a href="#" onclick="editOffice(1);"><i class="fa fa-trash" aria-hidden="true"></i></a> </td>
											</tr>
											<tr class="gradeX">
												<td>4</td>
												<td></td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td><a href="#" onclick="editOffice(1);"><i class="fa fa-trash" aria-hidden="true"></i></a> </td>
											</tr>
											<tr class="gradeX">
												<td>5</td>
												<td></td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td><a href="#" onclick="editOffice(1);"><i class="fa fa-trash" aria-hidden="true"></i></a> </td>
											</tr>
											<tr class="gradeX">
												<td></td>
												<td>Total</td>
												<td style="text-align:right">0.00</td>
												<td></td>
											</tr>
											</tbody>
											</table>
                                        </div> 
                                    </div> 									
                                     <div class="form-group">
                                     	<div class="hr-line-dashed"></div>
                                                  <div class="col-sm-4 col-sm-offset-2">                                                    
                                                    <button id="cmdSave" class="btn btn-primary" type="button">Save </button>
                     							</div>  
                                     	</div>                      
                            </form>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
 
        
 <?php
	echo form_close();
?>  

<script>
  $(function () {
    
      
      $("#cmdSave1").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmOfficeDetails").serialize();   
                    //alert(values);
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/office/SaveOffice",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({
                                  position: 'top-right',
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                });  
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url().'index.php/'. $v_formOpen;?>");
                                  }, 1500);
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    }); 
                                          
                                         $("li").removeClass("active");                                                                                                                                    
                                                                           
                                   // ErrTab
                                swal(
                                      'Error...',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
      
      
});

</script>        
        
        
 