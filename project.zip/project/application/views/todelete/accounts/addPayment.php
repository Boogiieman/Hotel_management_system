 			
           <input type="hidden"  id="office_id" name="office_id" value=""/> 
            <input type="hidden" id="office_type_id" name="office_type_id" value=""/> 
            <input type="hidden" id="parent_id" name="parent_id" value=""/> 
             <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Payment Voucher</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Transaction</a>
                        </li>
                        <li class="active">
                            <strong>Payment Voucher</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Payments Details<small> </small></h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>                              
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form method="post" class="form-horizontal">                            
                                     <div class="row">
                                        <div class="col-lg-12">
											<table class="table table-striped table-bordered table-hover dataTable1" border=0>
											<thead>
											<tr>
												<th width=2%> </th>
												<th width=20%> </th>
												<th width=20%> </th>
												<th width=25%> </th>
												<th width=20%></th>
											</tr>
											</thead>
											<tbody>
											<tr class="gradeX">
												<td>*</td>
												<td>Voucher Number</td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td></td>
												<td></td>
											</tr>
											<tr class="gradeX">
												<td>*</td>
												<td>Date of Payment</td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td></td>
												<td></td>
											</tr>
											<tr class="gradeX">
												<td>*</td>
												<td>Pay from</td>
												<td colspan=2>
													<select class="form-control">
														<option value="group">...</option>
														<option value="group">Cash</option>
														<option value="head">Bank 1</option>
													</select>
												</td>
												<td>A/c Balance: 0.00</td>
											</tr>
											<tr class="gradeX">
												<td>*</td>
												<td>Pay To</td>
												<td colspan=2>
													<select class="form-control">
														<option value="group">...</option>
														<option value="1">Account Head 1</option>
														<option value="2">Account Head 2</option>
														<option value="3">Account Head 3</option>
														<option value="4">Account Head 4</option>
													</select>
												</td>												
												<td>A/c Balance: 0.00</td>
											</tr>
											<tr class="gradeX">
												<td>*</td>
												<td>Amount</td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" style="text-align:right" value=""></td>
												<td></td>
												<td></td>
											</tr>
											<tr class="gradeX">
												<td>*</td>
												<td>Reference No</td>
												<td><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td></td>
												<td></td>
											</tr>
											<tr class="gradeX">
												<td>*</td>
												<td>Narration</td>
												<td colspan=2><input type="text" class="form-control" id="office_name" name="office_name" value=""></td>
												<td></td>
											</tr>
											</tbody>
											</table>  											
                                        </div> 
                                    </div> 
																	
                                    <div class="form-group">                                     	
                                                  <div class="col-sm-4 col-sm-offset-2">                                                    
                                                    <button id="cmdSave" class="btn btn-primary" type="button">Save </button>
                     							</div>  
												</br>
												<div class="hr-line-dashed"></div>
                                     	</div>                       
                            </form>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
 
        
 <?php
	echo form_close();
?>  

<script>
  $(function () {
    
      
      $("#cmdSave1").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmOfficeDetails").serialize();   
                    //alert(values);
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/office/SaveOffice",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({
                                  position: 'top-right',
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                });  
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url().'index.php/'. $v_formOpen;?>");
                                  }, 1500);
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    }); 
                                          
                                         $("li").removeClass("active");                                                                                                                                    
                                                                           
                                   // ErrTab
                                swal(
                                      'Error...',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
      
      
});

</script>        
        
        
 