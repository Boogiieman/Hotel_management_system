
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Account Heads</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index.html">Home</a>
            </li>
            <li>
                <a>Accounts</a>
            </li>
            <li class="active">
                <strong>Account Head</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Account Heads <small></small></h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                        <a class="close-link">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">

                    <div id="jstree1">
                        <ul>
                            <li class="jstree-open">Saif
                                <ul>
                                    <li class="jstree-open" ><span class="text-navy">Liabilities</span>
                                        <ul>
                                            <li data-jstree='{"type":"css"}'>Capital A/c</li>
                                            <li data-jstree='{"type":"css"}'>Current A/c</li>
                                            <li data-jstree='{"type":"css"}'><span class="text-navy">Investments</span></li>
                                        </ul>
                                    </li>
                                    <li class="jstree-open"><span class="text-navy">Assets</span>
                                        <ul>
                                            <li class="jstree-open"  data-jstree='{"type":"html"}'><span class="text-navy">Current Assets</span>
												<ul>
													<li class="jstree-open"  data-jstree='{"type":"html"}'><span class="text-navy">Cash and Bank</span>
														<ul>
															<li data-jstree='{"type":"html"}'>Cash on Hand</li>
															<li data-jstree='{"type":"html"}'>Cash at CTS</li>
															<li data-jstree='{"type":"html"}'>Cash at Bank</li>
														</ul>
													</li>													
												</ul>
											</li>
                                        </ul>
										<ul>
                                            <li class="jstree-open"  data-jstree='{"type":"html"}'>Fixed Assets
												<ul>
													<li data-jstree='{"type":"html"}'>land & Building - Cost</li>														
													<li data-jstree='{"type":"html"}'>Furnitures & Fixtures - Cost</li>
													<li data-jstree='{"type":"html"}'>Computer HW & SW - Cost</li>
													<li data-jstree='{"type":"html"}'>Vehicles - Cost</li>																								
												</ul>
											</li>
                                        </ul>
                                    </li>
                                    <li class="jstree-open"><span class="text-navy">Expenses</span>
                                        <ul>
                                            <li data-jstree='{"type":"svg"}'>Dividend</li>                                            
                                        </ul>
										<ul>
											<li class="jstree-open"  data-jstree='{"type":"svg"}'>Admin Expense
											<ul>
												<li data-jstree='{"type":"html"}'>Office Rent</li>
												<li data-jstree='{"type":"html"}'>Telephone & Communications</li>
												<li data-jstree='{"type":"html"}'>Electricity exp</li>
												<li data-jstree='{"type":"html"}'>Stationary exp</li>
												<li data-jstree='{"type":"html"}'>Postage & Courrier</li>
												<li data-jstree='{"type":"html"}'>Travel Exp</li>
												<li data-jstree='{"type":"html"}'>Entertainment exp</li>
												<li data-jstree='{"type":"html"}'>Legal & Professional exp</li>
												<li data-jstree='{"type":"html"}'>Accounting Exp</li>
												<li data-jstree='{"type":"html"}'>Audit Fees</li>
												<li data-jstree='{"type":"html"}'>GB & 'Meeting Exp</li>
												<li data-jstree='{"type":"html"}'>Exchange fluctuations</li>
												<li data-jstree='{"type":"html"}'>Profit / (loss) on sales of Assets</li>
												<li data-jstree='{"type":"html"}'>Depreciation expense</li>
												<li data-jstree='{"type":"html"}'>Taxes and Fees</li>
											</ul>
											</li> 
										</ul>
										<ul>
											<li  class="jstree-open" data-jstree='{"type":"svg"}'>Cost of revenue
											<ul>
												<li data-jstree='{"type":"html"}'>Thamrasseri Rentals</li>
												<li data-jstree='{"type":"html"}'>Periya Cultivations</li>
												<li data-jstree='{"type":"html"}'>Khayal project related cost</li>
											</ul>
											</li> 
										</ul>
                                    </li>
                                    <li class="jstree-open"><span class="text-navy">Income</span>
                                        <ul>
                                            <li data-jstree='{"type":"img"}'>Thamrasseri Rental income</li>
                                            <li data-jstree='{"type":"img"}'>Periya Cultivation Income</li>
                                            <li data-jstree='{"type":"img"}'>Khayal Dividents</li>
                                            <li data-jstree='{"type":"img"}'>Income from Sale of Investments</li>
                                        </ul>
                                    </li>                                    
                                </ul>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>   
		<div class="col-lg-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Account Head Details</h5>                    
                </div>
                <div class="ibox-content">
									<div class="row">
                                        <div class="col-lg-12">
										<div class="form-group">
											<div class="row">															
													<label class="col-sm-4 control-label">Parent Head</label>
													<div class="col-sm-6" id="div1">...</div>                                                                                              
											</div>	
											</br>
											<div class="row">
												<label class="col-sm-4 control-label">Type</label>
												<div class="col-sm-6" id="div3">
													<select class="form-control">
														<option value="group">...</option>
														<option value="group">Group</option>
														<option value="head">Head</option>
													</select>
												</div>                                                             	                                   
											</div>  
											</br>
											<div class="row">															
													<label class="col-sm-4 control-label">Code</label>
													<div class="col-sm-6" id="div1"><input type="text" class="form-control" id="office_code" name="office_code" value=""></div>                                                                                              
											</div>	
											</br>
											<div class="row">
												<label class="col-sm-4 control-label">Group/Head Name</label>
												<div class="col-sm-6" id="div2"><input type="text" class="form-control" id="office_name" name="office_name" value=""></div>                                                                                              
											</div> 
											</br>											
											
											<div class="row">
												<label class="col-sm-4 control-label">Opening Balance</label>
												<div class="col-sm-6"  id="div4"><input type="text" class="form-control" id="phone_number" name="phone_number" style="text-align:right" value=""></div>
											</div>
											</br>
											<div class="row">
												<label class="col-sm-4 control-label">Current Balance</label>
												<div class="col-sm-6"  id="div4" style="text-align:right">0.00</div>
											</div>											
										</div>	
										<div class="form-group">
											<div class="hr-line-dashed"></div>
                                              <div class="col-sm-12 col-sm-offset-2">
                                                <button id="cmdSaveInv" class="btn btn-primary" type="button">Save </button>
												<button id="cmdSaveInv" class="btn btn-warning" type="button">New Group </button>
												<button id="cmdSaveInv" class="btn btn-warning" type="button">New Head </button>
                 							</div>   
                                     	</div> 										
                                        </div> 
                                    </div>
                </div>
            </div>
        </div>		
    </div>


</div>




<style>
    .jstree-open > .jstree-anchor > .fa-folder:before {
        content: "\f07c";
    }

    .jstree-default .jstree-icon.none {
        width: 0;
    }
</style>

<script>
    $(document).ready(function(){

        $('#jstree1').jstree({
            'core' : {
                'check_callback' : true
            },
            'plugins' : [ 'types', 'dnd' ],
            'types' : {
                'default' : {
                    'icon' : 'fa fa-folder'
                },
                'html' : {
                    'icon' : 'fa fa-file-code-o'
                },
                'svg' : {
                    'icon' : 'fa fa-file-picture-o'
                },
                'css' : {
                    'icon' : 'fa fa-file-code-o'
                },
                'img' : {
                    'icon' : 'fa fa-file-image-o'
                },
                'js' : {
                    'icon' : 'fa fa-file-text-o'
                }

            }
        });

        $('#using_json').jstree({ 'core' : {
            'data' : [
                'Empty Folder',
                {
                    'text': 'Resources',
                    'state': {
                        'opened': true
                    },
                    'children': [
                        {
                            'text': 'css',
                            'children': [
                                {
                                    'text': 'animate.css', 'icon': 'none'
                                },
                                {
                                    'text': 'bootstrap.css', 'icon': 'none'
                                },
                                {
                                    'text': 'main.css', 'icon': 'none'
                                },
                                {
                                    'text': 'style.css', 'icon': 'none'
                                }
                            ],
                            'state': {
                                'opened': true
                            }
                        },
                        {
                            'text': 'js',
                            'children': [
                                {
                                    'text': 'bootstrap.js', 'icon': 'none'
                                },
                                {
                                    'text': 'inspinia.min.js', 'icon': 'none'
                                },
                                {
                                    'text': 'jquery.min.js', 'icon': 'none'
                                },
                                {
                                    'text': 'jsTree.min.js', 'icon': 'none'
                                },
                                {
                                    'text': 'custom.min.js', 'icon': 'none'
                                }
                            ],
                            'state': {
                                'opened': true
                            }
                        },
                        {
                            'text': 'html',
                            'children': [
                                {
                                    'text': 'layout.html', 'icon': 'none'
                                },
                                {
                                    'text': 'navigation.html', 'icon': 'none'
                                },
                                {
                                    'text': 'navbar.html', 'icon': 'none'
                                },
                                {
                                    'text': 'footer.html', 'icon': 'none'
                                },
                                {
                                    'text': 'sidebar.html', 'icon': 'none'
                                }
                            ],
                            'state': {
                                'opened': true
                            }
                        }
                    ]
                },
                'Fonts',
                'Images',
                'Scripts',
                'Templates',
            ]
        } });

    });
</script>


</body>

</html>
