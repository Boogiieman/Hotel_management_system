<?php
		$attr1= array('name' => 'frmOfficeDetails', 'id' => 'frmOfficeDetails', 'class'=> 'form-horizontal');
		echo form_open('#',$attr1);
        
	if($v_Parentdetails!="No")
	{
		$parentDetails		=	$v_Parentdetails->office_name;
	
//	var_dump($v_Parentdetails);
    	if($v_data=="No")
    	{		
            $office_id  =  0;
            $office_type_id  =  $office_type_id;
            $parent_id  =   $v_Parentdetails->office_id;
            $office_code  =   '';
            $office_name  =   '';
            $active  =   1;
            $office_location  =   '';
            $linked_user  =   '';
            $enterprise_id  =   '';
            $phone_number  =   '';
            $email_id  =   '';

    	}
    	else 
    	{
    	        $office_id  = $v_data->office_id ;
                $office_type_id  = $v_data->office_type_id ;
                $parent_id  = $v_data->parent_id ;
                $office_code  = $v_data->office_code ;
                $office_name  = $v_data->office_name ;
                $active  = $v_data->active ;
                $office_location  = $v_data->office_location ;
                $linked_user  = $v_data->linked_user ;
                $enterprise_id  = $v_data->enterprise_id ;
                $phone_number  = $v_data->phone_number ;
                $email_id  = $v_data->email_id ;

        
    	}
?>		
 			
           <input type="hidden"  id="office_id" name="office_id" value="<?php echo $office_id; ?>"/> 
            <input type="hidden" id="office_type_id" name="office_type_id" value="<?php echo $office_type_id; ?>"/> 
            <input type="hidden" id="parent_id" name="parent_id" value="<?php echo $parent_id; ?>"/> 
             <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Hospital Details</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Office</a>
                        </li>
                        <li class="active">
                            <strong>Hospital</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Hospital details <small> </small></h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>                              
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form method="get" class="form-horizontal">
                            
                                     <div class="row">
                                        <div class="col-lg-12">
                                            <div class="panel blank-panel"> 
                                                <div class="panel-body">
                                                    <div class="tab-content">
                                                        <div id="tab-1" class="tab-pane active">
                                                        	<div class="form-group">
                                                            	<label class="col-sm-2 control-label">Parent Department</label>
                                                                <div class="col-sm-3"><?php echo $parentDetails ?></div>                                                                                              
                                                            </div>         
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Hospital Code</label>
                                                                <div class="col-sm-3" id="div1"><input type="text" class="form-control" id="office_code" name="office_code" value="<?php echo $office_code ?>"></div>                                                                                              
                                                            </div>    
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Hospital Name</label>
                                                                <div class="col-sm-3" id="div2"><input type="text" class="form-control" id="office_name" name="office_name" value="<?php echo $office_name; ?>"></div>                                                                                              
                                                            </div>  
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Location</label>
                                                                <div class="col-sm-3" id="div3"><input type="text" class="form-control" id="office_location" name="office_location" value="<?php echo $office_location; ?>"></div>                                                             	                                   
                                                            </div>  
                                                               
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Phone No</label>
                                                                <div class="col-sm-3"  id="div4"><input type="text" class="form-control" id="phone_number" name="phone_number"  value="<?php echo $phone_number; ?>"></div>
                                                             	<label class="col-sm-2 control-label">Email Id</label>
                                                                <div class="col-sm-3" id="div5"><input type="text" class="form-control"  id="email_id" name="email_id"  value="<?php echo $email_id; ?>" ></div>                                   
                                                            </div>                                                                                                     
                                                        </div>
                                                    </div>  
                                                </div>
                        
                                            </div>
                                        </div> 
                                    </div>     
                                     <div class="form-group">
                                     	<div class="hr-line-dashed"></div>
                                                  <div class="col-sm-4 col-sm-offset-2">
                                                    <a href="<?php echo base_url().'index.php/'.$v_formOpen; ?>"> 
                                                        <button  id="cmdCancel" class="btn btn-primary" type="button">Cancel</button>
                                                    </a>
                                                    <button id="cmdSave" class="btn btn-primary" type="button">Save </button>
                     							</div>  
                                     	</div>                      
                            </form>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
 
        
 <?php
	echo form_close();
?>  

<script>
  $(function () {
    
      
      $("#cmdSave").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmOfficeDetails").serialize();   
                    //alert(values);
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/office/SaveOffice",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({
                                  position: 'top-right',
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                });  
                                
                                setTimeout(
                                  function() 
                                  {
                                    window.location.assign("<?php echo base_url().'index.php/'. $v_formOpen;?>");
                                  }, 1500);
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    }); 
                                          
                                         $("li").removeClass("active");                                                                                                                                    
                                                                           
                                   // ErrTab
                                swal(
                                      'Error...',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
      
      
});

</script>        
        
        
        
<?php
	}else{
	   echo 'Invalid Data';
       }
?>