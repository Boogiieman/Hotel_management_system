
<form method="post">
<textarea name="txtData" rows="5" cols="40"></textarea>
<input type="submit">
</form>