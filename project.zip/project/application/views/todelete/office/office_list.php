<?php 
		$attr1= array('name' => 'frmInvestor', 'id' => 'frmInvestor');
		echo form_open(base_url().'index.php/' . $v_formOpen ,$attr1);
?>

            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5><?php echo $v_officeType; ?></h5>
                    	<div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a> 
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content"> 
                    
                        <div class="form-group">
                            <label class="col-sm-2 control-label text-right">Department</label>
                            <div class="col-sm-4">
                       			<?php
                                
                        			$js ='id="cmbParent" class="form-control m-b"';
                        			$DefaultValue = set_value('cmbParent',0); 
                        			echo   form_dropdown('cmbParent', $ParentList,$DefaultValue,$js);
                      			?>	
                            </div>                  
                            <label class="col-sm-4 control-label text-right"></label>
                            <div class="col-sm-2">
                                <!--  <a href="<?php echo base_url(); ?>index.php/<?php echo $v_formAdd; ?>">-->
                                <?php if($ParentID>0){?>
                                     <button class="btn btn-danger btn-sm " type="button" onclick="addOffice()"><i class="fa fa-plus-square"></i>&nbsp;Add <?php echo $v_officeType; ?></button>
                                 <!--  </a>-->
                                 <?php }?>
                            </div>							                           
                        </div>
                      
                        <div class="form-group">
                        	<br>
                     			<div class="hr-line-dashed"></div>
                     	
                    
<?php
	
if($v_data!= "No" &&  $DefaultValue!= 0)
    {
?>
                    <table class="table table-striped table-bordered table-hover dataTable1" >
                    <thead>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th width=10%>Code</th>
                        <th>Hospital Name</th>
                        <th width=15%>Location</th>
                        <th width=15%>Assigned User</th>
                        <th width=10%></th>
                    </tr>
                    </thead>
                    <tbody>
<?php
    $loop = 0;
    	foreach ($v_data->result() as $r)
     	 { 
     	  $loop = $loop + 1;
?>
                    <tr class="gradeX">
                        <td><?php  echo $loop; ?></td>
                        <td><?php  echo $r->office_code;?></td>
                        <td><?php  echo $r->office_name; ?></td>
                        <td><?php  echo $r->office_location; ?></td>
                        <td><?php  echo 'Not Assigned'; ?></td>
                        <td><a href="#" onclick="editOffice(<?php  echo $r->office_id;?>);">Edit</a> </td>
                    </tr>
<?php
        }
 
?>           
                    </tbody>
                    <tfoot>
                    <tr>
                        <th width=5%>Sl No</th>
                        <th width=10%>Code</th>
                        <th>Hospital Name</th>
                        <th width=15%>Location</th>
                        <th width=15%>Assigned User</th>
                        <th width=10%></th>
                    </tr>
                    </tfoot>
                    </table>
<?php
        }
        else
        {
        	if( $DefaultValue> 0) 
            {
?>	
                <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins"> 
                               Add Hospital Details 
                            </h3>
                            <small>Please add Hospital detail using "Add" button </small>    
                        </div>
                    </div>

  <?php          
            }
            else
            {
?>
                <div class="widget navy-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins">
                             Selct the Parent Department
                            </h3>
                            <small>Please selct the Parent Department  from the List</small>
                        </div>
                </div>
  <?php                 
            }
        }
 
?>
                  	</div>
                  </div>
                </div>
            </div>
            </div>            
<input type="submit"  id="cmdSubmit" hidden="hidden" />
<?php
	echo form_close();
    
  
		$attr1= array('name' => 'frmInvestorEdit', 'id' => 'frmInvestorEdit');
		echo form_open(base_url().'index.php/office/addOfficeDetails',$attr1);
        
        echo '<input  id="office_id" name="office_id" value="0" type="hidden"/>';
        echo '<input id="office_type_id" name="office_type_id" value="'.$v_officeTypeID.'" type="hidden"/>  ';
        echo '<input id="parent_id" name="parent_id" value="'.$DefaultValue.'" type="hidden"  />';
        echo '<input id="v_formOpen" name="v_formOpen" value="'.$v_formOpen.'" type="hidden"  />';
        echo '<input type="submit"  id="cmdSubmitAdd" value="22" hidden="hidden" />';
        echo form_close();                                
?>	
     
<script>
function addOffice()
{
	$('#cmdSubmitAdd').click();
}

function editOffice(officeid)
{
	$('#office_id').val(officeid);
	$('#cmdSubmitAdd').click();
}

$(document).ready(function()
{
     $('#cmbParent').change(function (event){                          
         $('#cmdSubmit').click();
     });

});

</script>       