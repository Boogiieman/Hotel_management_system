
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins" style="margin:0px -10px 0px -10px ;">
                    <div class="ibox-title">
                        <h5>Zonal Offices</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                          <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">New Zonal Office/a></li>                             
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">

                    <table class="table table-striped table-bordered table-hover dataTable1" >
                    <thead>
                    <tr>
                        <th>Sl No</th>
                        <th>Office Code</th>
                        <th>Zonal Office</th>
                        <th>Details</th>
                        <th>Person in-charge</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
<?php
    $loop = 0;
	foreach ($v_data->result() as $r)
 	 { 
 	  $loop = $loop + 1;
?>
                    <tr class="gradeX">
                        <td><?php  echo $r->JOBNo; ?></td>
                        <td width=10%><?php  echo $r->JOBDate; ?></td>
                        <td><?php  echo $r->Client_Name; ?></td>
                        <td><?php  echo $r->Job_Title; ?></td>
                        <td><?php  echo $r->Deadline_Date; ?></td>
                        <td><?php  echo $r->Deadline_Date; ?></td>
                    </tr>
<?php
	}
?> 
                    
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Sl No</th>
                        <th>Office Code</th>
                        <th>Zonal Office</th>
                        <th>Details</th>
                        <th>Person in-charge</th>
                        <th>Action</th>
                    </tr>
                    </tfoot>
                    </table>

                    </div>
                </div>
            </div>
            </div>            

        
