<?php
		$attr1= array('name' => 'frmEnterpriseDetails', 'id' => 'frmEnterpriseDetails', 'class'=> 'form-horizontal');
		echo form_open('#',$attr1);
        
       if($v_data=='No'){ 
                $enterprise_id  =   0;
                $enterprise_name  =   '';
                $address  =   '';
                $country  =   '';
                $phone_number  =   '';
                $email_id  =   '';
                $website  =   '';
                $registration_no  =   '';
                $registration_details  =   '';
                $access_code  =   ''; 
        }
        else
        {
            $enterprise_id  = $v_data->enterprise_id ;
            $enterprise_name  = $v_data->enterprise_name ;
            $address  = $v_data->address ;
            $country  = $v_data->country ;
            $phone_number  = $v_data->phone_number ;
            $email_id  = $v_data->email_id ;
            $website  = $v_data->website ;
            $registration_no  = $v_data->registration_no ;
            $registration_details  = $v_data->registration_details ;
            $access_code  = $v_data->access_code ; 
        }
 


?>		
 		<input type="hidden" id="enterprise_id" name="enterprise_id" value="<?php echo $enterprise_id; ?>"/>
         	<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Enterprise Details</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Office</a>
                        </li>
                        <li class="active">
                            <strong>Enterprise</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">
            
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Enterprise details <small> </small></h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>                              
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                             
                                     <div class="row">
                                        <div class="col-lg-12">
                                            <div class="panel blank-panel"> 
                                                <div class="panel-body">
                                                    <div class="tab-content">
                                                        <div id="tab-1" class="tab-pane active">        
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Enterprise Name</label>
                                                                <div class="col-sm-3" id="div1" ><input type="text" class="form-control" id="enterprise_name" name="enterprise_name" value="<?php echo $enterprise_name; ?>"></div>                                                                                              
                                                            </div>     
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Address</label>
                                                                <div class="col-sm-3" id="div2" ><input type="text" class="form-control" id="address" name="address" value="<?php echo $address; ?>"></div>
                                                             	<label class="col-sm-2 control-label">Country</label>
                                                                <div class="col-sm-3" id="div3" ><input type="text" class="form-control" id="country" name="country"  value="<?php echo $country; ?>"></div>                                   
                                                            </div>  
                                                               
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Phone No</label>
                                                                <div class="col-sm-3" id="div4" ><input type="text" class="form-control" id="phone_number" name="phone_number"  value="<?php echo $phone_number; ?>"></div>
                                                             	<label class="col-sm-2 control-label">Email Id</label>
                                                                <div class="col-sm-3" id="div5" ><input type="text" class="form-control"  id="email_id" name="email_id"  value="<?php echo $email_id; ?>" ></div>                                   
                                                            </div> 
                                                               
                                                            <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Web site</label>
                                                                <div class="col-sm-3" id="div6" ><input type="text" class="form-control" id="website" name="website"  value="<?php echo $website; ?>"></div>                                                             	                               
                                                            </div>  
                                                             <div class="form-group">
                                                            	<label class="col-sm-2 control-label">Registration No</label>
                                                                <div class="col-sm-3"  id="div7" ><input type="text" class="form-control" id="registration_no" name="registration_no"  value="<?php echo $registration_no; ?>"></div>
                                                             	<label class="col-sm-2 control-label">Registration Details</label>
                                                                <div class="col-sm-3" id="div8" ><input type="text" class="form-control"  id="registration_details" name="registration_details"  value="<?php echo $registration_details; ?>" ></div>                                   
                                                            </div>                                                                                                            
                                                        </div>
                                                    </div>  
                                                </div>
                        
                                            </div>
                                        </div> 
                                    </div>     
                                     <div class="form-group">
                                     	<div class="hr-line-dashed"></div>
                                              <div class="col-sm-4 col-sm-offset-2">
                                                <a href="<?php echo base_url(); ?>index.php/office/enterprise"> 
                                                    <button  id="cmdCancelInv" class="btn btn-primary" type="button">Cancel</button>
                                                </a>
                                                <button id="cmdSaveInv" class="btn btn-primary" type="button">Save </button>
                 							</div>   
                                     	</div>                      
                             
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
 <?php
	echo form_close();
?>  

<script>
  $(function () {
    
      
      $("#cmdSaveInv").click(function(){
  	         event.preventDefault(); 
                    $("div").removeClass("has-error");
                    var values = $("#frmEnterpriseDetails").serialize();   
                    //alert(values);
                   $('#dumyMebrDiv').html('<div id="loader"></div>');
                   $("#divMemBody").find("*").prop("disabled", true);  
                 $.ajax ({
                	   type: "POST",
                	   url: "<?php echo base_url();?>index.php/office/Save",
                	   data:values,
                	   dataType:'json' ,
                	   success: function(data)
                	   {	 
                             $('#dumyMebrDiv').html('');
                            $("#divMemBody").find("*").prop("disabled", false);
                            
                            if(data.Success==1){
                                swal({
                                  position: 'top-right',
                                  type: 'success',
                                  title: 'Successfully Saved',
                                  showConfirmButton: false,
                                  timer: 1500
                                });  
                            }
                            else{
                                
                                var array = data.ErrCode.split(",");
                                   $.each(array,function(i){ 
                                        ErrDiv = '#div'+ array[i];
                                       $(ErrDiv).addClass('has-error');
                                    }); 
                                          
                                         $("li").removeClass("active");                                                                                                                                    
                                                                           
                                   // ErrTab
                                swal(
                                      'Error...',
                                      data.msg,
                                      'error'
                                    );
                                    
                            }
                   	   },
                	   error: function(jqXHR, textStatus, errorThrown) 
                		{  
                		$("#msg").html("ERROR:::::" + jqXHR.responseText);
                           alert(jqXHR.responseText);	
                		}
                  });
        }); 
      
      
});

</script>        
        
        
        