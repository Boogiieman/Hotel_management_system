 
   <div class="wrapper wrapper-content">
        <div class="row">
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <span class="label label-success pull-right">SAR</span>
                                <h5>Total Investment </h5>
                            </div> 
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins col-md-6" id="divAccMpg"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <h1 class="no-margins col-md-6 text-right" id="divTotalColl"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <small class="col-md-6">Account</small>
                                <small class="col-md-6 text-right">Total Amount</small>  
                            </div>                            
                            
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins" >
                            <div class="ibox-title">
                                <span class="label label-primary pull-right">SAR</span>
                                <h5>Dividend</h5>
                            </div>
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins" id="divDivi"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1>
                                 
                                <small>Total Amount</small> 
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins" >
                            <div class="ibox-title">
                                <span class="label label-info pull-right">SAR</span>
                                <h5>Withdrawal</h5>
                            </div>
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins  " id="divWtdr"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1>  
                                <small >Total Amount</small> 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <span class="label label-danger pull-right">SAR</span>
                                <h5>Pending for Approval </h5>
                            </div> 
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins col-md-6" id="divPndgAccApr"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <h1 class="no-margins col-md-6 text-right" id="divTotalPndgColl"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <small class="col-md-6">Account</small>
                                <small class="col-md-6 text-right">Total Amount</small>  
                            </div>  
                        </div>
            </div>
        </div>
        <div id="ErrorMsg"> </div>
        <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Transactions for Approval</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                    
                                <div class="row">
                                    <div class="col-lg-12" id="divAprTbl"> 
                                        <div class="widget blue-bg p-lg text-center">
                                            <div class="m-b-md">
                                                <i class="fa fa-bell-slash fa-4x"></i>
                                                <h1 class="m-xs"> </h1>
                                                <h3 class="font-bold no-margins "> 
                                                     No pending transaction available for approval
                                                </h3>
                                                <small> </small>    
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div id="world-map" style="height: 300px;"></div>
                                    </div>
                            </div>
                            </div>
                        </div>
                    </div>
               </div> 
     </div>
                 <script>
 
 $(document).ready(function() {
   
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/InvCollCounts", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divAccMpg').html(data.AccMpg); 
                        $('#divTotalColl').html(data.Coll); 
                        $('#divDivi').html(data.Divi);  
                        $('#divWtdr').html(data.Wtdr);   
                        $('#divPndgAccApr').html(data.ActAcc);   
                        $('#divTotalPndgColl').html(data.PngColl);  
				   } 
			}); 
   
             
            /// Pending Table 
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/InvCollAndPending", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divAprTbl').html(data);   
				   } 
			});             
            
             
 });
        
   
    </script>