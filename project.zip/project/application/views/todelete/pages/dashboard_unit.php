 
   <div class="wrapper wrapper-content">
        <div class="row">
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <span class="label label-success pull-right">SAR</span>
                                <h5>Unit Collecton</h5>
                            </div> 
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins col-md-6" id="divCollection"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <h1 class="no-margins col-md-6 text-right" id="divTran"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <small class="col-md-6">Amount</small>
                                <small class="col-md-6 text-right">Transaction</small>  
                            </div>                            
                            
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins" >
                            <div class="ibox-title">
                                <span class="label label-primary pull-right">Count</span>
                                <h5>Investors</h5>
                            </div>
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins" id="divInvestors"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1>
                                 
                                <small>Active and Inactive</small> 
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins" >
                            <div class="ibox-title">
                                <span class="label label-info pull-right">SAR</span>
                                <h5>Pending with Area</h5>
                            </div>
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins  " id="divPendingAreaAmount"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1>  
                                <small >Amount</small> 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <span class="label label-danger pull-right">Count</span>
                                <h5>Pending with Area</h5>
                            </div>
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins" id="divPendingAreaTran"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1>
                                 
                                <small>Transactions</small>
                            </div>
                        </div>
            </div>
        </div>
        <div id="ErrorMsg"> </div>
        <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Transactions for Approval</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                    
                                <div class="row">
                                    <div class="col-lg-12" id="divAprTbl"> 
                                        <div class="widget blue-bg p-lg text-center">
                                            <div class="m-b-md">
                                                <i class="fa fa-bell-slash fa-4x"></i>
                                                <h1 class="m-xs"> </h1>
                                                <h3 class="font-bold no-margins "> 
                                                     No pending transaction available for approval
                                                </h3>
                                                <small> </small>    
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div id="world-map" style="height: 300px;"></div>
                                    </div>
                            </div>
                            </div>
                        </div>
                    </div>
               </div> 
     </div>
                 <script>
 
 $(document).ready(function() {
   
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/PendingCollection", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divCollection').html(data.CollAmount); 
                        $('#divTran').html(data.TrnCount);  
				   } 
			}); 
   
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/PendingCollectionArea", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						 
                        $('#divPendingAreaAmount').html(data.CollAmount); 
                        $('#divPendingAreaTran').html(data.TrnCount);  
				   } 
			}); 
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/CountInvestors", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divInvestors').html(data.InvCount);   
				   } 
			});             
            
            /// Pending Table 
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/PendingApproval", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divAprTbl').html(data);   
				   } 
			});             
            
             
 });
        
   
    </script>