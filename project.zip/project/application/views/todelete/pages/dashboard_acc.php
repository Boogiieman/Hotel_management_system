 
   <div class="wrapper wrapper-content">
        <div class="row">
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <span class="label label-success pull-right">SAR</span>
                                <h5>Pending Collection</h5>
                            </div> 
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins col-md-6" id="divAllPndgAmount"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <h1 class="no-margins col-md-6 text-right" id="divAllPndgCount"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <small class="col-md-6">Amount</small>
                                <small class="col-md-6 text-right">Units/Volunteer</small>  
                            </div>                            
                            
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins" >
                            <div class="ibox-title">
                                <span class="label label-info pull-right">Count</span>
                                <h5>Area and Unit</h5>
                            </div> 
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins col-md-6" id="divArea"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <h1 class="no-margins col-md-6 text-right" id="divUnit"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <small class="col-md-6">Area</small>
                                <small class="col-md-6 text-right">Unit</small>  
                            </div>  
                        </div>
                    </div>
                    
                    
                    <div class="col-lg-2">
                        <div class="ibox float-e-margins" >
                            <div class="ibox-title">
                                <span class="label label-primary pull-right">SAR</span>
                                <h5>Collection</h5>
                            </div>
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins" id="divTotColl"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1>
                                 
                                <small>This Month</small> 
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <span class="label label-danger pull-right">SAR</span>
                                <h5>Demand Collection</h5>
                            </div>
                            <div class="ibox-content" style="min-height: 87px;">
                                <h1 class="no-margins col-md-6" id="divDemndColl"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <h1 class="no-margins col-md-6 text-right" id="divInvestor"> 
                                     <i class="fa  fa-refresh fa-spin"></i> 
                                </h1> 
                                <small class="col-md-6">Amount</small>
                                <small class="col-md-6 text-right">Investors</small>  
                            </div> 
                        </div>
            </div>
        </div>
        <div id="ErrorMsg"> </div>
        <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Demand Collection List Area</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                    
                                <div class="row">
                                    <div class="col-lg-12" id="divZoneTbl">
                                        <div class="widget blue-bg p-lg text-center">
                                            <div class="m-b-md">
                                                <i class="fa fa-bell-slash fa-4x"></i>
                                                <h1 class="m-xs"> </h1>
                                                <h3 class="font-bold no-margins "> 
                                                     No pending transaction available for approval
                                                </h3>
                                                <small> </small>    
                                            </div>
                                        </div> 
                                    </div>
                                    <div class="col-lg-6">
                                        <div id="world-map" style="height: 300px;"></div>
                                    </div>
                            </div>
                            </div>
                        </div>
                    </div>
               </div>


                 
    </div>
 <script>
 
 $(document).ready(function() {
   
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/PendingAllCollections", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divAllPndgAmount').html(data.CollAmount); 
                        $('#divAllPndgCount').html(data.TrnCount);  
				   } 
			}); 
   
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/TotalMonthCollection", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						 
                        $('#divTotColl').html(data.TotColl);  
				   } 
			}); 
            
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/OfficeCount", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						 
                        $('#divArea').html(data.Area); 
                        $('#divUnit').html(data.Unit);  
				   } 
			});   
             
            
             $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/CountInv", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divInvestor').html(data.InvCount);  
                        $('#divDemndColl').html(data.DemndColl);  
				   } 
			});             
            
             
            /// Pending Collection Table 
           /*  $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/PendingZone", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divZoneTbl').html(data);   
				   } 
			});  
            */  
            
            // Demand Collections         
              $.ajax 
			({
				   type: "POST",
				   url: "<?php echo base_url();?>index.php/Dash/DemandColl", 
				   dataType:'json' ,
				   success: function(data)
				   {	 
						$('#divZoneTbl').html(data);   
				   } 
			});      
             
 });
        
   
    </script>