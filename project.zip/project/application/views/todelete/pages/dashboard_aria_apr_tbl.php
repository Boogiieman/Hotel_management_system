 
<?php
	if($v_data != 'No' || $v_data1 != 'No')
    {

        if($v_data != 'No'){
?>


<table class="table table-hover margin bottom">
        <thead>
        <tr>
            <th colspan="8">
                <span class="text-danger "><b>Direct Collection</b></span>
            </th>
        </tr>
        <tr>
            <th style="width: 5%" class="text-center">No.</th>
            <th style="width: 40%">Name</th>
            <th style="width: 20%" class="text-center">Folio No.</th>
            <th style="width: 15%"class="text-center">Date</th>
            <th style="width: 20%" class="text-center">Amount</th> 
        </tr>
        </thead>
        <tbody>
      <?php
	       $loop = 0;
    	foreach ($v_data->result() as $r)
     	{ 
     	  $loop = $loop + 1;
           
          $Class = 'class="label label-danger"';
          
?>  
        <tr>
            <td class="text-center"><?php echo $loop ; ?></td>
            <td><?php echo $r->name; ?> </td>
            <td class="text-center "><?php echo $r->folio_no; ?> </td>
            <td class="text-center "><?php echo $r->CollDate; ?> </td>
            <td class="text-right " ><span <?php echo $Class; ?>><?php echo 'SA '.number_format($r->tran_amount_collection,2); ?></span></td> 
            
            

        </tr>
        <?php
	      }
?>
        </tbody>
    </table>

<?php
	   }
       if($v_data1 != 'No'){
?>
        <table class="table table-hover margin bottom">
                <thead>
                    <tr>
                        <th colspan="8">
                            <span class="text-danger "><b>Unit Collection</b></span>
                        </th>
                    </tr>
                <tr>
                    <th style="width: 5%" class="text-center">No.</th> 
                    <th style="width: 40%">Unit Name</th> 
                    <th style="width: 20%" class="text-center">Log No.</th>
                    <th style="width: 15%" class="text-center">Date</th>
                    <th style="width: 20%" class="text-center">Amount</th>
                </tr>
                </thead>
                <tbody>
              <?php
        	       $loop = 0;
            	foreach ($v_data1->result() as $r)
             	{ 
             	  $loop = $loop + 1;
                  $Class = 'class="label label-primary"'; 
                  
        ?>  
                <tr>
                    <td class="text-center"><?php echo $loop ; ?></td> 
                    <td><?php echo $r->office_name; ?> </td> 
                    <td class="text-center "><?php echo $r->log_no; ?> </td>
                    <td class="text-center "><?php echo $r->TrnDate; ?> </td>
                    <td class="text-right" ><span <?php echo $Class; ?>><?php echo 'SA '.$r->CollAmount; ?></span></td>
                    
                    
                    
        
                </tr>
                <?php
        	      }
        ?>
                </tbody>
            </table>    
    
    
    <?php
	       }
    }
    else{
?>


                    <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell-slash fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins "> 
                                 No pending transaction available for approval
                            </h3>
                            <small> </small>    
                        </div>
                    </div>


<?php
	}
?>