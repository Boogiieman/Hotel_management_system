 
<?php
	if($v_data != 'No' || $v_data1 != 'No')
    {

        if($v_data != 'No'){
?>


<table class="table table-hover margin bottom">
        <thead>
        <tr>
            <th colspan="8">
                <span class="text-danger "><b>Account Details</b></span>
            </th>
        </tr>
        <tr>
            <th style="width: 5%" class="text-center">No.</th>
            <th style="width: 30%">Name</th>
            <th style="width: 15%" class="text-center">Folio No.</th>
            <th style="width: 10%" class="text-right">Investment </th>
            <th style="width: 10%" class="text-right">Dividend </th> 
            <th style="width: 10%" class="text-right">Withdrawal  </th>  
            <th style="width: 10%" class="text-right">Balance  </th> 
        </tr>
        </thead>
        <tbody>
      <?php
	       $loop = 0;
           
    	foreach ($v_data->result() as $r)
     	{ 
     	  $loop = $loop + 1; $Balance = 0;
           
          $Class = 'class="label label-danger"';
          
          $Balance = $r->collection + $r->dividend - $r->withdrawal ;
          
?>  
        <tr>
            <td class="text-center"><?php echo $loop ; ?></td>
            <td><?php echo $r->name; ?> </td>
            <td class="text-center "><?php echo $r->folio_no; ?> </td>
            <td class="text-right "><?php echo number_format($r->collection,2); ?> </td> 
            <td class="text-right "><?php echo number_format($r->dividend,2); ?> </td> 
            <td class="text-right "><?php echo number_format($r->withdrawal,2); ?> </td>  
            <td class="text-right "><?php echo number_format($Balance,2); ?> </td>  
            

        </tr>
        <?php
	      }
?>
        </tbody>
    </table>

<?php
	   }
       if($v_data1 != 'No'){
?>
        <table class="table table-hover margin bottom">
                <thead>
                    <tr>
                        <th colspan="8">
                            <span class="text-danger "><b>Pending Approval</b></span>
                        </th>
                    </tr>
                <tr>
                    <th style="width: 5%" class="text-center">No.</th> 
                    <th style="width: 30%">Name</th>
                    <th style="width: 15%" class="text-center">Folio No.</th>
                    <th style="width: 10%" class="text-right">Investment </th> 
                    <th style="width: 10%" class="text-right">Withdrawal  </th>  
                    <th style="width: 10%" class="text-center">Pending With  </th>  
                    <th style="width: 10%" class="text-center">Date  </th>  
                </tr>
                </thead>
                <tbody>
              <?php
        	       $loop = 0;
            	foreach ($v_data1->result() as $r)
             	{ 
             	  $loop = $loop + 1;
                  $Class = 'class="label label-primary"'; 
                  
        ?>  
                <tr>
                    <td class="text-center"><?php echo $loop ; ?></td> 
                    <td><?php echo $r->name; ?> </td>
                    <td class="text-center "><?php echo $r->folio_no; ?> </td>
                    <td class="text-right "><?php echo $r->collection; ?> </td>  
                    <td class="text-right "><?php echo $r->withdrawal; ?> </td> 
                    <td class="text-center "><?php echo $r->User_Name; ?> </td> 
                    <td class="text-center "><?php echo $r->PndgDate; ?> </td> 
        
                </tr>
                <?php
        	      }
        ?>
                </tbody>
            </table>    
    
    
    <?php
	       }
    }
    else{
?>


                    <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell-slash fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins "> 
                                 No pending transaction available for approval
                            </h3>
                            <small> </small>    
                        </div>
                    </div>


<?php
	}
?>