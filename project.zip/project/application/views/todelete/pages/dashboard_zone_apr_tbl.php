 
<?php
	if($v_data != 'No')
    {
?>


<table class="table table-hover margin bottom">
        <thead>
        <tr>
            <th style="width: 5%" class="text-center">No.</th>
            <th>Office Name</th>
            <th >Volunteer Name</th> 
            <th class="text-center">Amount</th> 
        </tr>
        </thead>
        <tbody>
      <?php
	       $loop = 0;
    	foreach ($v_data->result() as $r)
     	{ 
     	  $loop = $loop + 1;
          $Class = 'class="label label-primary"';
          
          if($r->office_type_id==5)
          $Class = 'class="label label-danger"';
          
?>  
        <tr>
            <td class="text-center"><?php echo $loop ; ?></td>
            <td><?php echo $r->office_name; ?> </td>
            <td  ><?php echo $r->User_Name; ?> </td> 
            <td  class="text-right"><span <?php echo $Class; ?>><?php echo 'SA '.$r->PndgAMount; ?></span></td> 
            
            

        </tr>
        <?php
	      }
?>
        </tbody>
    </table>
    
    
    
    <?php
	}
    else{
?>


                    <div class="widget blue-bg p-lg text-center">
                        <div class="m-b-md">
                            <i class="fa fa-bell-slash fa-4x"></i>
                            <h1 class="m-xs"> </h1>
                            <h3 class="font-bold no-margins "> 
                                 No pending transaction available for approval
                            </h3>
                            <small> </small>    
                        </div>
                    </div>


<?php
	}
?>