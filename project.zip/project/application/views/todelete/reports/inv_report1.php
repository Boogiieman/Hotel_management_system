 <?php
 
        $mdate 		= now();
        $Date 		= date("d/m/Y",$mdate);  
            
?>
<style type="text/css">
<!--
.style6 {
	color: #000000;
	font-weight: bold;
}
  
.style7 {font-size: 24px}
-->
</style>  	 
				  
     			<?php
                         $Loop =0; $Amount = 0; $Page = 0;
                    
                     if($v_Data!='No'){                     
                        foreach ($v_Data->result() as $r)
    			 		{  
                              $Loop = $Loop + 1;  $Page =  $Page + 1;
                                $InvPhoto = '';// 'assets/img/profile_small.jpg'; $Rand = md5(time());
                                if(!empty($r->photo))
                                $InvPhoto = 'photo/'.$photo;
    
    if($Page==1)  {                      
?>
         <div align="center" style="font-weight: bold; font-size: large; color: black;"  > <u>
	Investors List of <?php  echo $UnitDetails->office_name; ?> Unit </u></div> 
<?php
	}
?>              
                    <div align="center"><b><?php echo $Loop;  ?></b></div>
                    <table width="100%" border="0" cellspacing="0" cellpadding="1" style="font-size: small;">
                          <tr>
                            <td width="10%">Name</td>
                            <td width="4%">:</td>
                            <td colspan="6" align="left"><div align="left">
                              <?php  echo $r->name; ?>
                            </div></td>
                          </tr>
                          
                          <tr>
                            <td align="left">Folio No</td>
                            <td align="left">:</td>
                            <td width="28%" align="left"><div align="left">
                                <?php  echo $r->folio_no; ?>
                            </div></td>
                            <td width="0%">&nbsp;</td>
                            <td width="11%">&nbsp;</td>
                            <td width="0%">&nbsp;</td>
                            <td width="26%">&nbsp;</td>
                            <td width="21%">&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Date of Birth</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->dob; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>Sex</td>
                            <td>:</td>
                            <td colspan="2"><div align="left">
                              <?php  echo $Sex[$r->sex]; ?>
                            </div>                              <div align="left"></div></td>
                          </tr>
                          <tr>
                            <td>Job Title</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->job_title; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>Email</td>
                            <td>:</td>
                            <td colspan="2"><div align="left">
                              <?php  echo $r->email; ?>
                            </div>                              <div align="left"></div></td>
                          </tr>
                          <tr>
                            <td>Passport No</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->passport; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td><label>PAN Card</label></td>
                            <td>:</td>
                            <td colspan="2"><div align="left">
                              <?php  echo $r->pancard; ?>
                            </div>                              <div align="left"></div></td>
                          </tr>
                          <tr>
                            <td><label>Aadhar No</label></td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->aadhar; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>Iqama No</td>
                            <td>:</td>
                            <td colspan="2"><div align="left">
                              <?php  echo $r->iqama; ?>
                            </div>                              <div align="left"></div></td>
                          </tr>
                          <tr>
                            <td>Join Date</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->join_date; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>Subscription Amount</td>
                            <td>:</td>
                            <td colspan="2"><div align="left">
                              <?php  echo $r->premium_amount; ?>
                            </div>                              <div align="left"></div></td>
                          </tr>
                          <tr>
                            <td colspan="8"> </td>
                          </tr>
                          <tr>
                            <td><label>Address in KSA</label></td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->address_ksa; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>Address in India</td>
                            <td>:</td>
                            <td colspan="2"><div align="left">
                              <?php  echo $r->address_india; ?>
                            </div>                              <div align="left"></div></td>
                          </tr>
                          <tr>
                            <td>Mobile</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->mobile_ksa; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>Mobile</td>
                            <td>:</td>
                            <td colspan="2"><div align="left">
                              <?php  echo $r->mobile_india; ?>
                            </div>                              <div align="left"></div></td>
                          </tr>
                          <tr>
                            <td colspan="8"> </td>
                          </tr>
                          <tr>
                            <td colspan="3"><div align="center"><b><u> Nominee</u></b></div></td>
                            <td>&nbsp;</td>
                            <td>Current Location</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->current_location; ?>
                            </div></td>
                            <td rowspan="5">
                            <?php if(!empty($InvPhoto)){ ?>
							<img  src="<?php echo base_url().$InvPhoto;?>" width="75px" height="100px" class="img-circle circle-border   text-right" alt="Profile Photo"></td>
                            <?php } ?>
                          </tr>
                          <tr>
                            <td>Name</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->nominee_name; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td> Residence Status</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $Residence[$r->residence_status]; ?>
                            </div></td>
                          </tr>
                          <tr>
                            <td>Relation&nbsp;</td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $r->nominee_relation; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Address</td>
                            <td>:</td>
                            <td>  <div align="left">
                              <?php  echo $r->nominee_address; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>Account Status </td>
                            <td>:</td>
                            <td><div align="left">
                              <?php  echo $Status[$r->active]; ?>
                            </div></td>
                          </tr>
                          <tr>
                            <td>Mobile</td>
                            <td>;</td>
                            <td><div align="left">
                              <?php  echo $r->nominee_mobile; ?>
                            </div></td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                          </tr>
                     </table>   
    
    <?php
	if($Page==2){
	   echo '<br pagebreak="true" />';
       $Page = 0;
	}
    else
    {echo '<hr style="height:1px;border-top:3px solid #f00" />  ';}
?>
    
    
      <?php
                 	   } 
    
	               }
?>                     
                      
      
         
                        <!-- /.table -->
 



