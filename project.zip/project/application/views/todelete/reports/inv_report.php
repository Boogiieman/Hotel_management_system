 <?php
 
        $mdate 		= now();
        $Date 		= date("d/m/Y",$mdate);  
            
?>
<style type="text/css">
<!--
.style6 {
	color: #000000;
	font-weight: bold;
}
   .dotted {
        border: 1px dotted #ff0000; 
        border-style: none none dotted; 
        color: #fff; 
        background-color: #fff; 
   }
hr.style12 {
	height: 6px;
	background: url(http://ibrahimjabbari.com/english/images/hr-12.png) repeat-x 0 0;
    border: 0;
}
.style7 {font-size: 24px}
-->
</style>
 
  <div style="margin-left: 10px;">            

              
				 
				  
     			<?php
                         $Loop =0; $Amount = 0; $Page = 0;
                    
                     if($v_Data!='No'){                     
                        foreach ($v_Data->result() as $r)
    			 		{  
                              $Loop = $Loop + 1;  $Page =  $Page + 1;
    if($Page==1)  {                      
?>
        <table width="100%" border="0" cellspacing="0" cellpadding="1"  style=" font-size:12px; font-weight: bold; color:#FF0000"   >
  <tr>
    <td width="100%" colspan="2"><div align="center" style="font-weight: bold; font-size: large; color: black;"  > <u>
	Investors List of <?php  echo $UnitDetails->office_name; ?> Unit </u></div></td>
    </tr>
</table>
<?php
	}
?>              
                    <div align="center"><b><?php echo $Loop;  ?></b></div>
                    <table width="100%" border="0" cellspacing="0" cellpadding="1" style="font-size: small;">
                          <tr>
                            <td>Name</td>
                            <td>:</td>
                            <td colspan="4"><div align="left"><?php  echo $r->name; ?></div>
                            </td>
                          </tr>
                          <tr>
                            <td width="14%">Folio No</td>
                            <td width="1%">:</td>
                            <td width="33%"><?php  echo $r->folio_no; ?></td>
                            <td width="1%">&nbsp;</td>
                            <td width="15%">&nbsp;</td>
                            <td width="36%">&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Date of Birth</td>
                            <td>:</td>
                            <td><?php  echo $r->dob; ?></td>
                            <td>&nbsp;</td>
                            <td>Sex</td>
                            <td> : 
                            <?php  echo $Sex[$r->sex];  ?></td>
                          </tr>
                          <tr>
                            <td>Job Title</td>
                            <td>:</td>
                            <td><?php  echo $r->job_title; ?></td>
                            <td>&nbsp;</td>
                            <td>Email</td>
                            <td>:
                            <?php  echo $r->email; ?></td>
                          </tr>
                          <tr>
                            <td>Passport No</td>
                            <td>:</td>
                            <td><?php  echo $r->passport; ?></td>
                            <td>&nbsp;</td>
                            <td><label>PAN Card</label></td>
                            <td>:
                            <?php  echo $r->pancard; ?></td>
                          </tr>
                          <tr>
                            <td><label>Aadhar No</label></td>
                            <td>:</td>
                            <td><?php  echo $r->aadhar; ?></td>
                            <td>&nbsp;</td>
                            <td>Iqama No</td>
                            <td>:
                            <?php  echo $r->iqama; ?></td>
                          </tr>
                          <tr>
                            <td>Join Date</td>
                            <td>:</td>
                            <td><?php  echo $r->join_date; ?></td>
                            <td>&nbsp;</td>
                            <td>Subscription Amount</td>
                            <td>:
                            <?php  echo $r->premium_amount; ?></td>
                          </tr>
                          <tr>
                            <td colspan="6"> </td>
                          </tr>
                          <tr>
                            <td><label>Address in KSA</label></td>
                            <td>:</td>
                            <td><?php  echo $r->address_ksa; ?></td>
                            <td>&nbsp;</td>
                            <td>Address in India</td>
                            <td>:<?php  echo $r->address_india; ?></td>
                          </tr>
                          <tr>
                            <td>Mobile</td>
                            <td>:</td>
                            <td><?php  echo $r->mobile_ksa; ?></td>
                            <td>&nbsp;</td>
                            <td>Mobile</td>
                            <td>:
                              <?php  echo $r->mobile_india; ?></td>
                          </tr>
                          <tr>
                            <td colspan="6"> </td>
                          </tr>
                          <tr>
                            <td colspan="3"><div align="center"><b><u> Nominee</u></b></div></td>
                            <td>&nbsp;</td>
                            <td>Current Location</td>
                            <td>:
                            <?php  echo $r->current_location; ?></td>
                          </tr>
                          <tr>
                            <td>Name</td>
                            <td>:</td>
                            <td><?php  echo $r->nominee_name; ?></td>
                            <td>&nbsp;</td>
                            <td>Current Residence Status</td>
                            <td>:
                            <?php   echo $Residence[$r->residence_status]; ?></td>
                          </tr>
                          <tr>
                            <td>Relation&nbsp;</td>
                            <td>:</td>
                            <td><?php  echo $r->nominee_relation; ?></td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Address</td>
                            <td>:</td>
                            <td>  <?php  echo $r->nominee_address; ?></td>
                            <td>&nbsp;</td>
                            <td>Account Status </td>
                            <td>: <?php  echo $Status[$r->active];  ?></td>
                          </tr>
                          <tr>
                            <td>Mobile</td>
                            <td>:</td>
                            <td><?php  echo $r->nominee_mobile; ?></td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                          </tr>
                     </table>   
    
    <?php
	if($Page==2){
	   echo '<br pagebreak="true" />';
       $Page = 0;
	}
    else
    {echo '<hr style="height:1px;border-top:3px solid #f00" />  ';}
?>
    
    
      <?php
                 	   } 
    
	               }
?>                     
                             
  </div>                         
      
         
                        <!-- /.table -->
 



