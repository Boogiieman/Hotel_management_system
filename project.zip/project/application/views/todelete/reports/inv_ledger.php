 <?php
 
        $mdate 		= now();
        $Date 		= date("d/m/Y",$mdate);  
            
?>
<style type="text/css">
<!--
.style6 {
	color: #000000;
	font-weight: bold;
}
.style7 {font-size: 24px}
-->
</style>
 
                 
  <table width="100%" border="0" cellspacing="0" cellpadding="1"  style=" font-size:12px; font-weight: bold; "   >
  <tr>
    <td colspan="2"><div align="center" style="font-weight: bold; font-size: large; color: black;"  > Transaction Report </div></td>
    </tr>
  <tr>
    <td width="69%"><div align="left"><span style="text-align: left;  ">Investor Name :
      <?php  echo $v_details->name; ?>
    </span></div></td>
    <td width="31%"><div align="left"><span style="text-align: right; ">Report Date :
      <?php  echo $Date; ?>
    </span></div></td>
    </tr>
  
  <tr>
    <td><div align="left"><span style="text-align: left; ">Folio No :
      <?php  echo $v_details->folio_no; ?>
    </span></div></td>
    <td><span style="text-align: right; "> 
        
    </span></td>
    </tr>
</table>
              
				
				 <table align="center" width="100%" border="1" cellspacing="0" cellpadding="1" > 
                    <tr bgcolor="#CCCCCC" style=" font-size:11px; font-weight: bold; min-height:200px">
                        <th width="5%"  height="25px" align="center" >#</th>
                        <th width="10%" align="center" >Tran.Date</th>
                        <th width="45%" align="center">Remarks</th>
                        <th width="10%"  align="center">Collection</th>
                        <th width="10%"  align="center">Withdrawal</th>
						<th width="10%"  align="center">Balance</th>
						<th width="8%"  align="center">Status</th>
                    </tr>
                    
     			<?php
                	$total_collection=0;
                	$total_Dividend=0;
                	$total_Withdrawal=0;
                if($v_ledgerdetails!="No")
                {
                    $loop = 0;
					$rowtotal=0;					
                    foreach ($v_ledgerdetails->result() as $r)
                     	 { 
                     	  $loop = $loop + 1;
						  $rowtotal=$rowtotal+$r->sumamt;
?>
                    <tr class="gradeX" style=" font-size:11px; min-height:200px;">
                        <td width="5%"  height="25px"  align="center"><?php  echo $loop; ?></td>
                        <td width="10%" align="center"><?php  echo $r->tran_date;?></td>
                        <td width="45%"  align="left"><?php  echo $r->tran_description; ?></td>
                        <td width="10%" align="right"><?php  echo number_format($r->Collection,2); ?></td>
                        <td width="10%" align="right"><?php  echo number_format($r->Withdrawal,2); ?></td>
						<td width="10%" align="right"><?php  echo number_format($rowtotal,2); ?></td>
						<td width="8%"  align="center"><?php  echo $r->TranStatus; ?></td>	
						<?php 
							$total_collection=$total_collection+$r->Collection;
							$total_Dividend=$total_Dividend+$r->Dividend;;
							$total_Withdrawal=$total_Withdrawal+$r->Withdrawal;
						?>						
                    </tr>     
    
    
      <?php
                 	   } 
                       $Balance = $total_collection - $total_Withdrawal;//courier
    ?> 
                    <tr style=" font-size:12px;">
                        <th   height="25px" ></th>
                        <th  ></th>
                        <th>Total</th>
                        <th align="right" ><?php echo number_format($total_collection,2)  ?></th>
                        <th align="right"><?php echo number_format($total_Withdrawal,2) ?></th>
						<th align="right"></th>
						<th align="right"></th>
                    </tr>
    
<?php
	}
?>                     
</table>
<br />
          <div align="center" >         
<?php
	               echo 'Balance Amount :'. number_format($Balance,2) 
?>                    
          </div>           
                    <!-- /.table -->
 



