 <?php
 
        $mdate 		= now();
        $Date 		= date("d/m/Y",$mdate);  
            
?>  
  <div style="margin-left: 20px;">  
     			<?php
                         $Loop =0; $Amount = 0; $Page = 0;
                    
                     if($v_Data!='No'){                     
                        foreach ($v_Data->result() as $r)
    			 		{  
                              $Loop = $Loop + 1;  $Page =  $Page + 1;
                        $photo = $r->photo;
                       if(!empty($photo))
                            $Img = 'photo/'.$photo. '?'.md5(time());
                        else
                            $Img = 'assets/img/profile_small.jpg';
?>
            <div align="center"><b><?php echo $Loop;  ?></b></div>
                    <table width="100%" border="0" cellspacing="0" cellpadding="1" style="font-size: medium;">
                          <tr>
                            <td colspan="4"><div class="head" align="center">Investors List of 
                            <?php  echo $UnitDetails->office_name; ?> 
                            Unit</div></td> 
                          </tr>
                          
                          <tr>
                            <td width="27%">&nbsp;</td>
                            <td width="1%">&nbsp;</td>
                            <td width="55%">&nbsp;</td>
                            <td width="17%">&nbsp;</td>
                          </tr>
                          
                          <tr>
                            <td height="23">Name</td>
                            <td>:</td>
                            <td><?php  echo $r->name; ?></td>
                            <td width="17%" rowspan="10"><img src="<?php echo base_url().$Img; ?> " width="180" height="200" /></td>
                          </tr>
                          <tr>
                            <td>Folio No</td>
                            <td>:</td>
                            <td><?php  echo $r->folio_no; ?></td>
                          </tr>
                          <tr>
                            <td>Join Date</td>
                            <td>:</td>
                            <td><?php  echo $r->join_date; ?></td>
                          </tr>
                          <tr>
                            <td>Date of Birth</td>
                            <td>:</td>
                            <td><?php  echo $r->dob; ?></td>
                          </tr>
                          <tr>
                            <td>Sex</td>
                            <td>:</td>
                            <td><?php  echo $Sex[$r->sex];  ?></td>
                          </tr>
                          <tr>
                            <td>Email</td>
                            <td>:                              </td>
                            <td><?php  echo $r->email; ?></td>
                          </tr>
                          <tr>
                            <td>Job Title</td>
                            <td>:</td>
                            <td><?php  echo $r->job_title; ?></td>
                          </tr>
                          <tr>
                            <td><label>PAN Card</label></td>
                            <td>:                              </td>
                            <td><?php  echo $r->pancard; ?></td>
                          </tr>
                          <tr>
                            <td><label>Aadhar No</label></td>
                            <td>:</td>
                            <td><?php  echo $r->aadhar; ?></td>
                          </tr>
                          <tr>
                            <td>Passport No</td>
                            <td>:</td>
                            <td><?php  echo $r->passport; ?></td>
                          </tr>
                          <tr>
                            <td>Iqama No</td>
                            <td>:                              </td>
                            <td><?php  echo $r->iqama; ?></td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Current Location</td>
                            <td>:                              </td>
                            <td><?php  echo $r->current_location; ?></td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Current Residence Status</td>
                            <td>:                              </td>
                            <td><?php   echo $Residence[$r->residence_status]; ?></td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Subscription Amount</td>
                            <td>:                              </td>
                            <td><?php  echo $r->premium_amount; ?></td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Account Status </td>
                            <td>:                              </td>
                            <td><?php  echo $Status[$r->active];  ?></td>
                            <td> :                            </td>
                          </tr>
                          <tr>
                            <td colspan="4">&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="3">
                            <div  class="subhead" ><u>Address (KSA) </u></div></td>
                          </tr>
                          <tr>
                            <td>Address</td>
                            <td>:</td>
                            <td colspan="2"><?php  echo $r->address_ksa; ?></td>
                          </tr>
                          <tr>
                            <td>Mobile</td>
                            <td>:</td>
                            <td colspan="2"><?php  echo $r->mobile_ksa; ?></td>
                          </tr>
                          <tr>
                            <td colspan="4">&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="3"><div  class="subhead"  ><u>Address (India) </u></div></td>
                          </tr>
                          <tr>
                            <td>Address</td>
                            <td>:</td>
                            <td colspan="2"><?php  echo $r->address_india; ?></td>
                          </tr>
                          <tr>
                            <td colspan="4"> </td>
                          </tr>
                          <tr>
                            <td>Mobile</td>
                            <td>:                              </td>
                            <td colspan="2"><?php  echo $r->mobile_india; ?></td>
                          </tr>
                          <tr>
                            <td colspan="4">&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="3"><div  class="subhead"><u>Nominee </u></div></td>
                          </tr>
                          
                          <tr>
                            <td>Name</td>
                            <td>:</td>
                            <td colspan="2"><?php  echo $r->nominee_name; ?></td>
                          </tr>
                          <tr>
                            <td>Relation&nbsp;</td>
                            <td>:</td>
                            <td colspan="2"><?php  echo $r->nominee_relation; ?></td>
                          </tr>
                          <tr>
                            <td>Address</td>
                            <td>:</td>
                            <td colspan="2">  <?php  echo $r->nominee_address; ?></td>
                          </tr>
                          <tr>
                            <td>Mobile</td>
                            <td>:</td>
                            <td colspan="2"><?php  echo $r->nominee_mobile; ?></td>
                          </tr>
                     </table>   
                     <br pagebreak="true" />
    
 
    
      <?php
                 	   } 
    
	               }
?>                     
                             
  </div>                         
      
         
                        <!-- /.table -->
 



