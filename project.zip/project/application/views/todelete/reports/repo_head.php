    <table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td width="25%"> 
                <!-- <img id="logo" width="25px" height="25px" src="<?php echo base_url();?>images/logo.png" >  --!>
            </td>
			<td>
                <h2 style="text-align: center; width: 100%;"> Saif Enterprise  </h2>
            </td> 
		  </tr>
     </table> 