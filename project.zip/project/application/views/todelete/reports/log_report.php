 <?php
 
        $mdate 		= now();
        $Date 		= date("d/m/Y",$mdate);  
            
?>
<style type="text/css">
<!--
.style6 {
	color: #000000;
	font-weight: bold;
}
.style7 {font-size: 24px}
-->
</style>
 
                 
  <table width="100%" border="0" cellspacing="0" cellpadding="1"  style=" font-size:12px; font-weight: bold; color:#FF0000"   >
  <tr>
    <td colspan="2"><div align="center" style="font-weight: bold; font-size: large; color: black;"  > Transaction Report </div></td>
    </tr>
  <tr>
    <td width="69%"><div align="left"><span style="text-align: left;  ">Office :
      <?php  echo $LogDetails->office_name; ?>
    </span></div></td>
    <td width="31%"><div align="left"><span style="text-align: right; ">TrnNo :
      <?php  echo $LogDetails->log_no; ?>
    </span></div></td>
    </tr>
  
  <tr>
    <td><div align="left"><span style="text-align: left; ">Volunteer :
      <?php  echo $LogDetails->User_Name; ?>
    </span></div></td>
    <td><span style="text-align: right; ">Date :
        <?php  echo $LogDetails->log_date; ?>
    </span></td>
    </tr>
</table>
              
				
				 <table   width="95%" border="1" cellspacing="0" cellpadding="1" > 
                                
                    <tr bgcolor="#CCCCCC" style=" font-size:12px; font-weight: bold;">
                        <th width="50px" ><div align="center">Sl No</div></th>
                      <th width="41%"><div align="center">Name</div></th>
                      <th width="15%"><div align="center">Folio No.</div></th>
                      <th width="15%"><div align="center">Ref No</div></th>  
                      <th width="15%"><div align="center">Submitted Date</div></th> 
                      <th width="11%"><div align="center">Amount</div></th>
                    </tr>
     			<?php
                         $Loop =0; $Amount = 0; 
                    
                     if($LogReport!='No'){                     
                        foreach ($LogReport->result() as $r)
    			 		{  
                              $Loop = $Loop + 1; 
                              
                             $Amount =  $Amount +$r->tran_amount_collection;
?>
                    <tr class="gradeX" style="font-size:12px">
                        <td><div align="center"><?php  echo $Loop; ?></div></td>
                        <td><?php  echo $r->name; ?></td>
                         <td><div align="center"><?php  echo $r->folio_no; ?></div></td> 
                         <td><div align="center"><?php  echo $r->receipt_no; ?></div></td>  
                         <td><div align="center"><?php  echo $r->tran_date; ?></div></td>  
                         <td  ><div align="right"><?php  echo $r->tran_amount_collection; ?></div></td> 
                   </tr>       
    
    
      <?php
                 	   } 
    ?> 
                    <tr  bgcolor="#CCCCCC" style=" font-size:12px; font-weight: bold;"> 
                         <th >    </th>  
                        <th colspan="4"  align="right"> Total   </th>   
                        <th align="right"> <?php  echo $Amount; ?> </th>    
                   </tr> 
    
<?php
	}
?>                     
</table>
                    <!-- /.table -->
 



