 <?php
	   
     $UT = $this->session->userdata['mysession']['user_type_id'];
       
          $OfficeType = 'Unit Name';
	
    if($UT==3)
    $OfficeType = 'Area Name';
    if($UT==2)
    $OfficeType = 'Zone Name';
    if($UT==1)
    $OfficeType = 'Zone Name';
    $loop  = 0;
?>
               
              <table width="100%" border="0" cellspacing="0" cellpadding="1"  style=" font-size:12px; font-weight: bold; color:#FF0000"   >
              <tr>
                <td colspan="2"><div align="center" style="font-weight: bold; font-size: large; color: black;"  > Authorised Report </div></td>
                </tr>
              <tr>
                <td width="64%"><div align="left"><span style="text-align: left;  ">Office :
                  <?php  echo $OfficeData->office_name; ?>
                </span></div></td>
                <td width="36%"><div align="left"><span style="text-align: right; ">Start Date  :
                  <?php  echo $Sdate; ?>
                </span></div></td>
                </tr>
              
              <tr>
                <td><div align="left"><span style="text-align: left; "> </span></div></td>
                <td><span style="text-align: right; ">End Date :
                    <?php  echo $Edate; ?>
                </span></td>
                </tr>
            </table>
              
				
				 <table   width="95%" border="1" cellspacing="0" cellpadding="1" > 
                    <tr bgcolor="#CCCCCC" style=" font-size:12px; font-weight: bold;">
                        <th width="50px">Sl No</th>
                        <th>Authorised By</th>
                        <th><?php echo $OfficeType ?></th>
                        <th>Authorised Date</th>
                        <th>Number of Investors</th> 
                        <th>Total Amount</th>  
                    </tr>  
<?php

    	foreach ($v_data->result() as $r)
     	 { 
     	  $loop = $loop + 1;
?>
                    <tr class="gradeX" style="font-size:12px">
                        <td><div align="center"><?php  echo $loop; ?></div></td>
                        <td><?php  echo $r->authorised_by; ?></td>
                         <td><?php  echo $r->office_name; ?></td> 
                         <td><div align="center"><?php  echo $r->aproved_date; ?></div></td> 
                         <td><<div align="center"><?php  echo $r->count_receipt; ?></div></td> 
                         <td><div align="right"><?php  echo $r->sum_amount; ?></div></td>   
                            
                    </tr>
<?php
        }
 
?> 
                    
                     
</table>
                     
    