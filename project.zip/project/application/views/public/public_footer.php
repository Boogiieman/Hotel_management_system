
        <div class="footer">
            <div class="pull-right">
                Ver <strong>1.0.1</strong> Hotel Booking Public Module.
            </div>
            <div>
                <strong>Copyright</strong> Hotel Booking System Ver.1.0 &copy; 2014-2020
            </div>
        </div>

        </div>
        </div>



    


    <script>
        $(document).ready(function() {



        });
    </script>

</body>

</html>
