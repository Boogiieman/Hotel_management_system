<?php
    if(!isset($rooms))
    {
        $rooms="1";
    }
?>


<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-2">
        <h2>Rooms Details</h2>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo base_url(); ?>index.php/public_page/hotels">Home</a>
            </li>
            <li>
                <a href="<?php echo base_url(); ?>index.php/public_page/hotels">Hotels</a>
            </li>
            <li class="active">
                <strong>Rooms</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-10">
    <form class="m-t" role="form" action="<?php echo base_url(); ?>index.php/public_page/rooms" method="post" name="form1" id="form1">
                <div class="col-lg-10">
                    <div class="col-lg-4">
                                <div class="form-group">
                                    <input type="hidden" class="input-sm form-control" name="hotel_id" id="hotel_id" value="<?php echo $searchdata; ?>"/>
                                    <input type="hidden" class="input-sm form-control" name="room_id" id="room_id" value="0"/>
                                </div>
                    </div>
                    <div class="col-lg-2">                        
                                <div class="form-group">
                                    <label class="font-noraml"># of Rooms</label>
                                    <div class="input-group">
                                    <?php
                                        $js ='id="vrooms" class="form-control m-b"';
                                        $DefaultValue = set_value('vrooms',$rooms); 
                                        echo   form_dropdown('vrooms',$lstRooms ,$DefaultValue,$js);
                                    ?>
                                    </div>
                                </div>                            
                    </div>
                    <div class="col-lg-4">
                        
                                <div class="form-group" id="data_5">
                                    <label class="font-noraml">Select Date range (dd-mm-yyyy)</label>
                                    <div class="input-daterange input-group" id="datepicker">
                                        <input type="text" class="input-sm form-control" name="vdatefrom" id="vdatefrom" value="<?php echo $datefrom; ?>"/>
                                        <span class="input-group-addon">to</span>
                                        <input type="text" class="input-sm form-control" name="vdateto" id="vdateto" value="<?php echo $dateto; ?>" />
                                    </div>
                                </div>
                           
                    </div>
                    <div class="col-lg-2">                        
                                </br><button type="submit" class="btn btn-primary full-width m-b">Search</button>                            
                    </div>
				</div>
    </form>
    </div>
</div>
<?php
	if($v_data_hotel!= "No")
    {        
        $row_hotel = $v_data_hotel->row();
        if(isset($row_hotel))
        {
            $hotelImage     =$row_hotel->image1;
            $category       =$row_hotel->category;
            $hotel_name   =$row_hotel->hotel_name;
            $location   =$row_hotel->location;
            $facilities   =$row_hotel->facilities;
            $address1   =$row_hotel->address1;
            $address2   =$row_hotel->address2;
            $phone_number   =$row_hotel->phone_number;
        }
    }
?>
<div class="wrapper wrapper-content">
            <div class="row animated fadeInRight">
                <div class="col-md-4">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Hotel Details :  <?php echo $hotel_name; ?></h5>
                        </div>
                        <div>
                            <div class="ibox-content no-padding border-left-right">
                                <img alt="image" class="photos img-responsive" src="<?php echo base_url(); ?>assets/project_images/<?php echo $hotelImage; ?>">
                            </div>
                            <div class="ibox-content profile-content">
                                <h4><strong><?php echo $address1; ?></strong></h4>
                                <h4><strong><?php echo $address2; ?></strong></h4>
                                <p><i class="fa fa-map-marker"></i> <?php echo $location; ?></p>
                                <h5>
                                    <i>Facilities</i>
                                </h5>
                                <p>
                                    <?php echo $facilities; ?>
                                </p>
                                <div class="row m-t-lg">
                                    <div class="col-md-6">
                                        <h5><strong></strong> Total Rooms</h5>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><strong></strong> 5</h5>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><strong></strong> Phone/Contact</h5>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><strong></strong> <?php echo $phone_number; ?></h5>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><strong></strong> Category</h5>
                                    </div>
                                    <div class="col-md-6">
                                        <h5><strong></strong> <?php echo $category; ?></h5>
                                    </div>
                                </div>                                
                                <div class="user-button">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <!--<button type="button" class="btn btn-primary btn-sm btn-block"><i class="fa fa-envelope"></i> Send Message</button>-->
                                        </div>
                                        <div class="col-md-6">
                                            <div id="result"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
                    </div>
                <div class="col-md-8">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Rooms List</h5>                            
                        </div>
                        <div class="ibox-content">
                            <div>                                
                                <br>
<?php
	if($v_data_rooms!= "No")
    {
        $loop = 0;
    	foreach ($v_data_rooms->result() as $r)
     	{ 
     	    $loop = $loop + 1;
?>
                                <div class="feed-activity-list">
                                        <div class="feed-element">
                                            
                                            <div class="media-body ">
                                                <div  class="col-sm-4">
                                                    <a href="#" class="pull-left">
                                                        <img alt="image" class="photos  img-responsive" src="<?php echo base_url(); ?>assets/project_images/<?php echo $r->image1; ?>">
                                                    </a>
                                                </div>
                                                <div  class="col-sm-8">
                                                    <small class="pull-right"><?php echo $r->room_number; ?></small>
                                                    <strong><?php echo $r->room_type; ?></strong> <br>
                                                    <small class="text-muted">Adults : <?php echo $r->no_of_adults; ?></small> <small class="text-muted"> Childs : <?php echo $r->no_of_childs; ?></small>
                                                    <div class="well">
                                                            <?php echo $r->facilities; ?>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <span class="badge badge-primary">Availability : <?php echo $r->available; ?> days</span>
                                                        <span class="badge badge-warning">Requested : <?php echo $r->days; ?> days</span>
                                                    </div>
                                                    <div class="col-md-3">
                                                    <?php if($r->diff==0){ ?>
                                                        <button type="button" class="btn btn-primary btn-sm btn-block" id="cmdbooknow" name="cmdbooknow" onclick="bookroom(<?php echo $r->room_id; ?>);"><i class="fa fa-cart-plus"></i> Book</button>
                                                    <?php } else { ?> Not Available <?php } ?> 
                                                    </div>
                                                    <div class="col-md-12">
                                                        <br>
                                                    </div>
                                                    <?php if($r->diff==0){ ?>
                                                    <div class="col-md-4">
                                                        <span class="label label-primary">Total Rate : <?php echo $r->rate; ?> </span>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <span class="label label-info">Total Tax : <?php echo $r->tax; ?></span>
                                                    </div>
                                                    <div class="col-md-4">                                                    
                                                        <span class="label label-success">Total Amount : <?php echo $r->total_amount; ?> </span>
                                                    </div>
                                                    <?php } ?>

                                                </div>
                                            </div>
                                        </div>
                                        
                                </div>
<?php
        }
    } 
?>
                                

                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div> 
           
	<script>

            function bookroom(room_id)
            { 
                $('#room_id').val(room_id);
                var r = confirm("Are you sure you want to Book this room?");
                if (r == true) 
                {
                    var serializedData = $('#form1').serialize();  
                    $.ajax({
                        type:"POST",
                        dataType: "json",
                        data: serializedData,
                        url:"<?php echo base_url(); ?>index.php/public_page/bookRoom",                                    
                        success:function(data)
                        {
                            alert(data.msg);
                            //$('#result').html(data.msg);
                        },
                        error: function(jqXHR, textStatus, errorThrown) 
                        {  
                            $("#msg").html("ERROR:::::" + jqXHR.responseText);
                            alert("error:" + jqXHR.responseText);	
                        }
                    });
                }
            }
            $(document).ready(function(){
                $('.contact-box').each(function() {
                    animationHover(this, 'pulse');
                });
            $('#data_5 .input-daterange').datepicker({
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true,
                format: 'dd-mm-yyyy'
            });

            
        });

    </script>