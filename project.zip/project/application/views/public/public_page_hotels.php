        <?php
            if(!isset($location))
            {
                $location="0";
            }
            if(!isset($rooms))
            {
                $rooms="1";
            }

            
        ?>
        <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-2">
                    <h2>List of Hotels</h2>                    
                </div>
                <form class="m-t" role="form" action="<?php echo base_url(); ?>index.php/public_page/hotels" method="post">
                <div class="col-lg-10">
                    <div class="col-lg-4">
                                <div class="form-group">
                                    <label class="font-noraml">Select Location</label>
                                    <div class="input-group">
                                    <?php
                                        $js ='id="txtLocation" class="form-control m-b"';
                                        $DefaultValue = set_value('txtLocation',$location); 
                                        echo   form_dropdown('txtLocation',$lstlocation ,$DefaultValue,$js);
                                    ?>
                                    </div>
                                </div>
                    </div>
                    <div class="col-lg-2">                        
                                <div class="form-group">
                                    <label class="font-noraml"># of Rooms</label>
                                    <div class="input-group">
                                    <?php
                                        $js ='id="txtRooms" class="form-control m-b"';
                                        $DefaultValue = set_value('txtRooms',$rooms); 
                                        echo   form_dropdown('txtRooms',$lstRooms ,$DefaultValue,$js);
                                    ?>
                                    </div>
                                </div>                            
                    </div>
                    <div class="col-lg-4">
                        
                                <div class="form-group" id="data_5">
                                    <label class="font-noraml">Select Date range (dd-MM-yyyy)</label>
                                    <div class="input-daterange input-group" id="datepicker">
                                        <input type="text" class="input-sm form-control" name="datefrom" id="datefrom" value="<?php echo $datefrom; ?>"/>
                                        <span class="input-group-addon">to</span>
                                        <input type="text" class="input-sm form-control" name="dateto" id="dateto" value="<?php echo $dateto; ?>" />
                                    </div>
                                </div>
                           
                    </div>
                    <div class="col-lg-2">                        
                                </br><button type="submit" class="btn btn-primary full-width m-b">Search</button>                            
                    </div>
                </form>
            </div>
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
<?php
	if($v_data!= "No")
    {
        $loop = 0;
    	foreach ($v_data->result() as $r)
     	{ 
     	    $loop = $loop + 1;
?>
            <div class="col-lg-6">
                <div class="contact-box">
                    <!--<a href="<?php echo base_url(); ?>index.php/public_page/rooms">-->
                    
                    <div class="col-sm-4">
                        <div class="text-center">
                            <img alt="image" class="img-circle m-t-xs img-responsive" src="<?php echo base_url(); ?>assets/project_images/<?php echo $r->image1; ?>">
                            <div class="m-t-xs font-bold"><?php echo $r->category; ?></div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <h3><strong><?php echo $r->hotel_name; ?></strong></h3>
                        <p><i class="fa fa-map-marker "></i> <span class="btn-info"><?php echo $r->location; ?></span></p>
                        <address>
                            <strong><?php echo $r->facilities; ?></strong><br>
                            <?php echo $r->address1; ?><br>
                            <?php echo $r->address2; ?><br>
                            <abbr title="Phone">P:</abbr> <?php echo $r->phone_number; ?>
                        </address>
                    </div>
                    <div class="clearfix"><a class="btn btn-xs btn-warning" onclick="postPage(<?php echo $r->hotel_id; ?>);"><i class="fa fa-hotel"></i> Select Rooms</a></div>
                    
                       <!-- </a>-->
                </div>
            </div>
<?php
        }
    } 
?>
         <form method="post" accept-charset="utf-8" action="<?php echo base_url(); ?>index.php/public_page/rooms" id="form1" name="form1">   
            <input type="hidden" name="hotel_id" id="hotel_id">
            <input type="hidden" name="vrooms" id="vrooms">
            <input type="hidden" name="vdatefrom" id="vdatefrom">
            <input type="hidden" name="vdateto" id="vdateto">
         </form>
            
        </div>
        </div>
        <script>
        function postPage(hotel_id) {
                $('#hotel_id').val(hotel_id);
                $('#vrooms').val($('#txtRooms').val());
                $('#vdatefrom').val($('#datefrom').val());
                $('#vdateto').val($('#dateto').val());
                document.getElementById("form1").submit();
        }
        $(document).ready(function(){
            $('.contact-box').each(function() {
                animationHover(this, 'pulse');
            });
            $('#data_5 .input-daterange').datepicker({
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true,
                format: 'dd-mm-yyyy'
            });

            
        });
    </script>
        